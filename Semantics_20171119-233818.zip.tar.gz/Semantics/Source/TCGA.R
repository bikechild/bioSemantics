library("stringr")

const_vecIgnorePhenoCol <- 
  c("bcr patient uuid", "bcr patient barcode", "form completion date", 
    "prospective collection", "retrospective collection", "birth days to", 
    "tissue prospective collection indicator", 
    "tissue retrospective collection indicator", "days to birth", 
    "cytokeratin immunohistochemistry staining method micrometastasis indicator", 
    "days to initial pathologic diagnosis", "patient id", "project code", 
    "stage other")


makeDataTcga <- function(in_cancer_name) {
  virtual_gse_num <- "TCGA_" %+% in_cancer_name
  
  pathTcga <- read.csv(const_pathTcagCsv)
  if (in_cancer_name %in% pathTcga$cancer) {
    selPathTcga <- pathTcga[in_cancer_name == pathTcga$cancer, ]
    pathTcgaPheno <- selPathTcga$pathPheno
    pathRnaPheno <- selPathTcga$pathRna
    
    tcgaPheno <- read.csv(pathTcgaPheno, sep = "\t")
    tcgaRnaExp <- read.csv(pathRnaPheno, sep = "\t")
    
    tcgaRnaExp <- tcgaRnaExp[tcgaRnaExp$GeneSymbol != "?", ]
    rownames(tcgaRnaExp) <- 1:dim(tcgaRnaExp)[1]
    
    dfSymbolData <- data.frame(ID = 1:dim(tcgaRnaExp)[1], 
                               gene_symbol = tcgaRnaExp$GeneSymbol)
    saveRDS(list(TCGA = dfSymbolData), const_pathFileFeature)
    
    tcgaRnaExp <- tcgaRnaExp[, which(substr(colnames(tcgaRnaExp), 14, 15) == 
                                       "01")]
    colnames(tcgaRnaExp) <- substr(colnames(tcgaRnaExp), 1, 12)
    
    colnames(tcgaPheno) <- str_replace_all(tcgaPheno[1, ], "_", " ")
    tcgaPheno <- tcgaPheno[3:nrow(tcgaPheno), ]
    rownames(tcgaPheno) <- make.names(tcgaPheno[, 2])
    tcgaPheno <- tcgaPheno[, !(colnames(tcgaPheno) %in% const_vecIgnorePhenoCol)]
    
    commonID <- intersect(rownames(tcgaPheno), colnames(tcgaRnaExp))
    tcgaPheno <- tcgaPheno[commonID, ]
    tcgaRnaExp <- tcgaRnaExp[, commonID]
    
    saveRDS(list(TCGA = "TCGA"), const_pathFileGplList)
    saveRDS(list(TCGA = tcgaRnaExp), const_pathFileGeno)
    saveRDS(list(TCGA = tcgaPheno), const_outPData)
    tmp <- readRDS(const_outPData)
    tmpDf <- tmp$TCGA
    tmpDf[, COL_NAME_GSE_NUM] <- virtual_gse_num
    tmpDf[, COL_NAME_GEO_SAMPLE] <- rownames(tmpDf)
    tmpDf[, COL_NAME_PLATFORM_ID] <- "TCGA"
    saveRDS(tmpDf, const_summaryPDataFile)
    
    saveRDS(data.frame(gse.num = virtual_gse_num, 
                       title = "TCGA", 
                       summary = "TCGA"), 
            const_outGseTitleSummaryFile)
  } else {
    return(FALSE)
  }
}
