flag_shinyrCommunilcation <- TRUE

flag_conversionTableChanged <- TRUE

while( flag_conversionTableChanged ){
  if (!is.na(const_path_root_old) &&  !file.exists(const_pathFileInitialConversionTable)){
    tmp <- readRDS(const_old_pathFileInitialConversionTable)
  } else {
    tmp <- readRDS(const_pathFileInitialConversionTable)
  }
  outPdata <- toDfString(readRDS(const_summaryPDataFile))
  
  conversionTable <- toDfString(tmp$conversionTable)
  dfRegularExp <- toDfString(tmp$dfRegularExp)
  dfSumFunction <- tmp$dfSumFunction
  dfValueConstraint <- toDfString(tmp$dfValueConstraint)
  listInferenceEngine <- tmp$listInferenceEngine
  valueConversionTable <- tmp$valueConversionTable
  
  colGeoId <- c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE, COL_NAME_PLATFORM_ID)
  
  notUsedColName <- setdiff(colnames(outPdata), colGeoId)
  # for (i in colnames(outPdata)) {
  #   catHeader(i, in.rank = 2)
  #   print(sF(outPdata[ , i]))
  #   readline("Pause...")
  # }
  
  filterPData <- outPdata[ , make.names(colGeoId)]
  arrangePData <- outPdata[ , make.names(colGeoId)]
  
  for (tmpNcolConversionTable in 1:nrow(conversionTable)) {
    tmpRowConversionTable <- conversionTable[tmpNcolConversionTable, ]
    tmpKeyword <- tmpRowConversionTable[ , 'keyword']
    if (!(tmpKeyword %in% colnames(filterPData))) {
      filterPData[ , tmpKeyword] <- NA
    }
    if (tmpRowConversionTable[ , 'alias'] %in% colnames(outPdata)) {
      vecData <- outPdata[ , tmpRowConversionTable[ , 'alias']]
      notUsedColName <- setdiff(notUsedColName, tmpRowConversionTable[ , 'alias'])
      conflictRow <- which(!is.na(vecData) & !is.na(filterPData[ , tmpKeyword]))
      
      if (length(conflictRow) > 0) {
        cat("Confilct Data is:\n")
        print(cbind(filterPData[conflictRow, tmpKeyword, drop = F], 
                    outPdata[conflictRow , tmpRowConversionTable[ , 'alias'], drop = F]))
        # stop('if (length(conflictRow) > 0)')
      }
      conversionRow <- !is.na(vecData)
      tmpVec4FilterPData <- vecData[conversionRow]
      for (tmpRowValueConversionTable in 1:nrow(valueConversionTable)) {
        tmpWhich4Old <- which(tmpVec4FilterPData == valueConversionTable[tmpRowValueConversionTable, 'old'])
        if (length(tmpWhich4Old) > 0) {
          tmpVec4FilterPData[tmpWhich4Old] <- valueConversionTable[tmpRowValueConversionTable, 'new']
        }
      }
      filterPData[conversionRow, tmpKeyword] <- tmpVec4FilterPData    
    }
  }
  
  for (tmp in colnames(filterPData)) {
    if (all(is.na(filterPData[, tmp]))) {
      filterPData[, tmp] <- NULL
    }
  }
  
  
  for (tmp in intersect(unique(dfRegularExp[ , 'keyword']), colnames(filterPData))) {
    tmp.out.data <-  rep(NA, nrow(filterPData))
    for (tmp.row in which(dfRegularExp[ , 'keyword'] == tmp)) {
      tmp.row.out.data <- changeFilterPData(filterPData, tmp, dfRegularExp[tmp.row, 'regStr'], dfRegularExp[tmp.row, 'postProcess'])
      if (!(tmp %in% names(dfSumFunction))) {
        tmp.out.data <- leftVecSel(tmp.row.out.data, tmp.out.data)
      } else {
        tmp.out.data <- dfSumFunction[[tmp]](tmp.row.out.data, tmp.out.data)
      }
    }
    arrangePData[ , tmp] <- tmp.out.data
  }
  
  for (tmpListInferenceEngine in listInferenceEngine) {
    tmpFigName <- tmpListInferenceEngine[['fig.name']]
    tmpArgs <- tmpListInferenceEngine[['arg.name']]
    tmpScriptText <- tmpListInferenceEngine[['script.text']]
    
    if (!all(tmpArgs %in% colnames(arrangePData))) {
      next
    }
    
    for (i in length(tmpArgs):1){
      pasteArgText <- paste0('#in_arg', i)
      tmpScriptText <- gsub(pasteArgText, paste0('arrangePData[ ,"', tmpArgs[i], '"]'), tmpScriptText)
    }
    
    tmp.out.data <- eval(parse(text = tmpScriptText))
    if (!(tmpFigName %in% colnames(arrangePData))) {
      arrangePData[ , tmpFigName] <- NA
    }
    arrangePData[ , tmpFigName] <- leftVecSel(arrangePData[ , tmpFigName], tmp.out.data)
  }
  
  for (tmpNcolValueConstraint in 1:nrow(dfValueConstraint)) {
    tmpFeatureName <- dfValueConstraint[tmpNcolValueConstraint, "feature"]
    if (!(tmpFeatureName %in% colnames(arrangePData))) next
    tmpFunction <- eval(parse(text = dfValueConstraint[tmpNcolValueConstraint, "function.to.filter"]))
    tmpValue  <- arrangePData[ , tmpFeatureName]
    tmpOut <- sapply(tmpValue, tmpFunction)
    arrangePData[ , tmpFeatureName] <- ifelse(tmpOut, tmpValue, NA)
  }
  
  # out
  notUsedColName
  saveRDS(arrangePData, const_arrangePDataFile)
  # out ended
  
  flag_conversionTableChanged <- F
  for (i in notUsedColName) {
    cat(i, '\n')
    tmp <- sort(names(summary(outPdata[ , i])), decreasing = T)
    valueList <- tmp[1:min(length(tmp), 5)]
    dfValueList <- data.frame(count = valueList, row.names = names(valueList))

    tmp <- calFeatureDistance(i, conversionTable[ , "alias"])
    tmp2 <- sort(tmp)[1:10]
    
    dfSum4Feature <- data.frame(distance = tmp2, candidate_name = names(tmp2), row.names = 1:NROW(tmp2))
    if (!flag_shinyrCommunilcation) {
      catHeader(i, in.rank = 2)      
      print(dfValueList)      
      print(dfSum4Feature)
      selKeyData <- readline("Insert number if there is alias name(-1 is end): ")
      numeric_selKeyData <- suppressWarnings(as.numeric(selKeyData))      
    } else {
      tmp <- list(state = 1,
                  df = dfSum4Feature,
                  feature = i,
                  valueDf = dfValueList)
      writeJsonCNewLine(in_list = tmp,
                        in_file_path = jsonFeature2Shiny)
      while (TRUE) {
        numeric_selKeyData <- tryInf(jsonlite::fromJSON(jsonShiny2Feature))
        if (numeric_selKeyData != 0) {
          tmp <- list(state = 0,
                      df = data.frame(),
                      feature = "",
                      valueDf = "")
          writeJsonCNewLine(in_list = tmp,
                            in_file_path = jsonFeature2Shiny)
          break
        }
        Sys.sleep(1)
      }
    }

    if (!is.na(numeric_selKeyData) & numeric_selKeyData > -9) {
      if (numeric_selKeyData > NROW(tmp2)) next
      if (numeric_selKeyData <= -1) {
        break
      }
      tmp_keyword <- conversionTable[conversionTable[ , "alias"] == names(tmp2[numeric_selKeyData]), 'keyword']
      conversionTable <- rbind(conversionTable, data.frame(keyword = tmp_keyword, 
                                                           alias = i))
      flag_conversionTableChanged <- TRUE
    }
  }
  
  if (flag_conversionTableChanged) {
    catE("Please rerun filterFeatueData.R")
  }
  
  saveRDS(list(conversionTable = conversionTable,
               dfRegularExp = dfRegularExp,
               dfSumFunction = dfSumFunction,
               dfValueConstraint = dfValueConstraint,
               listInferenceEngine = listInferenceEngine,
               valueConversionTable = valueConversionTable), 
          const_pathFileInitialConversionTable)
}
