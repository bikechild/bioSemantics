source("commonFunc.R")

if (!is.na(const_path_root_old)) {
  a <- readRDS(const_old_summaryGDataFile)
  b <- readRDS(const_summaryGDataFile)
  saveRDS(c(a,b), const_summaryGDataFile)
  
  a <- readRDS(const_arrangePDataFile)
  b <- readRDS(const_old_arrangePDataFile)
  saveRDS(mergeDF(a, b), const_arrangePDataFile)
}
