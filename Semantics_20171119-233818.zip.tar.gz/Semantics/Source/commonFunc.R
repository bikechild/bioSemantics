source("/home/bike/Semantics/Source/commonFunSub.R")

flag_shinyRCode <- TRUE
const_tcgaInitalValue <- FALSE
const_pvalueSignificant <- 3
const_scaleFillGreyStart <- 0.2
const_scaleFillGreyStop <- 0.7

if (!exists('userName')) {
  userName <- 'a'
}

NAStringVector <- c("", "not available", "na", 'n/a', "unk",'ntl')

const_rootPath <- '/home/bike/Semantics/'
const_rootSource <- fitDirPath(const_rootPath, 'Source')
const_tmpPath <- fitDirPath(const_rootPath, 'temp')
const_geoRawPath <- fitDirPath(const_tmpPath, 'GEOFile')

pathShiny <- fitDirPath(const_rootSource, 'shinyR')
pathPwTable <- fitFilePath(pathShiny, 'pw', 'pwtable.Rds')
pathKnitrTemplate <- fitFilePath(const_rootSource, 'knitr_template.docx')
pathTempDir <- fitDirPath(const_tmpPath, userName)
dir.create(pathTempDir, showWarnings = FALSE, recursive = TRUE)

jsonMain2Shiny <- fitFilePath(pathTempDir, 'main2Shiny.json')
jsonFeature2Shiny <- fitFilePath(pathTempDir, 'feature2Shiny.json')
jsonShiny2Feature <- fitFilePath(pathTempDir, 'shiny2Feature.json')

commandLogFile <- fitFilePath(pathTempDir, "_main_R.log")

pathShinyWww <- fitDirPath(pathShiny, 'www')

const_shinyZipFile <- paste0(userName, "_docs.zip") 
const_shinyZipFilePath <- fitFilePath(pathShinyWww, const_shinyZipFile)

const_MainJson <- fitFilePath(pathTempDir, "_main.json")
const_MainPhenoLoopJson <- fitFilePath(pathTempDir, "_mainPhenoLoop.json")

const_path_root_old <- fitDirPath(pathTempDir, 'Data')
const_path_root_new <- fitDirPath(pathTempDir, 'DataTemp')
const_GSEText <- fitFilePath(pathTempDir, 'GSEList.txt')
const_pathTcagCsv <- fitFilePath(const_rootPath, '/tcga/pathTCGA.csv')
const_docPath <- fitDirPath(pathTempDir, 'result')
const_docPathSub <- fitDirPath(pathTempDir, 'result/analysisUsingPhenotypeAndGenoType')
const_docSummaryCutoffFile <- fitFilePath(const_docPathSub, 'docSummaryCutoff.Rds')
const_docSummaryCutoffTable <- fitFilePath(const_docPathSub, 'docSummaryCutoff.csv')
pathKnitrData <- fitFilePath(const_path_root_old, 'makeDoc.Rds')

const_base_base_outGseTitleSummaryFile <- "outGseTitleSummary.rds"
const_base_summaryPDataFile <- "summaryPData.rds"
const_base_summaryGDataFile <- "summaryGData.rds"
const_base_arrangePDataFile <- "arrangePData.Rds"
const_base_outPData <- "outPData.rds"
const_base_pathFileGeno <- "outGData.rds"
const_base_pathFileFeature <- "outFData.rds"
const_base_pathFileGplList <- "outGplData.rds"
const_base_pathFileSurvExpressGeoList <- "SurvExpressGeoList.rds"
const_base_initialConversionTable <- "initialConversionTable.Rds"


const_outGseTitleSummaryFile <- fitFilePath(const_path_root_new, const_base_base_outGseTitleSummaryFile)
const_summaryPDataFile <- fitFilePath(const_path_root_new, const_base_summaryPDataFile)
const_summaryGDataFile <- fitFilePath(const_path_root_new, const_base_summaryGDataFile)
const_arrangePDataFile <- fitFilePath(const_path_root_new, const_base_arrangePDataFile)
const_outPData <- fitFilePath(const_path_root_new, const_base_outPData)
const_pathFileGeno <- fitFilePath(const_path_root_new, const_base_pathFileGeno)
const_pathFileFeature <- fitFilePath(const_path_root_new, const_base_pathFileFeature)
const_pathFileGplList <- fitFilePath(const_path_root_new, const_base_pathFileGplList)
const_pathFileSurvExpressGeoList <- fitFilePath(const_path_root_new, const_base_pathFileSurvExpressGeoList)
const_pathFileInitialConversionTable <- fitFilePath(const_path_root_new, const_base_initialConversionTable)

const_old_outGseTitleSummaryFile <- fitFilePath(const_path_root_old, const_base_base_outGseTitleSummaryFile)
const_old_summaryPDataFile <- fitFilePath(const_path_root_old, const_base_summaryPDataFile)
const_old_summaryGDataFile <- fitFilePath(const_path_root_old, const_base_summaryGDataFile)
const_old_arrangePDataFile <- fitFilePath(const_path_root_old, const_base_arrangePDataFile)
const_old_outPData <- fitFilePath(const_path_root_old, const_base_outPData)
const_old_pathFileGeno <- fitFilePath(const_path_root_old, const_base_pathFileGeno)
const_old_pathFileFeature <- fitFilePath(const_path_root_old, const_base_pathFileFeature)
const_old_pathFileGplList <- fitFilePath(const_path_root_old, const_base_pathFileGplList)
const_old_pathFileSurvExpressGeoList <- fitFilePath(const_path_root_old, const_base_pathFileSurvExpressGeoList)
const_old_pathFileInitialConversionTable <- fitFilePath(const_path_root_old, const_base_initialConversionTable)  
