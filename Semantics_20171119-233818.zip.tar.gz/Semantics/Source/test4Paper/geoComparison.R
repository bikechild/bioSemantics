loadLib(stringr)

cat('\f')
outPdataSel <- outPdata[outPdata$`gse name` == str_trim("GSE21501"), ]
outPdataTest <- data.frame(row.names = row.names(outPdataSel))
for (i in colnames(outPdataSel)) {
  selColOutPdataTest <- outPdataSel[, i]
  if (!all(is.na(selColOutPdataTest))) {
    outPdataTest[ , i] <- selColOutPdataTest
  }
}
head(outPdataTest)
