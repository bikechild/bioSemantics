source('C:/Users/feel/Desktop/CloudStation/_module/R/smallFunction/Sub/noticeToMe_StrPlus.R')
source("commonFunc.R")

tmpData <- readRDS(const_outPData)
for (tmp_names in names(tmpData)){
  cat('\f')
  cat(tmp_names, '\n')
  tmp <- tmpData[[tmp_names]]
  
  print(head(tmp))
  readline("Press return to continue")
}


