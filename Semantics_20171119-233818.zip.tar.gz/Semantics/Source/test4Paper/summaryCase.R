tmp1 <- read.csv('C:/Users/feel/Desktop/CloudStation/Personal/Graduation/Papers/CancerList.csv')

tmp2 <- tmp1$Cancer.Type

tmp3 <- sub("\\?", "", tmp2)
tmp4 <- sub(" ", "", tmp3)
tmp5 <- tolower(tmp4)
tmp6 <- summary(as.factor(tmp5))

tmp7 <- data.frame(names(tmp6), tmp6)
