flag_testGeoList <- FALSE

if (!flag_testGeoList) {
  geoList <- c(as.matrix(read.csv(const_GSEText, header = F)))  
} else {
  cat("downloadGeoData.R is TEST status.")
  geoList <- c( c("GSE2990","GSE3494","GSE6532","GSE12093","GSE9195","GSE16391","GSE17705","GSE19615"), #geo2RBreast.R
                c("GSE14814", "GSE19188", "GSE29013", "GSE30219", "GSE31210", "GSE3141",
                  "GSE31908", "GSE37745", "GSE43580", "GSE4573", "GSE50081", "GSE8894"), #geo2RLung.R
                c("GSE14764","GSE15622","GSE18520","GSE19829","GSE23554","GSE26193","GSE26712",
                  "GSE27651","GSE30161","GSE3149","GSE51373","GSE9891"), #geo2ROvarian.R
                readRDS(file = const_pathFileSurvExpressGeoList) #geo2RSurvExpress.R
                )  
}
geoList <- unique(geoList)

if (TRUE){
  tryCatch({
    dir.create(const_path_root_new, showWarnings = FALSE, recursive = TRUE)
    dir.create(const_geoRawPath, showWarnings = FALSE, recursive = TRUE)
    getGEOpData(in.geo.list = geoList,
                in.save.phono.path.file = const_outPData,
                in.save.geno.path.file = const_pathFileGeno,
                in.save.feature.path.file = const_pathFileFeature,
                in.save.gpl.path.file = const_pathFileGplList,
                in.dest.path = const_geoRawPath)
  },error=function(e){      
    stop(e);
  });
}

outPdata <- summaryPdata(readRDS(const_outPData))
saveRDS(outPdata, const_summaryPDataFile)

outGseTitleSummary <- findGseTitleSummaryInGeoVec( unique(outPdata$`gse name`) )
saveRDS(outGseTitleSummary, const_outGseTitleSummaryFile)
