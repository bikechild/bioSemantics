# Start Program load(".RData")

#TODO:
#   distanceData <- calFeatureDistance("stage", colnames(outPdata))
#   data.frame(dist = sort(distanceData, decreasing = F))[21:30, , drop=F]
#TODO
# a <- readRDS(const_outPData)
# a[["GSE3494__GSE3494-GPL96_series_matrix.txt.gz"]]$source_name_ch1
# unique(outPdata[which(outPdata[ ,"tumor stage"] == 'late'), COL_NAME_GSE_NUM])
# TODO
# tmp3 <- selColData(outPdata[ , "source_name_ch1"], normalCancerChar)
# finalPdata[ ,"cancer.or.tumor"] <- mergeFinalCol(mergeFinalCol(tmp1, tmp2), tmp3)

#  find tissue data in tmpFindTissueData <- unique(finalPdata[is.na(finalPdata[ ,"tissue"]), COL_NAME_GSE_NUM])
# 1. description
# 2. source_name_ch1
# 3. using function of findGEOTitleSummary

source("commonFunc.R")

outPdata <- readRDS(const_summaryPDataFile)
outGseTitleSummary <- readRDS(const_outGseTitleSummaryFile)

finalPdata <- outPdata[ ,c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE, COL_NAME_PLATFORM_ID)]

featureDataList <- apply(outPdata,2,function(x){length(which(!is.na(x)))})
data.frame(count = sort(featureDataList, decreasing = T))[1:20, , drop=F]

data.frame(dist = sort(calFeatureDistance("tissue", colnames(outPdata)), decreasing = F))[1:20, , drop=F]


summaryVec(outPdata$`stage`, Inf, in.stop = F)
stageReg <- '[123]|i{1,3}|iv'
sub_stageRege <- '([123]|i|ii|iii|iv)[abc]{1}'
finalPdata[ ,"stage"] <- selColData(outPdata[ ,"stage"], stageReg, in.exact.flag =  T)
finalPdata[ ,"sub_stage"] <- selColData(outPdata[ ,"stage"], sub_stageRege, in.exact.flag =  T)

summaryVec(outPdata$`pathological stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"pathological stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"pathological stage"], sub_stageRege, in.exact.flag =  T)
)
summaryVec(outPdata$`tumor stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"tumor stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"tumor stage"], sub_stageRege, in.exact.flag =  T)
)
summaryVec(outPdata$`cancer stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"cancer stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"cancer stage"], sub_stageRege, in.exact.flag =  T)
)
summaryVec(outPdata$`stage (pathological )`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"stage (pathological )"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"stage (pathological )"], sub_stageRege, in.exact.flag =  T)
)

summaryVec(outPdata$`clinical stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"clinical stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"clinical stage"], sub_stageRege, in.exact.flag =  T)
)

summaryVec(outPdata$`final pat stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"final pat stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"final pat stage"], sub_stageRege, in.exact.flag =  T)
)
summaryVec(outPdata$`ajcc uicc stage`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"ajcc uicc stage"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"ajcc uicc stage"], sub_stageRege, in.exact.flag =  T)
)
summaryVec(outPdata$`stage at reccurence`, Inf, in.stop = F)
finalPdata[ ,"stage"] <- mergeFinalCol(finalPdata[ ,"stage"],
                                       selColData(outPdata[ ,"stage at reccurence"], stageReg, in.exact.flag =  T)
)
finalPdata[ ,"sub_stage"] <- mergeFinalCol(finalPdata[ ,"sub_stage"],
                                           selColData(outPdata[ ,"stage at reccurence"], sub_stageRege, in.exact.flag =  T)
)


tStageReg <- 't([1-4]|a|b|is|x)'
nStageReg <- 'n(\\+|[0-3]|x)'
mStageReg <- 'm(\\+|[0-3]|x)'

finalPdata[ ,"t_stage"] <- selColData(outPdata[ ,"stage"], tStageReg)
finalPdata[ ,"n_stage"] <- selColData(outPdata[ ,"stage"], nStageReg)
finalPdata[ ,"m_stage"] <- selColData(outPdata[ ,"stage"], mStageReg)

summaryVec(outPdata$`tnm stage`, Inf, in.stop = F)
finalPdata[ ,"t_stage"] <- mergeFinalCol(finalPdata[ ,"t_stage"],
                                         selColData(outPdata[ ,"tnm stage"], tStageReg)
)
finalPdata[ ,"n_stage"] <- mergeFinalCol(finalPdata[ ,"n_stage"],
                                         selColData(outPdata[ ,"tnm stage"], nStageReg)
)
finalPdata[ ,"m_stage"] <- mergeFinalCol(finalPdata[ ,"m_stage"],
                                         selColData(outPdata[ ,"tnm stage"], mStageReg)
)

summaryVec(outPdata$`pt stage`, Inf, in.stop = F)
finalPdata[ ,"t_stage"] <- mergeFinalCol(finalPdata[ ,"t_stage"], selColData(outPdata[ ,"pt stage"], tStageReg))
summaryVec(outPdata$`pn stage`, Inf, in.stop = F)
finalPdata[ ,"n_stage"] <- mergeFinalCol(finalPdata[ ,"n_stage"], selColData(outPdata[ ,"pn stage"], nStageReg))
summaryVec(outPdata$`pm stage`, Inf, in.stop = F)
finalPdata[ ,"m_stage"] <- mergeFinalCol(finalPdata[ ,"m_stage"], selColData(outPdata[ ,"pm stage"], mStageReg))

summaryVec(outPdata$`t-stage`, Inf, in.stop = F)
finalPdata[ ,"t_stage"] <- mergeFinalCol(finalPdata[ ,"t_stage"], selColData(outPdata[ ,"t-stage"], "[0-4]"))
summaryVec(outPdata$`n-stage`, Inf, in.stop = F)
finalPdata[ ,"n_stage"] <- mergeFinalCol(finalPdata[ ,"n_stage"], selColData(outPdata[ ,"n-stage"], "[0-4]"))
summaryVec(outPdata$`m-stage`, Inf, in.stop = F)
finalPdata[ ,"m_stage"] <- mergeFinalCol(finalPdata[ ,"m_stage"], selColData(outPdata[ ,"m-stage"], "[0-4]"))

summaryVec(outPdata$`pathologic t stage`, Inf, in.stop = F)
finalPdata[ ,"t_stage"] <- mergeFinalCol(finalPdata[ ,"t_stage"], 
                                         selColData(outPdata[ ,"pathologic t stage"], tStageReg)
)
summaryVec(outPdata$`pathologic n stage`, Inf, in.stop = F)
finalPdata[ ,"n_stage"] <- mergeFinalCol(finalPdata[ ,"n_stage"], 
                                         selColData(outPdata[ ,"pathologic n stage"], nStageReg)
)

summaryVec(outPdata$`figo stage`, Inf, in.stop = F)
finalPdata[ ,"figo_stage"] <- selColData(outPdata[ ,"figo stage"], "[0-4]([a-c]){0,1}", in.exact.flag =  T)


summaryVec(outPdata$`gender`, Inf, in.stop = F)
tmp1 <- selColData(outPdata[ ,"gender"], '(f|female|m|male)')
tmp2 <- selColData(outPdata[ ,"sex"], '(f|female|m|male)')
finalPdata[ ,"gender"] <- mergeFinalCol(tmp1, tmp2)

summaryVec(outPdata$`age`, Inf, in.stop = F)
finalPdata[ ,"age_yrs_month"] <- selColData(outPdata[ ,"age"], "\\d{1,3}yrs.*?\\d{1,2}mos")
tmp1 <- selColData(outPdata[ ,"age"], "\\d{1,3}(\\.\\d{1,})?", in.exact.flag =  T)
tmp2 <- selColData(outPdata[ ,"age (yrs) at rrp"], "\\d{1,3}(\\.\\d{1,})?")
finalPdata[ ,"age"] <- mergeFinalCol(tmp1, tmp2)


summaryVec(outPdata$`tissue`, Inf, in.stop = F)
tissueChar <- paste(withSepWord("adrenal"),withSepWord("adrenocortical"),
                    withSepWord("brain"),
                    withSepWord("breast"),
                    withSepWord("lung"), withSepWord("bronchus"),
                    withSepWord("kidney"), withSepWord("renal"),
                    withSepWord("colonic"), withSepWord("colorectal"),
                    withSepWord("gastric"),
                    withSepWord("ovarian"), withSepWord("ovary"), withSepWord("ovca"), withSepWord("ovcas"),
                    withSepWord("lymph"),withSepWord("lymphnode"),
                    withSepWord("medulloblastoma"),
                    withSepWord("melanoma"),
                    withSepWord("nsclc"),
                    withSepWord("bladder"),
                    withSepWord("prostate"),
                    withSepWord("pancreatic"),
                    sep = "|")

tmp1 <- selColData(outPdata[ ,"tissue"], tissueChar)
tmp2 <- selColData(outPdata[ ,"source_name_ch1"], tissueChar)
finalPdata[ ,"tissue"] <- mergeFinalCol(tmp1, tmp2)

tmp3 <- selColData(outGseTitleSummary[ ,"title"], tissueChar)
tmp3 <- data.frame(gse.name = outGseTitleSummary$gse.name , title = tmp3)
tmp3 <- merge(outPdata[ ,c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE)], tmp3, by.x = COL_NAME_GSE_NUM, by.y = "gse.name" , all.x = T)
tmp3 <- tmp3[match(outPdata[ ,COL_NAME_GEO_SAMPLE], tmp3[ ,COL_NAME_GEO_SAMPLE]), ]
finalPdata[ ,"tissue"] <- mergeFinalCol(finalPdata[ ,"tissue"], tmp3[ , "title"])

summaryVec(finalPdata$`tissue`, Inf, in.stop = F)
rowOfNoTissueData <- which(is.na(finalPdata[ ,"tissue"]))

# print(unique(outPdata[outPdata[ , COL_NAME_GEO_SAMPLE] %in% tmpFindTissueData, "tissue"]))
# print(unique(outPdata[outPdata[ , COL_NAME_GEO_SAMPLE] %in% tmpFindTissueData, "source_name_ch1"]))

for (tmpGseNum in unique(finalPdata[rowOfNoTissueData, COL_NAME_GSE_NUM])) {
  tmpGseTitleSummary <- findGseTitleSummary(tmpGseNum)
  tmpTitleData <- selColData(tolower(tmpGseTitleSummary$title), tissueChar)
  if (!is.na(tmpTitleData) && (length(tmpTitleData) == 1)) {
    finalPdata[intersect(which(finalPdata[ ,COL_NAME_GSE_NUM] == tmpGseNum),  rowOfNoTissueData), "tissue"] <- tmpTitleData
  } else {
    tmpSummaryData <- selColData(tolower(tmpGseTitleSummary$summary), tissueChar)
    if (!is.na(tmpSummaryData) && (length(tmpSummaryData) == 1)) {
      finalPdata[intersect(which(finalPdata[ ,COL_NAME_GSE_NUM] == tmpGseNum),  rowOfNoTissueData), "tissue"] <- tmpSummaryData
    }    
  }
}


summaryVec(outPdata$`tissue type`, Inf, in.stop = F)
normalCancerChar <- paste(withSepWord("healthy"), withSepWord("normal"), 
                          withSepWord("tumor"), withSepWord("tumour"), withSepWord("tumors"), 
                          withSepWord("cancer"), withSepWord("\\w+oma"), withSepWord("\\w+omas"), withSepWord("nsclc"),
                          withSepWord("metastasis"),
                          sep = "|")

tmp1 <- selColData(outPdata[ , "tissue type"], normalCancerChar)
tmp2 <- selColData(outPdata[ , "tissue"], normalCancerChar)

finalPdata[ ,"cancer.or.tumor"] <- mergeFinalCol(tmp1, tmp2)
finalPdata[which(outPdata[ , "cancer"] == T), "cancer.or.tumor"] = 'cancer'

tmp <- which(is.na(finalPdata[ ,"cancer.or.tumor"]))
finalPdata[tmp ,"cancer.or.tumor"] <- selColData(outPdata[tmp, "source_name_ch1"], normalCancerChar)

tmp <- which(is.na(finalPdata[ ,"cancer.or.tumor"]))
print(unique(outPdata[tmp, COL_NAME_GSE_NUM]))

for (tmpGseNum in unique(outPdata[tmp, COL_NAME_GSE_NUM])) {
  tmpGseTitleSummary <- findGseTitleSummary(tmpGseNum)
  tmpTitleData <- selColData(tolower(tmpGseTitleSummary$title), normalCancerChar)
  if (!is.na(tmpTitleData) && (length(tmpTitleData) == 1)) {
    finalPdata[which(finalPdata[ ,COL_NAME_GSE_NUM] == tmpGseNum), "cancer.or.tumor"] <- tmpTitleData
  } else {
    tmpSummaryData <- selColData(tolower(tmpGseTitleSummary$summary), normalCancerChar)
    if (!is.na(tmpSummaryData) && (length(tmpSummaryData) == 1)) {
      finalPdata[which(finalPdata[ ,COL_NAME_GSE_NUM] == tmpGseNum), "cancer.or.tumor"] <- tmpSummaryData
    }
  }
}


gleasonChar4Column <- selColData(colnames(outPdata), 'gleason score')
finalPdata[, "gleason score"] <- outPdata[ ,which(!is.na(gleasonChar4Column))]

summaryVec(outPdata$`histology`, Inf, in.stop = F)




gleasonChar4Column <- selColData(colnames(outPdata), 'gleason score')
finalPdata[, "gleason score"] <- outPdata[ ,which(!is.na(gleasonChar4Column))]

statusChar <-  paste0('(', 'alive|0',
                      '|', 'alive no evidence of disease|ned|ned (no evidence of disease)|no evidence of disease (ned)',
                      '|', 'alive with disease (awd)|awd',
                      '|', 'deceased|1|death',
                      '|', 'dead of disease (dod)|death related to cancer',
                      '|', 'death unrelated to cancer',
                      ')')
tmp1 <- selColData(outPdata[ ,"patient's status"], statusChar)
tmp2 <- selColData(outPdata[ ,"status"], statusChar)
finalPdata[ ,"status"] <- mergeFinalCol(tmp1, tmp2)

cancerChar4Column <- selColData(colnames(outPdata), 'cancer specific death')
finalPdata[ ,'cancer specific death'] <- outPdata[ ,which(!is.na(cancerChar4Column))]


finalPdata[ , 'psa (ng/ml) at rrp'] <- outPdata[ , 'psa (ng/ml) at rrp']
finalPdata[ , 'ploidy'] <- outPdata[ , 'ploidy']

finalPdata[ , 'er'] <- outPdata[ , 'er']
finalPdata[ , 'er'] <- mergeFinalCol(finalPdata[ , 'er'], outPdata[ , "estrogen receptor (er) status"])


finalPdata[ , 'first rising psa (ng/ml)'] <- outPdata[ , 'first rising psa (ng/ml)']
finalPdata[ , 'time (yrs) from rrp to first rising psa'] <- outPdata[ , 'time (yrs) from rrp to first rising psa']
finalPdata[ , 'second rising psa (ng/ml)'] <- outPdata[ , 'second rising psa (ng/ml)']
finalPdata[ , 'time (yrs) from rrp to second rising psa'] <- outPdata[ , 'time (yrs) from rrp to second rising psa']

finalPdata[ , 'cancer size'] <- outPdata[ , 'size']

for (uniqueGseName in unique(finalPdata$`gse name`)) {
  cat(uniqueGseName, ":", unique(finalPdata[finalPdata$`gse name` == uniqueGseName,'tissue']), '\n')
}

save.image(file = "../tmpData/20150807_arrangeStageFeature.RData")

