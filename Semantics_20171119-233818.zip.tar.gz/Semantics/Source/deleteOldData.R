args <- commandArgs(trailingOnly=TRUE)
userName <- args[1]

source('/home/bike/Semantics/Source/commonFunc.R')

catE(const_path_root_old)
listFileToDelete <- listFilesOnly(const_path_root_old)
for (i in listFileToDelete) {
  catE(i)
  file.remove(fitFilePath(const_path_root_old, i))  
}

