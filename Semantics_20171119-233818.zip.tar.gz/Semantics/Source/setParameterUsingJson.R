source("commonFunc.R")

x <- list( 
flag_TCGAData = TRUE,
# tmpGeneName = "ESR1",
tmpGeneName = "AR",
flag_groupByStr = FALSE,
group1Str = "er is pos",
group2Str = "er is neg",
flag_continuousFeature = TRUE,
vecContinuousFeature = 'age',
flag_survivalFeature = FALSE,
colSurvivalTime = "recur free survival time",
colSurvivalEvent = "recur free event"
)

writeJsonCNewLine(x, in_file_path = "test.json")

x <- iris[1:5, ]

writeJsonCNewLine(x, in_file_path = "test2.json")

jsonlite::fromJSON("test2.json")

x <- 10

writeJsonCNewLine(x, in_file_path = "test3.json")

jsonlite::fromJSON("test3.json")
