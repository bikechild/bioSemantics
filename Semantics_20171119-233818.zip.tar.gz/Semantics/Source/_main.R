args <- commandArgs(trailingOnly=TRUE)
userName <- args[2]

cat(getwd())

source('/home/bike/Semantics/Source/commonFunc.R')
library("jsonlite")

setScriptArg()

catE("_main.R ", args[1]," " , args[2], " ", strftime(Sys.time(),"%Y-%m-%d %H:%M:%S"))

sinkFile <- file(commandLogFile, open = "at")
sink(sinkFile)
sink(file = sinkFile, type = "message")

tryCatch({
    jsonData <- tryInf(jsonlite::fromJSON(const_MainJson))
    
    for (i in names(jsonData)) {
        assign(i, jsonData[[i]])
    }  
    
    if (args[1] == 'download') {
        commandToShiny(0, args[1], "Download is Started", jsonMain2Shiny)
        dir.create(const_path_root_new, showWarnings = FALSE, recursive = TRUE)
        
        if (flag_TCGAData) {
            source("TCGA.R")
            catE(shiny_tcgaSel)
            makeDataTcga(shiny_tcgaSel)
        } else {
            source("downloadGeoData.R")
        }
        commandToShiny(0, args[1], "gData is processing", jsonMain2Shiny)    
        source("gData.R")
        
        commandToShiny(1, args[1], "ended", jsonMain2Shiny)
    } else if (args[1] == 'filterFeature') {
        commandToShiny(0, args[1], "filterFeature is started", jsonMain2Shiny)
        if (file.exists(const_old_pathFileInitialConversionTable)) {
            file.copy(const_old_pathFileInitialConversionTable, const_pathFileInitialConversionTable)
        } else {
            source("makeInitialConversionTables.R")
        }
        
        source("filterFeatureData.R")
        commandToShiny(0, args[1], "filterFeatureData.R is processed", jsonMain2Shiny)
        
        if (length(listFilesOnly(const_path_root_old)) != 0) {
            source("mergeNewAndOld.R")
            commandToShiny(0, args[1], "mergeNewAndOld.R", jsonMain2Shiny)
        }    
        moveFiles(const_path_root_new, const_path_root_old)
        commandToShiny(2, args[1], "ended", jsonMain2Shiny)
    } else if (args[1] == 'analyze') {
        commandToShiny(0, args[1], "Analyze is started", jsonMain2Shiny)
        source("analysisUsingPhenotypeAndGenoType.R")
        if (file.exists(const_shinyZipFilePath)) {
            file.remove(const_shinyZipFilePath)
        }
        zip(const_shinyZipFilePath, fitFilePath(const_docPathSub), "-r9Xj")
        removeFilesInDir(const_docPathSub)
        commandToShiny(3, args[1], "ended", jsonMain2Shiny)
    } else {
        stop("args is not fit!") 
    }
}, error = function(e) {
    print(paste("MY_ERROR: ", e))
    commandToShiny(-1, args[1], 'failed', jsonMain2Shiny)
})

sink(type = "message")
sink()
close(sinkFile)

catE("Ended. ",  strftime(Sys.time(),"%Y-%m-%d %H:%M:%S"))

readline("Pause...")
