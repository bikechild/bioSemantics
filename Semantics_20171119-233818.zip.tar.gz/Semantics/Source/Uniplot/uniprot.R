library(data.table)

uniplotIDVector <- c()
data <- fread("C:\\Users\\feel\\Downloads\\uniprot_sprot.dat\\uniprot-all.txt",sep='\n',header = F)

percentSave <- 0
trigID <- FALSE
timeStart <- proc.time()
saveLine <- dim(data)[1]
for (tmp.line in 1:saveLine) {
  if(trigID == F){
    if(grepl("^ID",data[tmp.line]) == T){
      trigID <- T
    }
  } else {
    if(grepl("^AC",data[tmp.line]) == T){
      uniplotIDVector <- c(uniplotIDVector,sub("^AC\\s*(\\w+)\\;.*$","\\1",data[tmp.line]))
    } 
    trigID <- F
  }
  if(round(tmp.line* 100 / saveLine) != percentSave){
    percentSave <- round(tmp.line* 100 / saveLine)
    cat(percentSave,"% elapsed\n")
    timeCont <- proc.time() - timeStart
    cat("Time:",round(timeCont['elapsed']/60),' min\n')
  }
}



library(biomaRt)
# Define biomart object
mart <- useMart(biomart="ensembl", dataset="hsapiens_gene_ensembl")

# listAttributes(mart)
# listFilters(mart)

results <- getBM(attributes = c("uniprot_swissprot","hgnc_symbol", "chromosome_name", "start_position", "end_position"),
                 filters = c("uniprot_swissprot"),
                 values = uniplotIDVector, 
                 mart = mart)
write.csv(results,file="C:\\Users\\feel\\Downloads\\uniprot_sprot.dat\\output.csv")
