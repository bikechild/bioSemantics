# -*- coding: utf-8 -*-

import os
import codecs

maxLines = 10000
filepath = "D:/BioDatabase/UMLS_SNOMEDCT raw"
#filename = "uniprot_sprot.dat"
filename = "2014ab-1-meta.nlm"
filepathname, fileext = os.path.splitext(os.path.join(filepath,filename))
filepathnameForOut = filepathname + "_header"

#with open(os.path.join(filepath, filename)) as f:
with codecs.open( os.path.join(filepath, filename), "r", "utf-8" ) as f:
    with open(filepathnameForOut + fileext, 'w') as f_w:
        for tmplineNum, tmplines in enumerate(f):
            if tmplineNum > maxLines:
                break
            f_w.write( tmplines )

print("ENDED!")