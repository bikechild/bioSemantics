#Version History
# 0.01 started by childcom (2014/12/22)

rm(list = ls())
library(tools)

testFlag = F
strPath <- "D:\\bioSemantic\\uniprot_sprot.dat\\"
testFileName <- "uniprot_sprot_header.dat"
# realFileName <- "uniprot_sprot.dat"
# realSimpleFileName <- "uniprot_sprot_simple.dat"
realFileName <- "uniprot_trembl_human.dat"
realSimpleFileName <- paste0(file_path_sans_ext(realFileName), "_simple.", file_ext(realFileName))
outputFileName  <- paste0("uniplotDataTable_", file_path_sans_ext(realFileName), "_simple.csv")
dataList <- c("AC", "HGNC", "GeneID", "RefSeq", "Ensembl", "PDB", "EMBL")

library(data.table)
library(stringr)

uniplotIDVector <- c()
simpleGrepString <- "^(ID|AC|OX|DR)"

if(testFlag == T){
  rawData <- fread(paste0(strPath, testFileName),sep='\n',header = F)  
  data <- rawData[ grep(simpleGrepString ,unlist(rawData)) ]
  ncbiTaxID <- "654924"
} else {
  if ( file.exists(paste0(strPath, realSimpleFileName)) ) {
    data <- fread(paste0(strPath, realSimpleFileName),sep='\n',header = F)  
  } else {
    rawData <- fread(paste0(strPath, realFileName),sep='\n',header = F)  
    data <- rawData[ grep(simpleGrepString ,unlist(rawData)) ]
    rm(rawData)
    write.table(data, file = paste0(strPath, realSimpleFileName), row.names= F, col.names = F,  quote = F)    
  }
  ncbiTaxID <- "9606"
}


data4ID <- data[ grep("^ID",unlist(data)) ]
reg4ID <- "^ID\\s*(\\w+?)\\s.*$"
rownameOfSaveData <- sub(reg4ID,"\\1", unlist(data4ID))
data4OX <- data[ grep("^OX",unlist(data)) ]
if(length(data4ID) !=length(data4OX)){
  stop("length(data4ID) !=length(data4OX)")
}
ncbiVector4SelectedSpecies <- (sub("^OX\\s*NCBI_TaxID\\=(\\d*).*$","\\1", unlist(data4OX)) == ncbiTaxID)
rownameOfSaveData <- rownameOfSaveData[ncbiVector4SelectedSpecies]

saveData <- as.data.frame(matrix("", nrow = length(rownameOfSaveData),ncol= length(dataList), dimnames = list(rownameOfSaveData, dataList)))

percentSave <- 0
trigID <- F
personData <- F
timeStart <- proc.time()
saveLine <- dim(data)[1]

print("Starting")
for (tmp.line in 1:saveLine) {
  dataTempLine <- data[tmp.line]
  lineHeader <- sub("^((\\w|/){2}).*$","\\1",dataTempLine)
  
  if( lineHeader == "ID" ){
    rowname4dataTempLine <- sub(reg4ID,"\\1", dataTempLine)
    if( rowname4dataTempLine %in% rownameOfSaveData ){
      trigID <- T
    } else {
      trigID <- F
    }
  } else if(trigID == T) {
    if (lineHeader == "AC") {
      saveData[rowname4dataTempLine, "AC"] <- sub("^AC\\s*(\\S+.*)$","\\1", dataTempLine)
    } else if (lineHeader == "DR") {
      regStr4DR <- "^DR\\s*((\\w|-)*?)\\;(.*)$"
      tmpDataList <- sub(regStr4DR,"\\1", dataTempLine)
      if(tmpDataList %in% dataList) {
        tmpData4DR <- str_trim(sub(regStr4DR,"\\3", dataTempLine))
        beforeSaveData <- saveData[rowname4dataTempLine, tmpDataList]
        if(nchar( beforeSaveData) == 0){
          saveData[rowname4dataTempLine, tmpDataList] <- tmpData4DR
        } else {
          saveData[rowname4dataTempLine, tmpDataList] <- paste0(beforeSaveData,";",tmpData4DR)
        }
      }
    }
  }
    

  if(round(tmp.line* 100 / saveLine) != percentSave){
    percentSave <- round(tmp.line* 100 / saveLine)
    timeCont <- proc.time() - timeStart
    cat("\r",paste0(rep(" ",120),collapse = ""));cat("\r", percentSave,"% elapsed Time:",round(timeCont['elapsed']/60),' min')
  }
}

write.csv(saveData, file=paste0(strPath, outputFileName) )
