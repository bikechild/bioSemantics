library(data.table)

strPath <- "D:\\bioSemantic\\uniprot_sprot.dat\\"

uniplotIDVector <- c()

testFlag = F
if(testFlag == T){
  rawData <- fread(paste0(strPath,"uniprot_sprot_header.dat"),sep='\n',header = F)  
  ncbiTaxID <- "654924"
} else {
  rawData <- fread(paste0(strPath,"uniprot_sprot.dat"),sep='\n',header = F)  
  ncbiTaxID <- "9606"
}

data <- rawData[ grep("^(ID|AC|OX|//|DR)",unlist(rawData)) ]

saveData <- vector()

percentSave <- 0
trigID <- F
personData <- F
timeStart <- proc.time()
saveLine <- dim(data)[1]

for (tmp.line in 1:saveLine) {
  if(trigID == F){
    if(grepl("^ID",data[tmp.line]) == T){
      trigID <- T
    }
  } else {
    if(grepl("^OX",data[tmp.line]) == T){
      if( sub("^OX\\s*NCBI_TaxID\\=(\\d*?)\\;.*$","\\1",data[tmp.line]) == ncbiTaxID ){
        personData <- T
      }
    }
    if(personData == T & grepl("^DR",data[tmp.line]) == T) {
      saveData <- union(saveData,sub("^DR\\s*((\\w|-)*?)\\;.*$","\\1",data[tmp.line]))
      
    } 
    
    if(grepl("^//",data[tmp.line]) == T){
      trigID <- F
      personData <- F      
    }
  }
  if(round(tmp.line* 100 / saveLine) != percentSave){
    percentSave <- round(tmp.line* 100 / saveLine)
    cat(percentSave,"% elapsed\n")
    timeCont <- proc.time() - timeStart
    cat("Time:",round(timeCont['elapsed']/60),' min\n')
  }
}

write.csv(saveData, file=paste0(strPath,"uniplotDRList.csv") )
