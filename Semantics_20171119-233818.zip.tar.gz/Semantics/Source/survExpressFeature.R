library(stringr)

con <- file("D:/BioSemantic/Data/20150612_survExpress_feature.txt" , open = 'r')
a <- readLines(con)
close(con)

b <- strsplit(a,",")
tmp2 <- c()
for(tmp in b){
  tmp2 <-unique(c(tmp2, tolower(trimws(tmp))))
}
tmp2 <- tmp2[tmp2!=""]

sort(tolower(str_replace_all(tmp2, "\\s{1,}"," ")))
