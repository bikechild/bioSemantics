library(shinydashboard)
library(DT)
library(shinyjs)

fitBox <- function(...){
  fluidRow(
    column(width = 12, ...)
    )
}


actionButtonInThis <- function(..., label = ""){
  actionButton(..., label = strong(label), icon = icon("chevron-right"))
}

dashboardPage(
  dashboardHeader(title = "GSE Merger"),
  dashboardSidebar(
      includeCSS("www/no_select.css"),          
    sidebarMenu(
      menuItem("Download GSE", tabName = "downloadGSE", icon = icon("download"), selected = T),
      menuItem("Fit Feature", tabName = "fitFeature", icon = icon("gears")),
      menuItem("Analysis Data", tabName = "Analysis_Data", icon = icon("file-text")),
      menuItem("Analysis Data By Phenotypes", tabName = "Analysis_Gene_By_Multiple_Phenotype", icon = icon("file-text")),
      menuItem("List Feature & Gene", tabName = "list_feature_list", icon = icon("list-alt")),
      infoBoxOutput("progressBox", width = 12),
      column(width = 12, box(
        width = NULL, background = "maroon",
        h5(textOutput("progressBox_title")),
        h6(textOutput("progressBox_value"))
      ))
    ),
    uiOutput("userpanel")
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "downloadGSE",
        fluidRow(
          box(title = "Input",
              status = "info",
              solidHeader = TRUE,
              width = 12,
              useShinyjs(),
              shinyjs::hidden( # temporary hide tcga analysis tools
                radioButtons("Data_Sel", label = h5(strong("Data Sel")),
                             choices = list("GSE Download" = "GSE", "TCGA" = "TCGA"),
                             selected = "GSE", inline = TRUE)
              ),
              div(id = "Input_GSE_div",
                  fitBox(strong(h4("Input GSE"))),
                  fitBox(tags$style(type="text/css",
                                    'textarea {width:100%; display: block; margin-left: auto; margin-right: auto; color:#000000}'),
                         tags$textarea(id="gsea_list", rows=10, cols = "")
                         ),
                  h6("")
                  ),
              div(id = "Input_TCGA_div",
                  fitBox(
                    selectInput("select_tcga", label = h5("Select TCGA"), choices = "test")
                  ),
                  h6("")
                  ),
              fitBox(actionButtonInThis("action", label = "Download"))
              )
          )
        ),
      tabItem(
        tabName = "fitFeature",
        fitBox(
          actionButtonInThis("action_delete_old_data", label = "Reset Before Data"),
          h6("")
          ),
        fluidRow(
          box(title = "Data List Arranged",
              width = 12,
              status = "info",
              solidHeader = TRUE,
              textOutput("Data_List_Arranged")
              )
          ),
        fluidRow(
          box(title = "Data List before arranged",
              width = 12,
              status = "info",
              solidHeader = TRUE,
              textOutput("Data_List_before_Arranged")
              )
          ),
        fitBox(
          actionButtonInThis("Select_Feature_and_Merge", label = "Select Feature and Merge"),
          h6("")
        ),
        fluidRow(
          div(
            id = "Select_Features_outer",
            box(
              title = 'Select Features',
              id ="Select_Features",
              width = 12,
              height = "100%",
              solidHeader = TRUE,
              status = "warning",
              div(id = "Select_Features_panel",
                  h3(textOutput("select_features_text_name")),
                  h5(verbatimTextOutput("select_features_text_feature")),
                  dataTableOutput('select_features_text'),
                  actionButtonInThis("select_features_text_pass", label = "Pass"),
                  actionButtonInThis("select_features_text_pass_all", label = "Pass All")
                  )
              )
            )
          )
        ),
      tabItem(
        tabName = "Analysis_Data",
        fluidRow(
            tabBox(
                title = "Group Selection",
                width = 12,
                # The id lets us use input$tabset1 on the server to find the current tab
                id = "group_select",
                tabPanel("Group By String",
                         textInput("groupByStr_group_1", "Group 1: ", value = "er is pos"),
                         textInput("groupByStr_group_2", "Group 2:", value = "er is neg")
                         ),
                tabPanel("Group By Continuous",
                         textInput("groupByCont_var", "Continuous Feature: ", value = "age")
                         ),
                tabPanel("Group By Survival",
                         textInput("groupBySurvival_Event", "Survival Event: ", value = "recur free event"),
                         textInput("groupBySurvival_Time", "Survival Time: ", value = "recur free survival time")
                         ),
                tabPanel("Group By Manual",
                         actionButton("button_A", "Group A"),
                         actionButton("button_B", "Group B"),
                         actionButton("button_clear", "Clear"),                         
                         DT::dataTableOutput('tblPhenotypeData')
                         )
                )
            ),
        fluidRow(
          div(id = "feature_input_to_cutoff_box_outer",
              box(
                title = 'Feature to calculate cut-off',
                status = "primary",
                solidHeader = TRUE,
                width = 12,
                textInput("variable_list", "Variable List", value = "AR"),
                checkboxInput("all_gene_variable_list", label = "Analysis All Gene?", value = FALSE)
                )
              )
        ),
        fitBox(
            actionButtonInThis("Run_Analysis", label = "Run Analysis"),
            h6()
        ),
        fluidRow(
          box(
            title = 'Download Link',
            status = "primary",
            solidHeader = TRUE,
            width = 12,
            shinyjs::hidden(div(id = "downloadData",
                                # shiny::a("click on me", id = "click_on_me", href = const_shinyZipFile))                                
                                htmlOutput('downloadDataLink')
                                )
                            )
            )
          )
      ),
      tabItem(tabName = "Analysis_Gene_By_Multiple_Phenotype",
              fluidRow(
                box(title = "Feature List",
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    textOutput("Feature_List_4_Multiple_Phenotype")
                )
              ),
              fitBox(
                actionButtonInThis("discriminate_features_automatically", label = "Discriminate Features Automatically"),
                h6()
              ),
              fluidRow(
                tabBox(
                  title = "Feature Input",
                  width = 12,
                  # The id lets us use input$tabset1 on the server to find the current tab
                  id = "group_select_By_Multiple_Phenotype",
                  tabPanel("Continuous Feature",
                           textInput("variable_list_Multiple_Phenotype", "", value = ""),
                           actionButtonInThis("Add_Multiple_Phenotype_Continuous", label = "Add")
                           ),
                  tabPanel("Survival Feature",
                           textInput("Survival_Event_Multiple_Phenotype", "Survival Event: ", value = "recur free event"),
                           textInput("Survival_Time_Multiple_Phenotype", "Survival Time: ", value = "recur free survival time"),
                           actionButtonInThis("Add_Multiple_Phenotype_Survival", label = "Add")
                           ),
                  tabPanel("Category Feature",
                           textInput("category_feature_multiple_phenotype", "", value = ""),
                           actionButtonInThis("add_multiple_phenotype_category", label = "Add")
                           )
                  )
                ),
              fluidRow(
                box(title = "Remove Feature",
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    textInput("feature_to_remove", "", value = ""),
                    actionButtonInThis("remove_feature", label = "Remove")
                    )
                ),
              fluidRow(
                box(title = "Feature List To Anlysis",
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    h5(strong("Continuous Features:")),
                    textOutput("Multiple_Phenotype_Continuous_Feature_List"),
                    h5(strong("Survival Features:")),
                    textOutput("Multiple_Phenotype_Survival_Feature_List"),
                    h5(strong("Catetory Features:")),
                    textOutput("Multiple_Phenotype_Category_Feature_List")
                    )
                ),
              fluidRow(
                box(title = "Gene List",
                    width = 12,
                    status = "info",
                    solidHeader = TRUE,
                    textInput("gene_list_multiple_phenotype", "", value = "")
                )
              ),              
              fitBox(
                actionButtonInThis("analysis_data_by_phenotype", 
                                   label = "Analysis"
                                   ),
                h6()
                )
              ),
      tabItem(tabName = "list_feature_list",
        fluidRow(
          box(title = "Feature List",
              width = 12,
              status = "info",
              solidHeader = TRUE,
              textOutput("Feature_List")
              )
          ),
        fluidRow(
          box(title = "Gene List",
              width = 12,
              status = "info",
              solidHeader = TRUE,
              textOutput("Gene_List")
              )
          )
        )
      )
    )
  )
