testText <-
"GSE2990
GSE3494
GSE6532
GSE12093
GSE9195
GSE16391
GSE17705
GSE19615"

library(shiny)
library(shinyjs)


jsonResetFeatureShiny <- function(in_jsonFeature2Shiny, in_jsonShiny2Feature){
  tmp <- list()
  tmp$state <- 0
  tmp$df <- data.frame()
  writeJsonCNewLine(tmp, in_jsonFeature2Shiny)
  writeJsonCNewLine(0, in_jsonShiny2Feature)  
}


resetEvent <- function(in_jsonMain2Shiny) {
  commandToShiny(0, '_', 'Initialized', in_jsonMain2Shiny)
}


writeFeatureListToAnlysis <- function(output) {
  output$Multiple_Phenotype_Continuous_Feature_List <- 
    renderText({paste(multiplePhenotypeContinuousFeatureList, collapse = ", ")})
  out_string <- ""
  if (nrow(multiplePhenotypeSurvivalFeatureList) != 0) {
    for (i in 1:nrow(multiplePhenotypeSurvivalFeatureList)) {
      out_string <- out_string %+% "(" %+% multiplePhenotypeSurvivalFeatureList[i, "time"] %+% ", " %+%
        multiplePhenotypeSurvivalFeatureList[i, "event"] %+% ")\n"
    }    
  }
  print(out_string)
  output$Multiple_Phenotype_Survival_Feature_List <- renderText({out_string})
  
  output$Multiple_Phenotype_Category_Feature_List <- 
    renderText({paste(multiplePhenotypeDiscreteFeatureList, collapse = ", ")})
}


shinyServer(function(input, output, session) {
  RV <- reactiveValues()
  RV$progress_box_text <- ""
  RV$progress_box_program_name <- ""
  
  RV$feature_df <- data.frame()
  RV$feature_of_feature_df <- ""
  RV$value_df_of_feature_df <- data.frame()
  
  RV$data_list_arranged_value <- ""
  RV$data_list_before_arranged_value <- ""

  RV$data_list_feature_list <- c()
  RV$data_list_gene_list <- ""

  RV$group_a <- c()
  RV$group_b <- c()
  RV$select_page <- 0
  RV$drag_item <- c()
  
  set_xor <- function(in_x1, in_x2) {
      tmp1 <- setdiff(in_x1, in_x2)
      tmp2 <- setdiff(in_x2, in_x1)
      return(unique(c(tmp1, tmp2)))
  }
  
  observeEvent(input$tbMouseClicked, {
      if (input$tbMouseClicked == 1) {
          RV$drag_item <- set_xor(RV$drag_item, input$hoverIndexJS + 1)
      } else {
          output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData(RV$drag_item)}, server = FALSE, 
                                                         options = list(stateSave = TRUE))
      }
  })
  
  observeEvent(input$hoverIndexJS, {
      if (!is.null(input$tbMouseClicked)) {
          if (input$tbMouseClicked == 1) {
              RV$drag_item <- set_xor(RV$drag_item, input$hoverIndexJS + 1)
              output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData(RV$drag_item)}, server = FALSE, 
                                                             options = list(stateSave = TRUE))
          }
      }
  })  
  
  observe({
      if (is.null(input$tblPhenotypeData_rows_current[1])) {
          RV$select_page <- 0
      } else {
          RV$select_page <- input$tblPhenotypeData_rows_current[1] - 1                        
      }
  })
  
  multiplePhenotypeContinuousFeatureList <- c()
  multiplePhenotypeDiscreteFeatureList <- c()
  multiplePhenotypeSurvivalFeatureList <- 
    as.data.frame(matrix(0, nrow = 0, ncol = 2, dimnames = list(NULL, c("event", "time")) ) )
  
  source('/home/bike/Semantics/Source/commonFunc.R', local = TRUE)
  
  const_summaryPDataFile <<- ''
  
  writeDataList <- function(in_path_old_arrangePDataFile, 
                            in_path_old_summaryGDataFile, 
                            in_path_summaryPDataFile) {
    
    if (file.exists(in_path_old_arrangePDataFile)) {
      old_arrangePData <- readRDS(in_path_old_arrangePDataFile)
      
      RV$data_list_arranged_value <<- paste(unique(old_arrangePData[ ,COL_NAME_GSE_NUM]), collapse = " ")          
      
      tmp <- setdiff(colnames(old_arrangePData),
                     c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE, COL_NAME_PLATFORM_ID))
      RV$data_list_feature_list <<- tmp
    } else {
      RV$data_list_arranged_value <<- ""
    }
    if (file.exists(in_path_summaryPDataFile)) {
      tmp <- readRDS(in_path_summaryPDataFile)
      RV$data_list_before_arranged_value <<- paste(unique(tmp[ ,COL_NAME_GSE_NUM]), collapse = " ")          
    } else {
      RV$data_list_before_arranged_value <<- ''
    }
    
    if (file.exists(in_path_old_summaryGDataFile)) {
      tmpData <- readRDS(in_path_old_summaryGDataFile)
      tmp <- NA
      for (i in names(tmpData)) {
        tmpGeneList <- rownames(tmpData[[i]])
        if (all(is.na(tmp))) {
          tmp <- tmpGeneList
        } else {
          tmp <- intersect(tmp, tmpGeneList)    
        }
      }
      RV$data_list_gene_list <<- paste(tmp, collapse = ", ")
    }
  }
  
    plot_tblPhenotypeData <- function(in_selected = NULL) {
    # cars %>% datatable(options = list("scrollY" = "50vh", "scrollCollapse" = TRUE, "paging" = FALSE)) %>%
        if (!file.exists(const_old_arrangePDataFile)) {
            rtn_datatable <- NULL
        } else {
            tmp <- readRDS(const_old_arrangePDataFile)
            rtn_datatable <- tmp %>% datatable(options = list(displayStart = RV$select_page, scrollX = TRUE),
                                                selection = list(mode = 'multiple', selected = in_selected),
                                                callback =  JS("
                                                               /* code for hover */
                                                               table.on('mouseenter', 'td', function() {
                                                               var info_out = table.cell( this ).index().row;
                                                               Shiny.onInputChange('hoverIndexJS', info_out);
                                                               });
                                                               /* code on click */
                                                               table.on('mousedown', 'td', 
                                                               function() {
                                                               var info_out = table.cell( this ).index().row;
                                                               Shiny.onInputChange('dblclickIndexJS', info_out);
                                                               Shiny.onInputChange('tbMouseClicked', 1);
                                                               }
                                                               );
                                                               /* code on click end */
                                                               table.on('mouseup', 'td', function() {
                                                               var info_out = table.cell( this ).index().row;
                                                               Shiny.onInputChange('clickIndexJS', info_out);
                                                               Shiny.onInputChange('tbMouseClicked', 0);
                                                               });"
                           ))
            if ((length(RV$group_a) != 0) || (length(RV$group_b) != 0)) {
                rtn_datatable <- rtn_datatable %>% 
                    DT::formatStyle(0, target = "row",
                                    backgroundColor = DT::styleEqual(
                                        c(RV$group_a, RV$group_b),
                                        c(rep("red", length(RV$group_a)), rep("green", length(RV$group_b)))
                                        )
                                    )
            }            
        }
        return(rtn_datatable)
    }
  observeEvent(input$button_A, {
      RV$group_a <<- unique(c(RV$group_a, input$tblPhenotypeData_rows_selected))
      RV$group_b <<- setdiff(RV$group_b, RV$group_a)
      output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData()}, server = FALSE, 
                                                     options = list(stateSave = TRUE))
      output$for_debug <- renderText('hahaha')
      RV$drag_item <<- c()
  })    
  observeEvent(input$button_B, {
      RV$group_b <<- unique(c(RV$group_b, input$tblPhenotypeData_rows_selected))
      RV$group_a <<- setdiff(RV$group_a, RV$group_b)
      output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData()}, server = FALSE, 
                                                     options = list(stateSave = TRUE))
      output$for_debug <- renderText(RV$select_page)
      RV$drag_item <<- c()        
  })
  observeEvent(input$button_clear, {
      RV$group_a <<- setdiff(RV$group_a, input$tblPhenotypeData_rows_selected)        
      RV$group_b <<- setdiff(RV$group_b, input$tblPhenotypeData_rows_selected)
      output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData()}, server = FALSE, 
                                                     options = list(stateSave = TRUE))
      RV$drag_item <<- c()
  })  
  
  resetEvent(jsonMain2Shiny)
  writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)

  pathTcga <- read.csv(const_pathTcagCsv)
  vecTcgaData <-  pathTcga$cancer
  
  resetValue_const_MainJson <- list(
    flag_TCGAData = const_tcgaInitalValue,
    shiny_tcgaSel = vecTcgaData[1],
    tmpGeneName = "AR",  # tmpGeneName = "ESR1",
    flag_groupByStr = FALSE,
    group1Str = "er is pos",
    group2Str = "er is neg",
    flag_continuousFeature = TRUE,
    vecContinuousFeature = 'age',
    flag_survivalFeature = FALSE,
    colSurvivalTime = "recur free survival time",
    colSurvivalEvent = "recur free event",
    flag_group_by_selection = FALSE,
    group1_list = c(),
    group2_list = c(),
    flag_analysisPhenotypeMultiple = FALSE,
    flag_discreteFeature = FALSE,
    vecDiscreteFeature = "er"  
  )
  writeJsonCNewLine(resetValue_const_MainJson, in_file_path = const_MainJson)
  
  jsonResetFeatureShiny(jsonFeature2Shiny, jsonShiny2Feature)
  
  autoInvalidate <- reactiveTimer(100)
  
  updateTextAreaInput(session, 'gsea_list', value = testText)
  
  updateSelectInput(session, "select_tcga",
              choices = vecTcgaData,
              selected = vecTcgaData[2])
  
  output$tblPhenotypeData <- DT::renderDataTable({plot_tblPhenotypeData()}, server = FALSE, 
                                                 options = list(stateSave = TRUE))
  
  observeEvent(input$action, {
    resetEvent(jsonMain2Shiny)
    shinyjs::hide(id = "downloadData")
    write(input$gsea_list, const_GSEText)
    catE("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " download")
    system("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " download " %+% userName, wait = F, invisible = FALSE)
    writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)
  })
  
  observeEvent(input$action_delete_old_data, {
    system("Rscript " %+% fitFilePath(const_rootSource, "deleteOldData.R " %+% userName ), wait = T)
    writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)
  })
  observeEvent(input$Select_Feature_and_Merge, {
    catE("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " filterFeature")
    system("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " filterFeature "  %+% userName, wait = F, invisible = FALSE)
    writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)
  })  
  
  observeEvent(input$Data_Sel, {
    jsonData <- tryInf(jsonlite::fromJSON(const_MainJson))
    if(input$Data_Sel == "GSE"){
      shinyjs::show(id = "Input_GSE_div")
      shinyjs::hide(id = "Input_TCGA_div")
      jsonData['flag_TCGAData'] <- FALSE
    } else if(input$Data_Sel == "TCGA") {
      shinyjs::show(id = "Input_TCGA_div")
      shinyjs::hide(id = "Input_GSE_div")
      jsonData['flag_TCGAData'] <- TRUE
      jsonData['shiny_tcgaSel'] <- input$select_tcga
    }
    writeJsonCNewLine(jsonData, const_MainJson)
  })
  
  observeEvent(autoInvalidate(), {
    dataJson <- tryNa(jsonlite::fromJSON(jsonMain2Shiny))
    if (!all(is.na(dataJson))) {
      RV$progress_box_text <- dataJson$text
      RV$progress_box_program_name <- dataJson$programName
      
      if (dataJson$state != 0) {
        if (file.exists(const_shinyZipFilePath)) {
          shinyjs::show(id = "downloadData")
        }
      } else {
        shinyjs::hide(id = "downloadData")
      }
    }
    
    dataFeatureSelStatusShiny <- tryNa(jsonlite::fromJSON(jsonFeature2Shiny))
    if (!all(is.na(dataFeatureSelStatusShiny))) {
      if (dataFeatureSelStatusShiny$state == 1) {
        shinyjs::show(id = "Select_Features_outer", anim = T)
        RV$feature_df <<- dataFeatureSelStatusShiny$df
        RV$feature_of_feature_df <<- dataFeatureSelStatusShiny$feature
        RV$value_df_of_feature_df <<- dataFeatureSelStatusShiny$valueDf
        
      } else if (dataFeatureSelStatusShiny$state == 0) {
        shinyjs::hide(id = "Select_Features_outer", anim = T)        
      }
    }
    writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)
  })
  
  dfSel <- reactive({input$select_features_text_rows_selected})
  observeEvent(dfSel(), {
    catE(dfSel())
    writeJsonCNewLine(dfSel(), jsonShiny2Feature)
  })
  observeEvent(input$select_features_text_pass, {
    tmpValue <- -9
    catE(tmpValue)
    writeJsonCNewLine(tmpValue, jsonShiny2Feature)
  })
  observeEvent(input$select_features_text_pass_all, {
    tmpValue <- -1
    catE(tmpValue)
    writeJsonCNewLine(tmpValue, jsonShiny2Feature)
  })  
  
  output$select_features_text_name <- renderText({RV$feature_of_feature_df})
  output$select_features_text_feature <- renderPrint({RV$value_df_of_feature_df})
  
  output$select_features_text <- DT::renderDataTable({
    return(RV$feature_df)
  }, selection = "single", options = list(searching = 'false',
                                          stateSave = TRUE))
  
  observeEvent(input$group_select, {
    flag_groupBy <- input$group_select
    catE(flag_groupBy)
    if (flag_groupBy %in% c("Group By String", "Group By Manual")) {
      shinyjs::hide(id = "feature_input_to_cutoff_box_outer", anim = T)
    } else if (flag_groupBy %in% c("Group By Continuous", "Group By Survival")) {
      shinyjs::show(id = "feature_input_to_cutoff_box_outer", anim = T)
    }    
  })
  
  observeEvent(input$Run_Analysis, {
    flag_groupBy <- input$group_select
    jsonData <- tryInf(jsonlite::fromJSON(const_MainJson))
    if (input$all_gene_variable_list) {
      jsonData$tmpGeneName <- RV$data_list_gene_list
    } else {
      jsonData$tmpGeneName <- input$variable_list      
    }

    jsonData$flag_groupByStr <- FALSE
    jsonData$flag_continuousFeature <- FALSE
    jsonData$flag_survivalFeature <- FALSE
    jsonData$flag_group_by_selection <- FALSE
    
    if (flag_groupBy == "Group By String") {
      jsonData$flag_groupByStr <- TRUE
      jsonData$group1Str <- input$groupByStr_group_1
      jsonData$group2Str <- input$groupByStr_group_2
    } else if (flag_groupBy == "Group By Continuous") {
      jsonData$flag_continuousFeature <- TRUE
      jsonData$vecContinuousFeature <-  input$groupByCont_var
    } else if (flag_groupBy == "Group By Survival") {
      jsonData$flag_survivalFeature <- TRUE 
      jsonData$colSurvivalTime <- input$groupBySurvival_Time
      jsonData$colSurvivalEvent <- input$groupBySurvival_Event      
    } else if (flag_groupBy == "Group By Manual") {
        jsonData$flag_group_by_selection <- TRUE
        jsonData$group1_list <- isolate(RV$group_a)
        jsonData$group2_list <- isolate(RV$group_b)
    } else {
        stop('The flag of Run_Analysis was error')
    }
    jsonData$flag_analysisPhenotypeMultiple <- FALSE
    writeJsonCNewLine(jsonData, in_file_path = const_MainJson)
    
    catE("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " analyze")
    system("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " analyze " %+% userName, wait = F, invisible = FALSE)
  })
  
  observeEvent(input$Add_Multiple_Phenotype_Continuous, {
    candidate_phenotype <- input$variable_list_Multiple_Phenotype
    if ( candidate_phenotype %in% RV$data_list_feature_list ) {
      multiplePhenotypeContinuousFeatureList <<- 
        unique(c(candidate_phenotype, multiplePhenotypeContinuousFeatureList))
      catE(paste(multiplePhenotypeContinuousFeatureList, collapse = ", "))
      catE(candidate_phenotype)
    } else {
      catE(candidate_phenotype %+% "_")
    }
    writeFeatureListToAnlysis(output)
  })
  
  observeEvent(input$Add_Multiple_Phenotype_Survival, {
    candidate_survival_event <- input$Survival_Event_Multiple_Phenotype    
    candidate_survival_time <- input$Survival_Time_Multiple_Phenotype

    if ( candidate_survival_event %in% RV$data_list_feature_list &
         candidate_survival_time %in% RV$data_list_feature_list
         ) {
      candidate_survival_row <- data.frame(event = candidate_survival_event, time = candidate_survival_time)
      print(candidate_survival_row)
      if (nrow(merge(candidate_survival_row, multiplePhenotypeSurvivalFeatureList)) == 0) {
        multiplePhenotypeSurvivalFeatureList <<-
          rbind(multiplePhenotypeSurvivalFeatureList, candidate_survival_row)
        print(multiplePhenotypeSurvivalFeatureList)
      }
    } else {
      catE(candidate_phenotype %+% "_")
    }
    writeFeatureListToAnlysis(output)
  })  
  
  observeEvent(input$add_multiple_phenotype_category, {
    candidate_phenotype <- input$category_feature_multiple_phenotype    
    if ( candidate_phenotype %in% RV$data_list_feature_list ) {
      multiplePhenotypeDiscreteFeatureList <<- 
        unique(c(candidate_phenotype, multiplePhenotypeDiscreteFeatureList))
      catE(paste(multiplePhenotypeDiscreteFeatureList, collapse = ", "))
      output$Multiple_Phenotype_Category_Feature_List <- 
        renderText({paste(multiplePhenotypeDiscreteFeatureList, collapse = ", ")})
      catE(candidate_phenotype)
    } else {
      catE(candidate_phenotype %+% "_")
    }
    writeFeatureListToAnlysis(output)
  })  

  observeEvent(input$remove_feature, {
    candidate_remove_feature <- input$feature_to_remove    
    
    multiplePhenotypeContinuousFeatureList <<- 
      setdiff(multiplePhenotypeContinuousFeatureList, candidate_remove_feature)
    multiplePhenotypeDiscreteFeatureList <<- 
      setdiff(multiplePhenotypeDiscreteFeatureList, candidate_remove_feature)
    tmp_row_to_remove <- c()
    for (i in 1:nrow(multiplePhenotypeSurvivalFeatureList)) {
      if (candidate_remove_feature %in% unlist(multiplePhenotypeSurvivalFeatureList[i, ])) {
        tmp_row_to_remove <- c(tmp_row_to_remove, i)
      }
    }
    if (length(tmp_row_to_remove)>= 1) {
      multiplePhenotypeSurvivalFeatureList <<- multiplePhenotypeSurvivalFeatureList[-tmp_row_to_remove, ]
    }
    writeFeatureListToAnlysis(output)
  })        
  
  observeEvent(input$discriminate_features_automatically, {
    if (file.exists(const_old_arrangePDataFile)) {
      old_arrangePData <- readRDS(const_old_arrangePDataFile)
      RV$data_list_arranged_value <<- paste(unique(old_arrangePData[ ,COL_NAME_GSE_NUM]), collapse = " ")          
      tmp <- setdiff(colnames(old_arrangePData),
                     c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE, COL_NAME_PLATFORM_ID))
      RV$data_list_feature_list  <<- tmp
      tmp2 <- checkCategoryOrContinuousOfDf(old_arrangePData[ , tmp, drop = F], 2, 2)
      print(tmp2)
      multiplePhenotypeContinuousFeatureList <<- tmp2$coutinuous
      multiplePhenotypeDiscreteFeatureList <<- tmp2$category
      writeFeatureListToAnlysis(output)
    }
  })
  
  observeEvent(input$analysis_data_by_phenotype, {
    x <- list( 
      continuousFeatures = multiplePhenotypeContinuousFeatureList,
      discreteFeatures = multiplePhenotypeDiscreteFeatureList,
      survivalFeatures = multiplePhenotypeSurvivalFeatureList,
      genes = input$gene_list_multiple_phenotype
      )
    writeJsonCNewLine(x, in_file_path = const_MainPhenoLoopJson)

    jsonData <- tryInf(jsonlite::fromJSON(const_MainJson))
    jsonData$flag_analysisPhenotypeMultiple <- TRUE
    writeJsonCNewLine(jsonData, in_file_path = const_MainJson)    
        
    catE("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " analyze")
    system("Rscript " %+% fitFilePath(const_rootSource, "_main.R") %+% " analyze " %+% userName, wait = F, invisible = FALSE)    
  })
  
  output$progressBox_title <- renderText({RV$progress_box_program_name})
  output$progressBox_value <- renderText({RV$progress_box_text})

  output$Data_List_Arranged <- renderText({RV$data_list_arranged_value})
  output$Data_List_before_Arranged <- renderText({RV$data_list_before_arranged_value})

  dataListFeatureListText <- reactive({paste(RV$data_list_feature_list, collapse = ", ")})
  output$Feature_List <- renderText({dataListFeatureListText()})
  output$Feature_List_4_Multiple_Phenotype <- renderText({dataListFeatureListText()})
  
  output$Gene_List <- renderText({RV$data_list_gene_list})    

  loginPopup <- function() {
    modalDialog(
      textInput("loginName", "ID", "user1"),
      passwordInput("loginPassword", "Password", ""),
      actionButton("loginPopup_login", "LogIn"),
      actionButton("loginPopup_register", "Register"),
      span(h5(textOutput("loginPopup_noti")), style = "color:red"),      
      footer = NULL,
      easyClose = FALSE
    )
  }  
  showModal(loginPopup())
  
  registerPopup <- function() {
    modalDialog(
      textInput("registerName", "ID", "user1"),
      passwordInput("registerPassword", "Password", ""),
      passwordInput("registerPasswordAgain", "Password", ""),      
      actionButton("registerPopup_register", "Register"),
      actionButton("registerPopup_cancel", "Cancel"),
      span(h5(textOutput("registerPopup_noti")), style = "color:red"),
      footer = NULL,
      easyClose = FALSE
    )
  }    

  observeEvent(input$registerPopup_register, {
    if (input$registerPassword == input$registerPasswordAgain) {
      if (!file.exists(pathPwTable)) {
        dfPw <- data.frame()
      } else {
        dfPw <- readRDS(pathPwTable)
        if (input$registerName %in% dfPw$id) {
         output$registerPopup_noti <- renderText("ID already exist!")
         showModal(registerPopup())
         return()
        }
      }
      saltedPw <- password_store(input$registerPassword)
      dfPw <- rbind(dfPw, data.frame(id = input$registerName, pw = saltedPw, stringsAsFactors = F))
      saveRDS(dfPw, pathPwTable)
    }      
    showModal(loginPopup())
  })
  
  observeEvent(input$loginPopup_register, {
    output$registerPopup_noti <- renderText("")
    showModal(registerPopup())
  })

  observeEvent(input$registerPopup_cancel, {
    removeModal()
    showModal(loginPopup())    
  })
    
  observeEvent(input$loginPopup_login, {
    flag_loginOk <- FALSE
    if (file.exists(pathPwTable)) {
      dfPw <- readRDS(pathPwTable)
      posId <- which(input$loginName == dfPw$id)
      if (length(posId)) {
        if (password_verify(dfPw[posId[1], 'pw'], as.character(input$loginPassword))) {
          flag_loginOk <- TRUE
        }
      }
    }
    if (flag_loginOk) {
      userName <<- input$loginName
      
      RV$group_a <<- c()
      RV$group_b <<- c()
      RV$select_page <<- 0
      RV$drag_item <<- c()
      
      
      pathTempDir <<- fitDirPath(const_tmpPath, userName)
      dir.create(pathTempDir, showWarnings = FALSE, recursive = TRUE)
      
      ## for global variable in commonFunc.R. TODO tidy up lately
      jsonMain2Shiny <<- fitFilePath(pathTempDir, 'main2Shiny.json')
      jsonFeature2Shiny <<- fitFilePath(pathTempDir, 'feature2Shiny.json')
      jsonShiny2Feature <<- fitFilePath(pathTempDir, 'shiny2Feature.json')
      const_MainJson <<- fitFilePath(pathTempDir, "_main.json")
      const_MainPhenoLoopJson <<-  fitFilePath(pathTempDir, '_mainPhenoLoop.json')
      const_GSEText <<- fitFilePath(pathTempDir, 'GSEList.txt')
      
      const_base_arrangePDataFile <- "arrangePData.Rds"
      const_base_summaryGDataFile <- "summaryGData.rds"
      const_base_summaryPDataFile <- "summaryPData.rds"
      const_path_root_old <- fitDirPath(pathTempDir, 'Data')
      const_path_root_new <- fitDirPath(pathTempDir, 'DataTemp')      
      const_old_arrangePDataFile <<- fitFilePath(const_path_root_old, const_base_arrangePDataFile)
      const_old_summaryGDataFile <<- fitFilePath(const_path_root_old, const_base_summaryGDataFile)
      const_summaryPDataFile <<- fitFilePath(const_path_root_new, const_base_summaryPDataFile)
      const_shinyZipFile <- paste0(userName, "_docs.zip") 
      const_shinyZipFilePath <<- fitFilePath(pathShinyWww, const_shinyZipFile)
      writeDataList(const_old_arrangePDataFile, const_old_summaryGDataFile, const_summaryPDataFile)
      
      cat(userName)
      cat(jsonFeature2Shiny)
      jsonResetFeatureShiny(jsonFeature2Shiny, jsonShiny2Feature)
      writeJsonCNewLine(resetValue_const_MainJson, in_file_path = const_MainJson)
      resetEvent(jsonMain2Shiny)
      
      output$userpanel <- renderUI({
        # session$user is non-NULL only in authenticated sessions
        if (!is.null(userName) && userName != 'a') {
          sidebarUserPanel(
            span("Logged in as ", userName),
            actionLink('logout', 'LogOut')
          )
          
        }
      })
      
      output$downloadDataLink <- renderUI({shiny::a("click on me", id = "click_on_me", href = const_shinyZipFile)})
      removeModal()          
      output$loginPopup_noti <- renderText("")
    } else {
      output$loginPopup_noti <- renderText("Check ID or Pw!")
    }
  })
  
  output$downloadDataLink <- renderUI({shiny::a("click on me", id = "click_on_me", href = const_shinyZipFile)})
  
  observeEvent(input$logout, {
    showModal(loginPopup())
  })
})
