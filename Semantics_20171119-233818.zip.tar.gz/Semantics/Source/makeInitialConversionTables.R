source("commonFunc.R")

const_Keyword <- NA

valueConversionTable <- data.frame()
conversionTable <- data.frame()
dfRegularExp <- data.frame()
dfSumFunction <- list() # If not defined, function "leftVecSel" will be used.
# #in_arg1, #in_arg2 ......
listInferenceEngine <- list()
dfValueConstraint <- data.frame()

`saveValueConversionTable<-` <- function(in.data, value) {
  
  if (length(value) != 2) stop('if (length(value) != 2)')
  return(rbind(in.data, data.frame(old = value[1], new = value[2])))
}

`saveConversionTable<-` <- function(in.data, value) {
  
  if (length(value) != 2) stop('if (length(value) != 2)')
  return(rbind(in.data, data.frame(keyword = value[1], alias = value[2])))
}

`saveRegularExp<-` <- function(in.data, value) {
  
  if (!(length(value) %in% c(2,3))) stop('if (length(value) %in% c(2,3))')
  if (length(value) == 2) {
    postProcess <- NA
  } else {
    postProcess <- value[3]
  }
  return(rbind(in.data, data.frame(keyword = value[1], regStr = value[2], postProcess = postProcess)))
}
pureNumericReg <- c('^((\\d+)(\\.(\\d)+){0,1})$', "as.numeric")
pureAllSel  <- '^(.*)$'
pureCharReg <- c(pureAllSel, "function(in_x){as.character(tolower(in_x))}")

`saveValueConstraint<-` <- function(in.data, value) {
  
  if (length(value) != 2) stop('if (length(value) != 2)')
  return(rbind(in.data, data.frame(feature = value[1], function.to.filter = value[2])))
}

## simplified functions
saveCTableKey <- function(value) {
  if (length(value) != 1) stop('if (length(value) != 1)')
  saveConversionTable(conversionTable) <<- c(const_Keyword, value)
}


setKeyword <- function(in_keyword){
  const_Keyword <<- in_keyword
  saveCTableKey(in_keyword)
}
saveVConst <- function(in_fun_str){
  saveValueConstraint(dfValueConstraint) <<- c(const_Keyword, in_fun_str)
}
saveRegExp <- function(in_arg_vec){
  saveRegularExp(dfRegularExp) <<- c(const_Keyword, in_arg_vec)
}
dfSumFun <- function(in_fun) {
  dfSumFunction[[const_Keyword]] <<- in_fun
}
#end of simplified functions

saveValueConversionTable(valueConversionTable) <- c('yes', "true")
saveValueConversionTable(valueConversionTable) <- c('no', "false")
saveValueConversionTable(valueConversionTable) <- c('y', "true")
saveValueConversionTable(valueConversionTable) <- c('n', "false")
saveValueConversionTable(valueConversionTable) <- c('cr', "complete response")
saveValueConversionTable(valueConversionTable) <- c('ir', "incomplete response")
saveValueConversionTable(valueConversionTable) <- c('unknown', NA)
saveValueConversionTable(valueConversionTable) <- c('unable to determine', NA)
saveValueConversionTable(valueConversionTable) <- c('not applicable', NA)
saveValueConversionTable(valueConversionTable) <- c('no information', NA)
saveValueConversionTable(valueConversionTable) <- c('unavailable', NA)
saveValueConversionTable(valueConversionTable) <- c('[Not Applicable]', NA)
saveValueConversionTable(valueConversionTable) <- c('[Not Available]', NA)
saveValueConversionTable(valueConversionTable) <- c('[unknown]', NA)
saveValueConversionTable(valueConversionTable) <- c('[Discrepancy]', NA)
saveValueConversionTable(valueConversionTable) <- c('negative', 'neg')
saveValueConversionTable(valueConversionTable) <- c('positive', 'pos')
saveValueConversionTable(valueConversionTable) <- c('?', NA)
saveValueConversionTable(valueConversionTable) <- c('i', 1)
saveValueConversionTable(valueConversionTable) <- c('ii', 2)
saveValueConversionTable(valueConversionTable) <- c('iii', 3)
saveValueConversionTable(valueConversionTable) <- c('iv', 4)


setKeyword('age')
saveCTableKey("age at surgery")
saveCTableKey("age (years)")
saveCTableKey("age at excision (years)")
saveCTableKey("age(years)")
saveCTableKey("age at primary diagnosis")
saveCTableKey("age (y)")
saveCTableKey("age (yrs) at rrp")
saveCTableKey("age diag")
saveCTableKey("age at diagnosis (y)")
saveCTableKey("age at initial pathologic diagnosis")
saveCTableKey("age at diagnosis")
saveRegExp(c('(\\d+)yrs', "as.numeric"))
saveRegExp(c('(\\d+)mos', 'function(x){x <- as.numeric(x) / 12;return(x)}'))
saveRegExp(pureNumericReg)
dfSumFun(vectorizeConsideringNA(sum))
saveVConst('is.numeric')


setKeyword('age more than 60')
saveCTableKey("age >60")
saveRegExp(pureCharReg)

appendList(listInferenceEngine) <-
  list(fig.name = 'age more than 60',
       arg.name = c('age'),
       script.text = 'ifelse(#in_arg1 > 60 , "TRUE", "FALSE")')


setKeyword('age at metastases')
saveRegExp(pureNumericReg)


setKeyword('gender')
saveCTableKey("sex")
saveRegExp(c(pureAllSel,
             'function(x){ x <- ifelse(x == "m", "male",x);
             x <- ifelse(x == "f", "female",x);
             x}'))
dfSumFun(vectorizeConsideringNA(paste0))
saveVConst('function(x){x %in% c("female", "male")}')


setKeyword('race')
saveCTableKey("ethnicity")
saveCTableKey("ethnic")
saveRegExp(c(pureAllSel,
             'function(x){ x <- ifelse(x == "bnh", "black and hispanic",x);
             x <- ifelse(x == "Wnh", "white and hispanic",x);
             x}'))
dfSumFun(vectorizeConsideringNA(paste0))


setKeyword('height (cm)')
saveRegExp(pureNumericReg)


setKeyword('weight (kg)')
saveRegExp(pureNumericReg)


setKeyword('bmi')
saveRegExp(pureNumericReg)
appendList(listInferenceEngine) <- list(fig.name = 'bmi',
                                        arg.name = c('height (cm)', 'weight (kg)'),
                                        script.text = '#in_arg2 / (#in_arg1 / 100) ^ 2')


setKeyword('date of birth')
saveCTableKey("dob")
saveRegExp(pureCharReg)


setKeyword('cancer')
saveCTableKey("tissue type")
saveRegExp(pureCharReg)

appendList(listInferenceEngine) <- list(fig.name = 'cancer',
                                        arg.name = c('breast tumor tissue'),
                                        script.text = 'ifelse(!is.na(#in_arg1), #in_arg1, NA)')
appendList(listInferenceEngine) <- list(fig.name = 'cancer',
                                        arg.name = c('frozen tissue of ovarian tumors'),
                                        script.text = 'ifelse(!is.na(#in_arg1), #in_arg1, NA)')
appendList(listInferenceEngine) <- list(fig.name = 'cancer',
                                        arg.name = c('cancer name'),
                                        script.text = 'ifelse(!is.na(#in_arg1), #in_arg1, NA)')


setKeyword('breast tumor tissue')
saveRegExp(pureCharReg)


setKeyword('frozen tissue of ovarian tumors')
saveRegExp(pureCharReg)


setKeyword('cancer name')
saveCTableKey("submitting diagnosis")
saveRegExp(c(pureAllSel,
             'function(x){ x <- ifelse(x == "tumor", TRUE,x);
             x <- ifelse(x == "healthy", FALSE, x);
             x}'))


setKeyword('excision year')
saveRegExp(pureNumericReg)


setKeyword('post surgical treatment')
saveRegExp(c( pureAllSel,
              'function(x){ x <- ifelse(x == "act", "activation",x);
              x <- ifelse(x == "obs", "observation", x);
              x}'))


setKeyword('radiation therapy')
saveCTableKey('adjuvant rx')
saveCTableKey('adjxrt')
saveRegExp(pureCharReg)


setKeyword('intravesical therapy')
saveRegExp(pureCharReg)


setKeyword('taxane treatment')
saveCTableKey('taxane')
saveRegExp(pureCharReg)


setKeyword('ecog performance status')
saveCTableKey('performance status corresponding to who criteria')
saveRegExp(pureCharReg)


setKeyword('cisplatin response')
saveCTableKey('cisplatin response (complete response or incomplete response)')
saveRegExp(pureCharReg)


setKeyword('platinum sensitivity')
saveRegExp(pureCharReg)


setKeyword('smoking')
saveCTableKey('smoking status')
saveCTableKey('smoking history')
saveCTableKey('smoking status(0:nonsmoker,1:smoker)')
saveRegExp(c(pureAllSel,
             'function(x){ x <- ifelse(x == "former", "ex-smoker", x)}')
)


setKeyword('smoking duration (years)')
saveRegExp(pureNumericReg)


setKeyword('smoking dose (cigarettes/day)')
saveRegExp(pureNumericReg)


setKeyword('smoking quit time')
saveCTableKey('time quit (@ initial consult)')
saveRegExp(pureNumericReg)


setKeyword('tumor site')
saveCTableKey('tumorsite')
saveCTableKey('primary site')
saveRegExp(pureCharReg)


setKeyword('tumor side of body')
saveCTableKey('side of body')
saveRegExp(pureCharReg)


setKeyword('localization of primary melanoma')
saveRegExp(pureCharReg)


setKeyword('cancer location')
saveCTableKey('location')
saveRegExp(pureCharReg)


setKeyword('recurrence site')
saveCTableKey('site of relapse')
saveCTableKey('rectype1')
saveRegExp(pureCharReg)


setKeyword('surgery type')
saveCTableKey('surgtype')
saveRegExp(pureCharReg)


setKeyword('surgical margins')
saveRegExp(pureCharReg)


setKeyword('debulking')
saveCTableKey('debulking (1:optimal)')
saveCTableKey('optimal')
saveCTableKey('surgery status')
saveCTableKey('surgical debulking or residual disease (cm)')
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("<1", "1", "o"), "optimal", x);
             x <- ifelse(x %in% c(">1", "0", "s", "sub-optimal"), "suboptimal", x);
             }'))


saveValueConstraint(dfValueConstraint) <- c('debulking', 'function(x){x %in% c("optimal", "suboptimal")}')


setKeyword('existance of residual tumor')
saveCTableKey('residual tumor')
saveRegExp(pureCharReg)


setKeyword('CA-125 in the blood')
saveCTableKey('ca-125 coefficient')
saveCTableKey('preop ca125')
saveRegExp(pureNumericReg)


setKeyword('psa')
saveCTableKey('psa (ng/ml) at rrp')
saveRegExp(pureNumericReg)


setKeyword('first rising psa (ng/ml)')
saveRegExp(pureNumericReg)


setKeyword('time (yrs) from rrp to first rising psa')
saveRegExp(pureNumericReg)


setKeyword('second rising psa (ng/ml)')
saveRegExp(pureNumericReg)


setKeyword('time (yrs) from rrp to second rising psa')
saveRegExp(pureNumericReg)


setKeyword('psa slope (ng/ml/yr)')
saveRegExp(pureNumericReg)


setKeyword('ldh ratio more than 1')
saveCTableKey('ldh ratio >1')
saveRegExp(pureCharReg)


setKeyword('Lactate dehydrogenase ratio')
saveCTableKey('ldh ratio')
saveRegExp(pureNumericReg)


setKeyword('hormone secretion')
saveCTableKey("hormone expression")
saveRegExp(pureCharReg)


setKeyword('tumor grade')
saveCTableKey("grade")
saveCTableKey("grade (modified, bloom, richardson)")
saveCTableKey("stage")
saveCTableKey("final pat stage")
saveCTableKey("pathological stage")
saveCTableKey("pstage iorii")
saveCTableKey("histologic grade")
saveCTableKey("who grade")
saveCTableKey("grpstage")
saveCTableKey("tumor stage")
saveCTableKey("ajcc uicc stage")
saveCTableKey("stagecode")
saveCTableKey("pstage")
saveCTableKey("cancer stage")
saveCTableKey("grading")
saveCTableKey("stage (pathological )")
saveCTableKey("tumor stage (ajcc)")
saveCTableKey("pathologic stage")
saveRegExp(pureNumericReg)


setKeyword("tumor size")
saveCTableKey("size")
saveCTableKey("tumor size (cm)")
saveRegExp(pureNumericReg)


setKeyword("er")
saveCTableKey("estrogen receptor (er) status")
saveCTableKey("breast carcinoma estrogen receptor status")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("0", "neg"), "neg", x);
             x <- ifelse(x %in% c("1", "pos", "pos-low", "er+"), "pos", x);
             }'))


setKeyword("pgr")
saveCTableKey("pr")
saveCTableKey("breast carcinoma progesterone receptor status")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("0", "neg"), "neg", x);
             x <- ifelse(x %in% c("1", "pos", "pos-low"), "pos", x);
             }'))


setKeyword("lymph node")
saveCTableKey("node")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("0", "negative"), "neg", x);
             x <- ifelse(x %in% c("1", "positive", "pos.micromet"), "pos", x);
             }'))


setKeyword("recur free survival time")
saveCTableKey("t rfs")
saveCTableKey("time rfs")
saveCTableKey("t rfs months")
saveRegExp(pureNumericReg)


setKeyword("recur free event")
saveCTableKey("e rfs")
saveCTableKey("distant rfs")
saveCTableKey("tumor recurrence (36mo)")
saveRegExp(pureNumericReg)


setKeyword("distance meta free survival time")
saveCTableKey("t dmfs")
saveCTableKey("distant recurrence free survival (mo)")
saveRegExp(pureNumericReg)


setKeyword("distance meta event")
saveCTableKey("e dmfs")
saveCTableKey("distant relapse")
saveCTableKey("distant recur (yn)")
saveCTableKey("distant relapse (1:dr, 0 censored)")
saveCTableKey("distant metastasis present ind2")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("0", "n"), "0", x);
             x <- ifelse(x %in% c("1", "y"), "1", x);
             }'))


setKeyword("disease free survival time")
saveCTableKey("dfs time")
saveRegExp(pureNumericReg)


setKeyword("disease free survival event")
saveCTableKey("dfs status")
saveRegExp(pureNumericReg)


setKeyword("time of followup")
saveCTableKey("time of followup (mo)")
saveRegExp(pureNumericReg)


setKeyword("ggi")
saveRegExp(pureNumericReg)


setKeyword("treatment")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("tamoxifen", "tamoxifen treatment for 5 years"), "1", x);
             }'))


setKeyword("adj neoadj chemotherapy")
saveCTableKey("adj neoadj chemotherapy received")
saveCTableKey("adjuvant chemotherapy")
saveCTableKey("chemo class")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("none"), "0", x);
             x <- ifelse(!(x %in% c("none")), "1", x);
             }'))


setKeyword("hormonal rx")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("none"), "0", x);
             x <- ifelse(!(x %in% c("none")), "1", x);
             }'))


setKeyword("her2")
saveCTableKey("her2 status")
saveCTableKey("her 2")
saveCTableKey("lab proc her2 neu immunohistochemistry receptor status")
saveRegExp(c(pureAllSel,
             'function(x){
             x <- ifelse(x %in% c("0", "neg"), "neg", x);
             x <- ifelse(x %in% c("1", "pos", "low pos (2+)", "pos (3+)"), "pos", x);
             }'))


setKeyword("nodal")
saveCTableKey("nodal status (0:negative, 1:positive, na:not applicable)")
saveRegExp(pureCharReg)


setKeyword("histology type")
saveCTableKey("histological type")
saveRegExp(pureCharReg)


setKeyword("other dx")
saveRegExp(pureCharReg)


setKeyword("history of neoadjuvant treatment")
saveRegExp(pureCharReg)


setKeyword("person neoplasm cancer status")
saveRegExp(pureCharReg)


setKeyword("death")
saveRegExp(pureCharReg)


setKeyword("vital status")
saveRegExp(c(pureAllSel, 
'function(x){
   x <- ifelse(x %in% c("alive", "dead"), x, NA);
 }'))


appendList(listInferenceEngine) <- 
  list(fig.name = 'death',
       arg.name = c('vital status'),
       script.text = 
         'ifelse(#in_arg1 == "alive", 0, 
                 ifelse(#in_arg1 == "dead", 1, #in_arg1))')


setKeyword("days to last followup")
saveRegExp(pureNumericReg)


setKeyword("days to death")
saveRegExp(pureNumericReg)


setKeyword("postoperative rx tx")
saveRegExp(pureCharReg)


setKeyword("histological type other")
saveRegExp(pureCharReg)


setKeyword("year of initial pathologic diagnosis")
saveRegExp(pureNumericReg)


setKeyword("initial pathologic diagnosis method")
saveRegExp(pureCharReg)


setKeyword("init pathology dx method other")
saveRegExp(pureCharReg)


setKeyword("breast carcinoma surgical procedure name")
saveRegExp(pureCharReg)


setKeyword("surgical procedure purpose other text")
saveRegExp(pureCharReg)


setKeyword("margin status")
saveRegExp(pureCharReg)


setKeyword("breast carcinoma primary surgical procedure name")
saveRegExp(pureCharReg)


setKeyword("breast neoplasm other surgical procedure descriptive text")
saveRegExp(pureCharReg)


setKeyword("axillary lymph node stage method type")
saveRegExp(pureCharReg)


setKeyword("axillary lymph node stage other method descriptive text")
saveRegExp(pureCharReg)


setKeyword("primary lymph node presentation assessment")
saveRegExp(pureCharReg)


setKeyword("lymph node examined count")
saveRegExp(pureNumericReg)


setKeyword("number of lymphnodes positive by he")
saveRegExp(pureNumericReg)


setKeyword("number of lymphnodes positive by ihc")
saveRegExp(pureNumericReg)


setKeyword("system version")
saveRegExp(pureCharReg)


setKeyword("t stage")
saveCTableKey("pathologic T")
saveRegExp(pureCharReg)


setKeyword("n stage")
saveCTableKey("pathologic N")
saveRegExp(pureCharReg)


setKeyword("m stage")
saveCTableKey("pathologic M")
saveRegExp(pureCharReg)


setKeyword("metastatic site at diagnosis")
saveRegExp(pureCharReg)


setKeyword("metastatic site at diagnosis other")
saveRegExp(pureCharReg)


setKeyword("er level cell percentage category")
saveRegExp(pureCharReg)


setKeyword("breast carcinoma immunohistochemistry er pos finding scale")
saveRegExp(pureCharReg)


setKeyword("immunohistochemistry positive cell score")
saveRegExp(pureCharReg)


setKeyword("positive finding estrogen receptor other measurement scale text")
saveRegExp(pureCharReg)


setKeyword("er detection method text")
saveRegExp(pureCharReg)


setKeyword("progesterone receptor level cell percent category")
saveRegExp(pureCharReg)


setKeyword("breast carcinoma immunohistochemistry progesterone receptor pos finding scale")
saveRegExp(pureCharReg)


setKeyword("breast carcinoma immunohistochemistry pos cell score")
saveRegExp(pureCharReg)


setKeyword("pos finding progesterone receptor other measurement scale text")
saveRegExp(pureCharReg)


setKeyword("pgr detection method text")
saveRegExp(pureCharReg)


setKeyword("her2 erbb pos finding cell percent category")
saveRegExp(pureCharReg)


setKeyword("her2 immunohistochemistry level result")
saveRegExp(pureCharReg)


setKeyword("pos finding her2 erbb2 other measurement scale text")
saveRegExp(pureCharReg)


setKeyword("her2 erbb method calculation method text")
saveRegExp(pureCharReg)


setKeyword("lab procedure her2 neu in situ hybrid outcome type")
saveRegExp(pureCharReg)


setKeyword("her2 neu breast carcinoma copy analysis input total number")
saveRegExp(pureNumericReg)


setKeyword("fluorescence in situ hybridization diagnostic procedure chromosome 17 signal result range")
saveRegExp(pureNumericReg)


setKeyword("her2 neu and centromere 17 copy number analysis input total number count")
saveRegExp(pureNumericReg)


setKeyword("her2 neu chromosone 17 signal ratio value")
saveRegExp(pureNumericReg)


setKeyword("her2 and centromere 17 positive finding other measurement scale text")
saveRegExp(pureCharReg)


setKeyword("her2 erbb pos finding fluorescence in situ hybridization calculation method text")
saveRegExp(pureCharReg)


setKeyword("new tumor event after initial treatment")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma estrogen receptor status")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma estrogen receptor level cell percent category")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma immunohistochemistry er pos cell score")
saveRegExp(pureCharReg)


setKeyword("pos finding metastatic breast carcinoma estrogen receptor other measuremenet scale text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma estrogen receptor detection method text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma progesterone receptor status")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma progesterone receptor level cell percent category")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma immunohistochemistry pr pos cell score")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma pos finding progesterone receptor other measure scale text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma progesterone receptor detection method text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma lab proc her2 neu immunohistochemistry receptor status")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma her2 erbb pos finding cell percent category")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma erbb2 immunohistochemistry level result")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma pos finding her2 erbb2 other measure scale text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma her2 erbb method calculation method text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma lab proc her2 neu in situ hybridization outcome type")
saveRegExp(pureCharReg)


setKeyword("her2 neu metastatic breast carcinoma copy analysis input total number")
saveRegExp(pureNumericReg)


setKeyword("metastatic breast carcinoma fluorescence in situ hybridization diagnostic proc centromere 17 signal result range")
saveRegExp(pureCharReg)


setKeyword("her2 neu and centromere 17 copy number metastatic breast carcinoma analysis input total number count")
saveRegExp(pureNumericReg)


setKeyword("metastatic breast carcinoma her2 neu chromosone 17 signal ratio value")
saveRegExp(pureNumericReg)


setKeyword("metastatic breast carcinoma pos finding other scale measurement text")
saveRegExp(pureCharReg)


setKeyword("metastatic breast carcinoma her2 erbb pos finding fluorescence in situ hybridization calculation method text")
saveRegExp(pureCharReg)


setKeyword("anatomic neoplasm subdivision")
saveRegExp(pureCharReg)


setKeyword("clinical M")
saveRegExp(pureCharReg)


setKeyword("clinical N")
saveRegExp(pureCharReg)


setKeyword("clinical T")
saveRegExp(pureCharReg)


setKeyword("clinical stage")
saveRegExp(pureCharReg)
			

setKeyword("days to patient progression free")
saveCTableKey('days to tumor progression')
saveRegExp(pureNumericReg)


setKeyword("disease code")
saveRegExp(pureCharReg)


setKeyword("extranodal involvement")
saveRegExp(pureCharReg)


setKeyword("icd 10")
saveRegExp(pureCharReg)


setKeyword("icd o 3 histology")
saveRegExp(pureCharReg)


setKeyword("icd o 3 site")
saveRegExp(pureCharReg)



setKeyword("informed consent verified")
saveRegExp(pureCharReg)


setKeyword("tumor tissue site")
saveRegExp(pureCharReg)

setKeyword("menopause status")
saveRegExp(pureCharReg)


setKeyword("history other malignancy")
saveRegExp(pureCharReg)


if (length(unique(conversionTable$alias)) != NROW(conversionTable)) {
  stop("if (length(unique(conversionTable$alias)) != NROW(conversionTable)) {")
}

saveRDS(list(conversionTable = conversionTable ,
             dfRegularExp = dfRegularExp,
             dfSumFunction = dfSumFunction,
             dfValueConstraint = dfValueConstraint,
             listInferenceEngine = listInferenceEngine,
             valueConversionTable = valueConversionTable),
        const_pathFileInitialConversionTable)
