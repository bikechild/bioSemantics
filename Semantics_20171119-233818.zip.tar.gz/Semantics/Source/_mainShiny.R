setwd('/home/bike/Semantics/Source/')
library(shiny)
runApp("shinyR")
