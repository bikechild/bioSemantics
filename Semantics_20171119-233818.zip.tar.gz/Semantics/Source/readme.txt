analysisUsingPhenotypeAndGenoType.R: Example of selPosOfFinalPData to restricted language
arrangeStageFeature.R: tide up feature # test 
commonFunc.R: summary of functions which is used in this project
downloadGeoData.R: download GEO data & merge data
featureSave.R: save features
filterFeatureData.R: extract features
filterFeatureDataSub.R: sub function of filterFeatureData.R
findGEOTitle.R: find GEO title
gData.R: save gene expression data
geo2RBreast.R: get GEO breast data
geo2RCheck.R: manually check GEO data
geo2RLung.R: get GEO breast data
geo2ROvarian.R: get GEO Ovarian data
geo2RSurvExpress.R: get SurvExpressData data
survExpressFeature.R: get SurvExpress feature from data
