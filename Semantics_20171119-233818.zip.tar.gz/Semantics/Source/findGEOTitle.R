findGEOTitleSummary <- function(in.geo.name){
  # findGEOTitle("GSE15622")
  
  library("XML")
  library("httr")
  library("rvest")
  library("magrittr")
  
  
#   reg.4.title <- "^.*Title\\n((\\w|\\s){1, })\\n.*$"
  reg.to.find.title <- "^.*Title\\n([[:alnum:] ()[:punct:]]+).*$"
  reg.to.find.summary <- "^.*Summary\\n([[:alnum:] ()[:punct:]]+).*$"

  fread.html <- html_session(paste0("http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=", in.geo.name))
  tr.data <- fread.html %>% read_html() %>% html_text()
  tr.data <- tr.data[[1]]

  if (grepl(reg.to.find.title, tr.data) == TRUE) {
    return.title <- sub(reg.to.find.title, '\\1', tr.data)
  } else {
    stop("(grepl(reg.4.title, tr.data) == TRUE)")
  }

  if (grepl(reg.to.find.summary, tr.data) == TRUE) {
    return.summary <- sub(reg.to.find.summary, '\\1', tr.data)
  } else {
    stop("(grepl(reg.4.title, tr.data) == TRUE)")
  }
  return(list(title = return.title, summary = return.summary))
}
