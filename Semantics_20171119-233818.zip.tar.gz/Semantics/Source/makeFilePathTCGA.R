library("stringr")
pathRootTcag <- 'D:/BioDatabase/TCGA'

allFile <- list.files('D:/BioDatabase/TCGA', recursive = T, full.names = T)  

tmp <- list.dirs(pathRootTcag, recursive = F, full.names = F)
vecCancer <- tmp[str_length(tmp) <= 4]
outDf <- data.frame(cancer = vecCancer, 
                    pathPheno = NA,
                    pathRna = NA)
selNotOldNewMod <- function(in_file_list) {
  in_file_list <- in_file_list[!grepl('old_module', in_file_list)]
  in_file_list <- in_file_list[which(max(file.mtime(in_file_list)) == file.mtime(in_file_list))] 
}
  
for (i in vecCancer) {
  tmCancerList <- allFile[grep("/" %+% i %+% "/" , allFile)]
  tmpPhenoPath <- selNotOldNewMod(tmCancerList[grep('nationwidechildrens\\.org_clinical_patient', tmCancerList)])
  tmpPathRna <- selNotOldNewMod(tmCancerList[grep('READ__illuminahiseq_rnaseqv2__GeneExp\\.txt', tmCancerList)])
  outDf[outDf[ ,'cancer'] == i, c("pathPheno", "pathRna")] <- c(tmpPhenoPath, tmpPathRna)    
}

write.csv(outDf, file = 'D:/BioSemantic/Code/tmpData/pathTCGA.csv', row.names = F)
