library(Biobase)
library(combinat)
library(extrafont)
library(GEOquery)
library(GGally)
library(ggplot2)
library(gplots)
library(HGNChelper)
library(httr)
library(jsonlite)
library(knitr)
library(limma)
library(magrittr)
library(Matrix)
library(methods)
library(plyr)
library(R6)
library(reshape)
library(rvest)
library(splines)
library(stringdist)
library(stringr)
library(survival)
library(XML)
library(sodium)
library(org.Hs.eg.db)

require(biomaRt)
require(plyr)
require(clusterProfiler)

require(DOSE)
require(rlang)


COL_NAME_GSE_NUM <- "gse.name"
COL_NAME_GEO_SAMPLE <- "geo.sample"
COL_NAME_PLATFORM_ID  <- "platform.id"
const_removeInColnames <- c('individual:', 'clinical info:')

options(stringAsFactor = FALSE)

listFilesOnly <- function(in.path){
  return(setdiff(list.files(in.path), 
                 list.dirs(in.path, full.names = FALSE, recursive = FALSE)))
}

fitFilePath <- function(...){
  return(fitDirPath(..., in.flag.file.end = T))
}

fitDirPath <- function(..., in.flag.file.end = F){
  
  raw.paste <- paste(..., sep = '/')
  tmp <- gsub('\\\\{2,}','/', raw.paste)
  tmp <- paste0(tmp, '/')
  paste.after.reg <- gsub('/{2,}','/', tmp)
  
  if (in.flag.file.end) {
    paste.after.reg <- substr(paste.after.reg, 1, nchar(paste.after.reg) - 1)
  }
  return(paste.after.reg)
}

catE <- function(...){
  cat(... , "\n", sep = "")
}

checkDFandMatrix <- function(in.value){
    if(is.data.frame(in.value) || is.matrix(in.value)){
        return(TRUE)
    } else{
        return(FALSE)
    }
}

vectorizeConsideringNA <- function(in.function){
  
  ret.function <- function(in.x, in.y) {
    if (is.na(in.x)) return(in.y)
    if (is.na(in.y)) return(in.x)
    
    return(in.function(in.x, in.y))
  }
  
  Vectorize(ret.function)
}


findGEOName <- function(in.colname, in.col.data = "" , in.data) {
  col.vec <- !is.na(in.data[ ,in.colname])
  if(in.col.data != ""){
    col.vec <- col.vec & in.data[ ,in.colname] == in.col.data
  }
  unique(in.data[col.vec, COL_NAME_GSE_NUM])
}

findGEONameForColData <- function(in.colname, in.col.data = "") {
  findGEOName(in.colname, in.col.data, outPdata)
}


calFeatureDistance <- function(in.x, in.vec.comparison) {
  # calculate phase distance
  #
  # arg:
  #   in.x
  #   in.vec.comparison
  #
  # return:
  #   vector of distance with in.vec.comparison name
  
  separateWord <- function(in.word) {
    
    vec.output  <- c()
    list.sep <- gregexpr("\\w+", in.word)
    list.sep <- list.sep[[1]]
    length.of.sep <- attr(list.sep, "match.length")
    
    for (i in seq(1,length(list.sep))) {
      vec.output <- c(vec.output, substring(in.word, list.sep[i], list.sep[i] + length.of.sep[i] - 1))
    }
    return(vec.output)
  }
  
  distanceData <- rep(Inf, length(in.vec.comparison))
  names(distanceData) <- in.vec.comparison
  vector.of.in.x <- separateWord(in.x)
  for (i in vector.of.in.x){
    for(j in in.vec.comparison){
      in.vec.comparison.separate.word <- separateWord(j)
      distanceData[j] <- 
        min(c(distanceData[j], stringdist(i, in.vec.comparison.separate.word, method = 'lv', weight = c(d = 1, i = 0.02, s = 1)))) +
        (length(in.vec.comparison.separate.word) -1) * 0.01
    }
  }
  return(distanceData)
}


revertStr <- function(in.string){
  return(paste(rev(strsplit(in.string, NULL)[[1]]),collapse=''))
}

countStr <- function(x, pattern, split){
  
  unlist(lapply(
    strsplit(x, split),
    function(z) na.omit(length(grep(pattern, z)))
  ))
  
}


getGEOpData <- function(in.geo.list, 
                        in.save.phono.path.file, 
                        in.save.geno.path.file = NA,
                        in.save.feature.path.file = NA,
                        in.save.gpl.path.file = NA, 
                        in.dest.path = NA, 
                        in.vec.gpl = NA, 
                        in_retry_count = 10){
  
  
  if(is.na(in.dest.path)){
    dest.dir <- tempdir()
  } else {
    dest.dir <- in.dest.path
  }  
  
  pData.save <- list()
  fData.save <- list()
  expData.save <- list()
  gplData.save <- list()
  
  for (tmp.geo.list in in.geo.list) {
    cat(tmp.geo.list %+% "'s download is started." %+% '\n')
    
    tmp.local.locale <- Sys.getlocale()
    Sys.setlocale(category = "LC_ALL", locale = "C")

    tryCatch({
      catE(dest.dir)
      geo_data <- NULL
      countGetGEO <- in_retry_count
      while (is.null(geo_data)) {
        geo_data <- tryCatch({
          getGEO(tmp.geo.list, destdir = dest.dir)
        }, error = function(e){
          return(NULL)
        })
        if (is.null(geo_data)) {
          if (countGetGEO > 0) {
            cat(tmp.geo.list %+% "'s download will be retried." %+% '\n')            
            Sys.sleep(30)
            countGetGEO <<- countGetGEO - 1
          } else {
            stop(e)
          }            
        }
      }
      suppressWarnings(Sys.setlocale(category = "LC_ALL", tmp.local.locale))
    
      for( tmp.geodata.names in names(geo_data)) {
        if (!any(is.na(in.vec.gpl))) {
          if (!(annotation(geo.data[[ tmp.geodata.names ]]) %in% in.vec.gpl)) {
            next
          }
        }      
        pData.save[[paste0(tmp.geo.list,"__",tmp.geodata.names)]] <- pData(geo_data[[ tmp.geodata.names ]])
        expData.save[[paste0(tmp.geo.list,"__",tmp.geodata.names)]] <- Biobase::exprs(geo_data[[ tmp.geodata.names ]])
        fData.save[[paste0(tmp.geo.list,"__",tmp.geodata.names)]] <- fData(geo_data[[ tmp.geodata.names ]])
        gplData.save[[paste0(tmp.geo.list,"__",tmp.geodata.names)]] <- annotation(geo_data[[ tmp.geodata.names ]])
      }
    }, error = function(e){
      cat(tmp.geo.list %+% "'s download is failed. Try next time." %+% '\n')
    })
  }
  if (!is.na(in.save.phono.path.file)) saveRDS(pData.save, in.save.phono.path.file)
  if (!is.na(in.save.geno.path.file)) saveRDS(expData.save, in.save.geno.path.file)
  if (!is.na(in.save.feature.path.file)) saveRDS(fData.save, in.save.feature.path.file)
  if (!is.na(in.save.gpl.path.file)) saveRDS(gplData.save, in.save.gpl.path.file)
}

G_featureVoca <- vector()
saveFeatureVoca <- function(in.data){
  if (in.data %in% G_featureVoca) {
    stop("Duplicated Data in G_featureVoca")
  }
  G_featureVoca[length(G_featureVoca) + 1] <<- in.data
}


#no upper character
G_featureVocaSynonym <- vector()
saveFeatureVocaSynonym <- function (in.feature.voca, in.data.synonym) {
  if (!(in.feature.voca %in% G_featureVoca)) {
    print(in.feature.voca)
    stop("in.feature.voca in saveFeatureVocaSynonym is not in G_featureVoca!")
  }
  
  if (in.data.synonym %in% G_featureVocaSynonym) {
    print(in.feature.voca)
    stop("in.data.synonym in saveFeatureVocaSynonym is not in G_featureVocaSynonym!")
  }
  
  if (in.data.synonym %in% G_featureVoca) {
    print(in.feature.voca)
    stop("in.data.synonym in saveFeatureVocaSynonym is in G_featureVoca!")
  }  
  
  G_featureVocaSynonym[in.data.synonym] <<- in.feature.voca
}

G_featureVocaRegix <- data.frame()
saveFeatureVocaRegix <- function (in.feature.voca, in.feature.regix) {
  if (!(in.feature.voca %in% G_featureVoca)) {
    print(in.feature.voca)
    stop("!(in.feature.voca %in% G_featureVoca) is not in saveFeatureVocaRegix!")
  }
  
  if (in.feature.regix %in% G_featureVocaRegix) {
    print(in.feature.voca)
    stop("in.feature.regix %in% G_featureVocaRegix is not in saveFeatureVocaRegix!")
  }
  
  if (in.feature.regix %in% G_featureVoca) {
    print(in.feature.regix)
    stop("in.feature.regix %in% G_featureVoca is in saveFeatureVocaRegix!")
  }  
  
  tmp.G_featureVocaRegix <- data.frame(feature.voca = in.feature.voca, 
                                       feature.regix = in.feature.regix)
  
  
  G_featureVocaRegix <<- rbind(G_featureVocaRegix, tmp.G_featureVocaRegix)  
}



G_ignoreTerm <- vector()
saveIgnoreTerm <- function(in.ignore.term){
  if (in.ignore.term %in% G_featureVoca) {
    print(in.ignore.term)
    stop("in.ignore.term in saveFeatureVocaSynonym is in G_featureVoca!")
  }
  
  G_ignoreTerm[length(G_ignoreTerm) + 1] <<- in.ignore.term
}


G_objectVoca <- data.frame()
addObjectVoca <- function(in.before.feature, in.before.value, in.after.feature, in.after.value){
  if( any(G_objectVoca$before.feature == in.before.feature & G_objectVoca$before.value == in.before.value) ){
    stop("any(G_objectVoca$before.feature == in.before.feature & G_objectVoca$before.value == in.before.value) in addObjectVoca")
  }
  if(!(in.after.feature %in% G_featureVoca)) {
    stop("!(in.after.feature %in% G_featureVoca) in addObjectVoca")
  }
  if(dim(G_objectVoca)[1] != 0){
    if(dim(subset(G_objectVoca, before.feature == in.before.feature & after.feature != in.after.feature))[1] > 1){
      stop("dim(subset(G_objectVoca, before.feature == in.before.feature & after.feature != in.after.value))[1] != 1 in addObjectVoca")
    }    
  }
  
  
  tmp.G_objectVoca <- data.frame(before.feature = in.before.feature, 
                                 before.value = in.before.value, 
                                 after.feature = in.after.feature, 
                                 after.value = in.after.value)
  
  
  G_objectVoca <<- rbind(G_objectVoca, tmp.G_objectVoca)
}



# superior word definition (not used word but data will be overwritten!)
G_featureVocaSuperior <- data.frame()
saveFeatureVocaSuperior <- function(in.feature.superior, in.feature.voca){
  if (nrow(G_featureVocaSuperior) > 0) {
    if (in.feature.superior %in% G_featureVocaSuperior[ ,"feature.superior"]) {
      print(in.feature.superior)
      stop("in.feature.superior %in% G_featureVocaSuperior error in G_featureVoca!")
    }
  }
  if (!(in.feature.voca %in% G_featureVoca)) {
    print(in.feature.voca)
    stop("!(in.feature.voca %in% G_featureVoca) error in G_featureVoca!")
  }    
  
  tmp.G_featureVocaSuperior <- data.frame(feature.superior = in.feature.superior, 
                                          feature.voca = in.feature.voca)
  G_featureVocaSuperior <<- rbind(G_featureVocaSuperior, tmp.G_featureVocaSuperior)
}



G_featureVocaSuperiorByData <- data.frame()
saveFeatureVocaSuperiorByData <- function(in.feature.after, in.feature.after.function,
                                          in.feature.before, in.feature.before.function){
  if (!(in.feature.before %in% G_featureVoca)) {
    print(in.feature.superior)
    stop("iin.feature.superior %in% names(G_featureVocaSuperiorByData error in saveFeatureVocaSuperiorByData!")
  }
  if (!(in.feature.after %in% G_featureVoca)) {
    print(in.feature.before)
    stop("(!(in.feature.before %in% G_featureVoca) error in G_featureVoca!")
  }    
  tmp.G_featureVocaSuperiorByData <- data.frame(feature.after = in.feature.after, 
                                                feature.after.function = in.feature.after.function,
                                                feature.before = in.feature.before,
                                                feature.before.function = in.feature.before.function)
  G_featureVocaSuperiorByData <<- rbind(G_featureVocaSuperiorByData, tmp.G_featureVocaSuperiorByData)
}

featureSurvialCurrentStatus <- function(in.data){
  in.data.without.na <- in.data[!is.na(in.data)]
  # NED=no evidence of disease; AWD=alive with disease; DOC=died from other cause; DOD=died of disease
  if ( all(in.data.without.na %in% c("ned", "dod", 'doc', "awd")) ) {
    return(TRUE)
  } 
  return(FALSE)
}
featureASIS <- function(in.data){
  return(in.data)
}

G_featureSplitRegix <- vector()
saveFeatureSplitRegix <- function(in.data){
  if ( any(grep(in.data, G_featureVoca)) ) {
    stop( paste0("any(grep(in.data, G_featureVoca) in G_featureVoca:",in.data) )
  }
  G_featureSplitRegix[length(G_featureSplitRegix) + 1] <<- in.data
}

G_dfChangeRawDataUsingRegix <- data.frame()
saveDfChangeRawDataUsingRegix<- function(in.feature.after, in.feature.before){
  if ( any(grep(in.feature.before, G_featureVoca)) ) {
    stop( paste0("any(grep(in.feature.before, G_featureVoca)) :",in.feature.before) )
  }
  tmp.G_dfChangeRawDataUsingRegix <- data.frame(feature.after = in.feature.after, 
                                                feature.before = in.feature.before)
  G_dfChangeRawDataUsingRegix <<- rbind(G_dfChangeRawDataUsingRegix, tmp.G_dfChangeRawDataUsingRegix)  
}


trimVocaVector <- function(in.voca, in.except.colon = F){
  # Only 1 space anc no space above and below parentheses
  #
  # args:
  #   in.voca: vector string or data.frame or matrix
  #   in.except.colon:
  #
  
  if (!is.vector(in.voca)) {
    stop("!is.vector(in.voca) in trimVoca")
  }
  if ( !(in.except.colon %in% c(F,T)) ) {
    stop("in.except.colon %in% c(F,T) in trimVoca")
  }
  
  return.voca <- in.voca
  return.voca <- gsub("^\\s+", "", return.voca)
  return.voca <- gsub("\\s+$", "", return.voca)
  return.voca <- gsub("(_|\\s)+"," ", return.voca)
  return.voca <- gsub("\\s+\\(\\s+","(", return.voca)
  return.voca <- gsub("\\s+\\)\\s+",")", return.voca)
  if (in.except.colon == F) {
    return.voca <- gsub("\\."," ", return.voca)  
  }
  return.voca <- gsub("\\s\\s"," ", return.voca)

  # manage small quotas which are existed in head & tail
  return.voca <- sapply(return.voca, function(in_x) {if (substr(in_x, 1, 1) == substr(in_x, nchar(in_x), nchar(in_x)) 
                                             && substr(in_x, 1, 1) == "'") {
      return(in_x <- substr(in_x, 2, nchar(in_x) - 1))
  } else {
      return(in_x)
  }})
  
  
  return(return.voca)
}  

trimVoca <-  function(in.voca, in.except.colon = F) {
  # Only 1 space anc no space above and below parentheses
  #
  # args:
  #   in.voca: vector string or data.frame
  #   in.except.colon:
  #
  
  
  if ( !(in.except.colon %in% c(F,T)) ) {
    stop("in.except.colon %in% c(F,T) in trimVocaDf")
  }
  if(!checkDFandMatrix(in.voca)==T){
    if(!is.vector(in.voca)){
      stop("!is.vector(in.voca) in trimVocaDf")
    } else {
      return(trimVocaVector(in.voca, in.except.colon))
    }
    stop("!is.data.frame(in.voca) in trimVocaDf")
  }
    
  out.voca <- apply(in.voca, 2, function(x){trimVocaVector(x, in.except.colon)})
  if (nrow(in.voca) == 1) {
      out.voca <- t(out.voca) 
  }
  rownames(out.voca) <- rownames(in.voca)
  colnames(out.voca) <- colnames(in.voca)
  return(out.voca)
}


library(stringr)
preprocessPData <- function(in.pData){
  # preprocessing for each phenotype data
  
  
  if (!is.data.frame(in.pData)) {
    stop("(!is.data.frame(in.pData))")
  }
  
  splitDataWithColon <- function(in.x, in.decreasing = T){
    # split vector of a:b -> a & b 
    #
    # arg:
    #   in.decreasing - T: last ":" is cutted
    #   in.decreasing - F: first ":" is cutted
    
    position.of.cut <- sort(str_locate_all(in.x, ":")[[1]][,"start"],decreasing = in.decreasing)[[1]]
    return(c(substr(in.x,1,position.of.cut-1),substr(in.x, position.of.cut+1, nchar(in.x))))
  }
  
  
#####################################################################
#splitDfwithFxValue
####################################################################
  
  splitDfWithFxValue <- function(in.selected.df, in.decreasing = T){  
    # apply splitDataWithColon in data.frame
    #
    # arg:
    #   in.decreasing - T: last ":" is cutted
    #   in.decreasing - F: first ":" is cutted    

      
    ##temporary pData 
   # in.selected.df <- pData[ , 'X8', drop = F]     
   #in.decreasing = T      
    ##temporary pData end
      
    if(checkDFandMatrix(in.selected.df)==F){
        stop("if (!is.data.frame(in.selected.df)) {")
    }
    if (ncol(in.selected.df) != 1) {
        stop("if (ncol(in.selected.df) != 1) {")
    }

    tmpSpecificReg <- "^((\\w|\\+|\\-)+)(:|\\s)\\s*((\\w+:([[:alnum:].]+,)\\s*)+(\\w+:[[:alnum:].]+))$"
    
    tmp.data <- data.frame(value = rep(NA, nrow(in.selected.df)),value2= rep(NA, nrow(in.selected.df)))
  
    for ( rowcount in 1:nrow(in.selected.df)) {
        selected.df <- in.selected.df[rowcount, ]
        if(grepl(tmpSpecificReg, selected.df)==T){
            tmp.data.feature <-gsub(tmpSpecificReg, "\\1", selected.df)
            tmp.data.value <-gsub(tmpSpecificReg, "\\4", selected.df)   
            tmp.data[rowcount,] <- c(tmp.data.feature, tmp.data.value)
        }else{
            tmp.data[rowcount,] <- splitDataWithColon(selected.df, in.decreasing)
        }
    }
    # tmp.data <- t(apply(in.selected.df, 1, function(x){splitDataWithColon(x, in.decreasing)}))         #17/06/23 backup
    
    tmp.data <- t(apply(tmp.data, 1, function(in_x){trimVoca(in_x, in.except.colon = T)}))
    
    return(tmp.data)
  }
  ##########################################################################################################
  #getColnameVector
  ###########################################################################################################
  getColnameVector <- function(in.selected.df){
    tmp.data <- splitDfWithFxValue(in.selected.df)
    
    #GSE593 needed col
    tmp.data[ ,1] <- trimVoca(tmp.data[ ,1], in.except.colon = T)
    
    #TODO
    for( tmp.vec in seq(1, length(tmp.data[ ,1])) ){
      if(tmp.data[tmp.vec,1] %in% names(G_featureVocaSynonym)){
        tmp.data[tmp.vec,1] <- G_featureVocaSynonym[which(tmp.data[tmp.vec,1] == names(G_featureVocaSynonym))]
      }
    }
    tmp_nrow_G_featureVocaRegix <- nrow(G_featureVocaRegix)
    if (tmp_nrow_G_featureVocaRegix >= 1) {
      for ( tmp.row.regix in seq(1, tmp_nrow_G_featureVocaRegix) ) {
        tmp.data[ ,1] <- sub( paste0(".*", G_featureVocaRegix[tmp.row.regix, "feature.regix"], ".*"),
                              G_featureVocaRegix[tmp.row.regix, "feature.voca"],
                              tmp.data[ ,1]
        )
      }      
    }
    return(tmp.data[ ,1])
  }  
  
  getColnameCandidate <- function(in.selected.df){
    return.vec.colname.candidate <- unique(getColnameVector(in.selected.df))
    if (any(which(return.vec.colname.candidate == ""))) {
      return.vec.colname.candidate <- return.vec.colname.candidate[ -which(return.vec.colname.candidate == "") ]      
    }
    
    return(return.vec.colname.candidate)
  }  
  
  splitColumn <- function(in.pdata, in.char.split){
    tmp.data <- apply(in.pdata, 1, function(x){lapply(strsplit(x, in.char.split),
                                                      function(x){if(length(x) == 0){""}else{x}})})
    tmp.row.num <- length(tmp.data)
    tmp.col.num <- max(sapply(tmp.data,function(x){length(unlist(x))}))
    out.pData <- data.frame(matrix("", nrow = tmp.row.num, ncol = tmp.col.num), stringsAsFactors = F)
    for(tmp.var in seq(1, tmp.row.num)){
      tmp.unlisted.row.data <- unlist(tmp.data[[tmp.var]])
      out.pData[tmp.var, seq(1,length(tmp.unlisted.row.data))] <- as.character(tmp.unlisted.row.data)
    }
    return(out.pData)
  }
  
  splitColumnUsingRegix <- function(in.pdata, in.regix){
    tmp.split.string <- ":::::"
    tmp.data <- apply(in.pdata, 1:2, function(x){sub(paste0("(", in.regix, ")"),
                                                     paste0(tmp.split.string, "\\1", tmp.split.string),
                                                     x
    )})
    out.data <- splitColumn(tmp.data, tmp.split.string)
    return(out.data)
  }

  selArrage <- function(in_pData, in_split_char){
      tmpSel <- grepl(in_split_char, in_pData)
      tmpUnSel <- !tmpSel
      pDataSelTmp <- splitColumn(in_pData[tmpSel , , drop = F], in_split_char)     
      if (any(tmpUnSel)) {
          pDataUnSelTmp <- in_pData[tmpUnSel, , drop = F]
          in_pData <- data.frame(row.names = rownames(in_pData))
          in_pData[ , 'XX'] <- ""
          in_pData[ , colnames(pDataSelTmp) ] <- ""
          in_pData[tmpSel , colnames(pDataSelTmp)] <- pDataSelTmp
          in_pData[tmpUnSel, 'XX'] <- pDataUnSelTmp
      } else {
          in_pData <- pDataSelTmp
      }
      return(in_pData)
  }
  
  
  flag.auto.pass <- F
  
  tmp.pData <- in.pData
  pDataRowName <- rownames(in.pData)  
  
  tmp.pData <- apply(tmp.pData,1:2,function(x){tolower(iconv(x,"latin1", "ASCII", "_") )})
  
  colnames(tmp.pData) <- tolower(colnames(tmp.pData))
  #   pData <- tmp.pData[ ,grep("(characteristics_ch1|description)",colnames(tmp.pData)), drop = F]
  pData <- tmp.pData[ , grep("characteristics_ch1", colnames(tmp.pData)), drop = F]
  
  if ( ncol(pData) == 0) {
      pData <- tmp.pData[ ,"description", drop = F]
      if(ncol(pData) != 1){
          stop("pData <- tmp.pData[ ,'description', drop = F] in preprocessPData")
      }
  }
  pData <- apply(pData, 1:2, function(in_x){
    if(is.na(in_x)){
      return("")
    } else {
      return(in_x)
      }
    })
  # pData[is.na(pData), ] <- ""

    
    #######################################################################
      #"number-number: " this shape cutting
      #"\\d-\\d:"
      
      tmpReg3 <- "^\\d+\\-\\d+:"
      
      pData <-gsub(tmpReg3,"",pData)

    #######################################################################    

      
      
     if (any(grepl(";", pData))) {
        pData <- selArrage(pData, ";")
        } else {
            if ( all(grepl(",", pData))) {
            ################################################################################
            # this line needs more details modify
            # if (length(grep(":", pData)) %in% c(0, nrow(length(grep(",", pData) + 1)))) {
            #################################################################################
                if(all(sapply(gregexpr(":", pData), length) <= (sapply(gregexpr(",", pData), length) + 1))){
                    pData <- selArrage(pData, ",")
                }
            }
        }
  if(nrow(G_dfChangeRawDataUsingRegix) != 0){
    for(tmp.nrow in seq(1,nrow(G_dfChangeRawDataUsingRegix))){
      pData <- apply(pData, 1:2, function(x){ sub(G_dfChangeRawDataUsingRegix[ ,"feature.before"],
                                                  G_dfChangeRawDataUsingRegix[ ,"feature.after"],
                                                  x) })
    }    
  }
  
  for(tmpSplitRegix in G_featureSplitRegix){
    pData <- splitColumnUsingRegix(pData, tmpSplitRegix)  
  }
  
  pData <- trimVoca(pData, in.except.colon = T)
  
  # Remove blank columns
  for (k in ncol(pData):1) {
      if (all(nchar(pData[, k]) == 0)) {
          pData <- pData[ , -k, drop = F]
      }
  }
  

  # Handling blank data & check separator between feature and data
  #     ex) "age 40; age 45"
  #     ex2) "age=40; age=45"
  for (tmp.num.col in seq(1, ncol(pData))) {
    tmp.col <- colnames(pData)[tmp.num.col]
    
    vec.col <- unlist(pData[ ,tmp.col, drop=F])
    vec.col.except.blank <- vec.col[vec.col != ""]
    
    if(any(grepl( "=", vec.col))){
      vec.col <- gsub("=", ":", vec.col)
      pData[ , tmp.col] <- vec.col
    }
    
    if ( all(countStr(vec.col.except.blank, ":", "") == 0) ) {
      if ( all(countStr(vec.col.except.blank, " ", "") == 1)) {
        tmp.df <- pData[trimVoca(pData[ ,tmp.num.col])!= "", tmp.num.col, drop=F]
        tmp.df[ ,1] <- gsub(" ", ":", unlist(tmp.df))
        tmp.df <- splitDfWithFxValue(tmp.df)        
        if( length(unique(tmp.df[,1])) == 1){
          vec.col <- gsub(" ", ":", vec.col)
          pData[ , tmp.col] <- vec.col                  
        }
      }
    }
    
    vec.col.no.colon <- !grepl( ":", vec.col)
    pData[vec.col.no.colon, tmp.col] <- paste0(vec.col[vec.col.no.colon],":")
  }
  
  
  # Maybe, this block finds the features that exist in same column.
  for (tmp.num.col in seq(1, ncol(pData))) {
    tmp.col <- colnames(pData)[tmp.num.col]
    tmp.colname.Separator <- getColnameVector(pData[ ,tmp.col,drop=F])
    if( all(grepl( ":", tmp.colname.Separator) )){
      tmp.colname.vector <- getColnameVector(as.data.frame(tmp.colname.Separator, stringsAsFactors = F))
      if( length(unique(tmp.colname.vector)) == nrow(pData)){
        temp.flag.for.compare = F
        for (tmp.num.col.for.compare in seq(1, ncol(pData)) ){
          if ( all(sort(tmp.colname.vector) == sort(trimVoca(pData[ ,tmp.num.col.for.compare]))) ) {
            temp.flag.for.compare = T
            break
          }          
        }
        if (temp.flag.for.compare == T) {
          tmp.df <- splitDfWithFxValue(pData[ ,tmp.col,drop = F] , in.decreasing  = F)
          pData[ ,tmp.col] <- trimVoca(tmp.df[ ,2])
        }
      }
    }
  }
  
  # find colname candidiate 
  list.colname.candidate <- list()
  for (tmp.num.col in seq(1, ncol(pData))) {
    tmp.col <- colnames(pData)[tmp.num.col]
    tmp.colname.candidate <- getColnameCandidate(pData[ ,tmp.col,drop=F])
    if(length(tmp.colname.candidate) > 1){
      cat(" Multiple candidate column names in processing pData in single line\n")
      cat("  candidates: ", paste(tmp.colname.candidate, collapse = ', ') , '\n')
      cat("  column number:", tmp.num.col ,'\n')
    }
    
    list.colname.candidate[[tmp.num.col]] <- rep(0, length(tmp.colname.candidate))
    
    names(list.colname.candidate[[tmp.num.col]]) <- tmp.colname.candidate
  }
  
  # determine colnames
  vec.final.colname <- rep(NA, length(list.colname.candidate))
  for (tmp.num.list in seq(length(list.colname.candidate), 1)) {
    tmp.list.colname.candidate <- list.colname.candidate[[tmp.num.list]]
    if (length(tmp.list.colname.candidate) == 1) {
      vec.final.colname[tmp.num.list] <- names(tmp.list.colname.candidate)
      next
    }
    if (tmp.num.list == length(list.colname.candidate)) {
      vec.final.colname[tmp.num.list:(tmp.num.list + length(tmp.list.colname.candidate)-1)] <- names(tmp.list.colname.candidate)
      next
      #stop("tmp.num.list == length(list.colname.candidate) in preprocessPData!")
    }
    selected.name <- names(tmp.list.colname.candidate)[!(names(tmp.list.colname.candidate) %in% vec.final.colname[!is.na(vec.final.colname)])]
    if (length(selected.name) > 1){
      if(tmp.num.list == 1){
        vec.final.colname <- c(selected.name,
                               vec.final.colname[2:length(vec.final.colname)])
      } else {
        vec.final.colname <- c(vec.final.colname[1:(tmp.num.list - 1)],
                               selected.name,
                               vec.final.colname[(tmp.num.list + 1):length(vec.final.colname)])
      }
      
      
      #stop("length(selected.name) >= 1 in preprocessPData")
    } else if (length(selected.name) == 1) {
      vec.final.colname[tmp.num.list] <- selected.name  
    } else {
      vec.final.colname[tmp.num.list] <- NA
    }
  }
  
  for (tmp.num.list in seq(1, length(list.colname.candidate))) {
    for (tmp2.num.list in seq(1, length(list.colname.candidate[[tmp.num.list]]))) {
      for (tmp3.num.list in seq(tmp.num.list + 1, length(vec.final.colname))) {
        if (names(list.colname.candidate[[tmp.num.list]][tmp2.num.list]) %in% vec.final.colname[tmp3.num.list]) {
          list.colname.candidate[[tmp.num.list]][tmp2.num.list] <- tmp3.num.list - tmp.num.list
        }
      }      
    }
  }
  
  shiftdata.frame <- data.frame(pData)
  shiftdata.frame <- apply(shiftdata.frame,1:2,function(x){return(0)})
  for (tmp.num.col in seq(1, dim(pData)[2])) {
    tmp.col <- colnames(pData)[tmp.num.col]
    tmp.colname.vector <- getColnameVector(pData[ ,tmp.col,drop=F])
    for (tmp.num.list.colname.candidate in seq(1, length(list.colname.candidate[[tmp.num.col]]))) {
      vec.row.sel <- tmp.colname.vector %in% names(list.colname.candidate[[tmp.num.col]][tmp.num.list.colname.candidate])
      shiftdata.frame[vec.row.sel,tmp.num.col] <- list.colname.candidate[[tmp.num.col]][tmp.num.list.colname.candidate]
    }
  }
  
  if (!all(dim(shiftdata.frame) == dim(pData))) {
    stop ("(!all(dim(shiftdata.frame) == dim(pData))) in preprocessPData ")
  }
  if (dim(pData)[2] != length(vec.final.colname)) {
    if (dim(pData)[2] > length(vec.final.colname)) {
      stop("dim(pData)[2] > length(vec.final.colname) in preprocessPData")
    }
    pData <- cbind(pData,matrix(":", nrow = nrow(pData), ncol = (length(vec.final.colname) - ncol(pData))))
  }
  
  for (tmp.num.df in seq(dim(shiftdata.frame)[2] ,1)) {
    vec.shiftdata.frame <- shiftdata.frame[ ,tmp.num.df]
    unique.vec.shiftdata.frame <- unique(vec.shiftdata.frame)
    for (tmp.unique.vec.shiftdata.frame in unique.vec.shiftdata.frame) {
      if (tmp.unique.vec.shiftdata.frame == 0) {
        next
      }
      row.sel.for.move <- (tmp.unique.vec.shiftdata.frame == vec.shiftdata.frame)
      pData[row.sel.for.move, tmp.num.df + tmp.unique.vec.shiftdata.frame] <- pData[row.sel.for.move, tmp.num.df]
      pData[row.sel.for.move, tmp.num.df] <- ":"
    }
  }  
  for (tmp.col.num in seq(dim(pData)[2],1)) {
    if (all(unique(pData[ ,tmp.col.num]) == ":")){
      pData <- pData[ ,-tmp.col.num, drop = F]
    }
  }
  
  out.df <- data.frame(row.names = pDataRowName)
  
  for (tmp.num.col in seq(1, ncol(pData))) {
    vecColnameCandidate <- getColnameCandidate(pData[ ,tmp.num.col, drop=F])    
    tmp.data <- splitDfWithFxValue(pData[ ,tmp.num.col, drop=F])
    tmpDf <- trimVoca(tmp.data[ ,2,drop = F], in.except.colon = T)
    if (all(tmpDf == "")) {
      tmpDf[ ,1] = F
      tmpDf[tmp.data[ ,1,drop = F] != "",1] = T
    }
    tmp.data <- splitDfWithFxValue(pData[ ,tmp.num.col, drop=F])
    tmpDf[tmpDf %in% NAStringVector] <- NA
    colnames(tmpDf) <- vecColnameCandidate
    
    out.df <- cbind(out.df, tmpDf)    
  }
  
  ###adding description column data 
  # c_description <- "description"
  # if (c_description %in% colnames(in.pData)) {
  #     if (c_description %in% colnames(out.df)) {
  #         colnames(out.df)[which(colnames(out.df) == c_description)] <- paste(c_description, "_feature", sep = "")
  #     }
  #     tmp.df <- in.pData[ , c_description]
  #     tmp.df <- ifelse(tmp.df == "", NA, tmp.df)
  #     tmp.df <- data.frame(description = tmp.df)
  #     out.df <- cbind(out.df, tmp.df)
  # }

  if (COL_NAME_GEO_SAMPLE %in% colnames(out.df)) {
      out.df <- out.df[ , -which(COL_NAME_GEO_SAMPLE == colnames(out.df))]
  }
    
  tmp.df <- in.pData[ ,c("geo_name", "geo_accession", "platform_id", "source_name_ch1")]
  colnames(tmp.df) <- c(COL_NAME_GSE_NUM, COL_NAME_GEO_SAMPLE, COL_NAME_PLATFORM_ID, "source_name_ch1")
  tmp.df$source_name_ch1 <- tolower( tmp.df$source_name_ch1 )
  out.df <- cbind(tmp.df, out.df)
  
  if ("source_name_ch2" %in% colnames(tmp.df)) {
    out.df <- cbind(out.df, in.pData[ ,c("source_name_ch2"), drop = F])
  }
  

  
  colnames.of.out.df <- colnames(out.df)
  reg.str.to.remove <- paste0(const_removeInColnames, collapse = '|')
  # remove unused word in data
  colnames(out.df) <- str_trim(sub(reg.str.to.remove, '', colnames.of.out.df))
  
  if (any(duplicated(colnames(out.df)))) {
    stop("any(duplicated(colnames(out.df))) in preprocessPData")
  }
  return(out.df)
}

mergeDF <- function(in.pdata1, in.pdata2){
  
  # hypo: individual row 
  if (min(dim(in.pdata1)) == 0) {
    return(in.pdata2)
  }
  if (min(dim(in.pdata2)) == 0) {
    return(in.pdata1)
  }
  
  out.pdata1 <- in.pdata1
  setdiffFrom2To1 <- setdiff(colnames(in.pdata2), colnames(in.pdata1))
  if (length(setdiffFrom2To1) > 0) {
    tmp.matrix <- matrix(NA, 
                         nrow = nrow(out.pdata1), 
                         ncol = length(setdiffFrom2To1),
                         dimnames = list(rownames(out.pdata1), 
                                         setdiffFrom2To1)
    )
    out.pdata1 <- cbind(out.pdata1, tmp.matrix)
  }
  
  out.pdata2 <- in.pdata2
  setdiffFrom1To2 <- setdiff(colnames(in.pdata1), colnames(in.pdata2))
  if (length(setdiff(colnames(in.pdata1), colnames(in.pdata2))) > 0) {
    tmp.matrix <- matrix(NA, 
                         nrow = nrow(out.pdata2), 
                         ncol = length(setdiffFrom1To2),
                         dimnames = list(rownames(out.pdata2), 
                                         setdiffFrom1To2)
    )
    out.pdata2 <- cbind(out.pdata2, tmp.matrix)
  }  
  
  
  return( rbind(out.pdata1, out.pdata2) )
}

checkGeo2R <- function(in.pdata.save){
  # manually check GEO data
  #
  # arg: 
  #   in.pdata.save - pdata list made by getGEOpData
  
  for (pdata.save.name in names(in.pdata.save)) {
    cat("==================================================\n")
    cat("GEO names:", pdata.save.name, "\n")
    cat("==================================================\n")
    tmp.pdata.save <- in.pdata.save[[pdata.save.name]]
    for (tmp.names in names(tmp.pdata.save)) {
      tmp <- names( summary(as.factor(tmp.pdata.save[ ,tmp.names]) ) )
      tmp <- tmp[tmp != ""]
      cat(tmp.names, "~", tmp[1], "\n",sep="")
    }
    
    for (tmp.names in names(tmp.pdata.save)) {
      cat("\tCharacters:", tmp.names, "\n")
      cat("\t------------------------------------------\n")
      print(summary(as.factor(tmp.pdata.save[, tmp.names]), maxsum = 10))
      tmp = scan(n=1, quiet=T, what="character")
      if (length(tmp) != 0 ) {
        if(tolower(tmp) == "p") {
          break        
        }
      }      
    }
  }
}


summaryPdata <- function(in.pdata.save){
  # Merge phenotype data and delete duplicated data(except gse name)
  
  
  if (any(is.na(names(in.pdata.save)))) {
    stop("(any(is.na(names(in.pdata.save))))")
  }
  
  summarized.df <- data.frame()
  for (tmp.num.in.pdata.save in seq(1,length(in.pdata.save))) {
    cat("Name: ", names(in.pdata.save[tmp.num.in.pdata.save]),"\n")
    gseName <- sub("^(GSE\\d{1,})__.*$", "\\1", names(in.pdata.save[tmp.num.in.pdata.save]))
    
    tmp.in.pdata.save <- data.frame(geo_name = gseName, in.pdata.save[[tmp.num.in.pdata.save]])
    if( dim(summarized.df)[1] == 0){
      summarized.df <- preprocessPData(tmp.in.pdata.save)
    } else {
      tmp.data <- preprocessPData(tmp.in.pdata.save)
      summarized.df <- mergeDF(summarized.df, tmp.data)
    }
  }
  summarized.df.except.gse.name <- summarized.df[ ,-which(colnames(summarized.df) == COL_NAME_GSE_NUM)]
  row.vec.of.duplicated.data <- !(duplicated(summarized.df.except.gse.name))
  summarized.df.except.duplication <- summarized.df[row.vec.of.duplicated.data, ]
  if (any(duplicated(summarized.df.except.duplication[ ,COL_NAME_GEO_SAMPLE]))) {
    print(paste0(paste(duplicated(summarized.df.except.duplication[ ,COL_NAME_GEO_SAMPLE]), sep = ','), " is(are) duplicated gse name"))
    stop()
  }
  
  return(summarized.df.except.duplication)
}

summaryColumnOfDf <- function(in.data.frame, in.maxsum = 10, in.stop = T) {
  for (temp in colnames(in.data.frame)) {
    cat("===================\n")
    cat("Colnames:",temp,'\n')
    cat("--------------------\n")
    print(data.frame(count = summary(as.factor(in.data.frame[ ,temp]), in.maxsum)))
    cat("===================\n")
    if (in.stop == T) {
      cat("If you want to quit, press q and enter\n")
      returnKey <- scan(n=1, quiet=T, what="character",sep = "\n")
      if (length(returnKey) != 0) {
        if (tolower(returnKey) == "q") {
          break
        }    
      }      
    }
  }  
}


summaryVec <- function(in.vec, in.maxsum = 10, in.stop = T){
  in.data.frame.selected  <- data.frame(data = in.vec)
  summaryColumnOfDf(in.data.frame.selected, in.maxsum, in.stop)
}


outNoNAColumnInDf <- function(in.df) {
  # delete all NA column in data.frame
  
  
  ori.colnames <- colnames(in.df)
  sel.colnames <- c()
  for (tmp.ori.colnames in ori.colnames) {
    if (!all(is.na(in.df[,tmp.ori.colnames]))) {
      sel.colnames <- c(sel.colnames, tmp.ori.colnames)
    }
  }
  return(in.df[ , sel.colnames])
}

outRegColInDf <- function(in.reg, in.df, in.col) {
  # extract in.reg shape in in.col of in.df
  
  
  tmp.data.frame <- in.df[grepl(in.reg, in.df[ ,in.col]), ]
  return(sub(paste0('^.*(', in.reg, ').*$'), '\\1', tmp.data.frame[ ,in.col]))
}


selColData <- function(in.vec, in.reg, in.exact.flag = F) {
  # return the vector satisfing the regular expression among the vector
  # If not satisfying, NA value will be return in vector.
  
  if (in.exact.flag == T) {
    complete.reg <- paste0("^(",in.reg,")$")  
  } else {
    complete.reg <- paste0("(",in.reg,")")      
  }
  
  out.vec <- sapply(in.vec, function(x){
    ifelse( grepl(complete.reg, x), 
            if (in.exact.flag == T) {
              x
            } else {
              sub(paste0('^.*?', complete.reg, '.*?$'), '\\1', x)
            },
            NA )
  })  
  return(out.vec)
}

mergeFinalCol <- function(in.vec1, in.vec2){
  # merge in.vec1 and in.vec2 
  #   in.vec1 and in.vec2 must be same length
  #   If in.vec1's data and vec2's data is not NA, compare the data.
  #   When value is not equal, print the column number of data
  
  length.of.vec = length(in.vec1)
  if (length.of.vec != length(in.vec2)) {
    stop("(length(in.vec1) != length(in.vec2))")
  }
  
  outputVec <- rep(NA, length.of.vec)
  for ( i in 1:length.of.vec ){
    if (!is.na(in.vec1[i])) {
      if (!is.na(in.vec2[i])) {
        if (in.vec1[i] != in.vec2[i] ){
          cat(paste0("In location :",i,", in.vec1 is '",in.vec1[i], "' but in.vec2 is '",in.vec2[i],"'" ), '\n')
        }
      }
      outputVec[i] <- in.vec1[i]
    } else {
      outputVec[i] <- in.vec2[i]
    }
  }
  return(outputVec)
}


withSepWord <- function(in.data) {
  return(paste0('\\b', in.data, '\\b'))
}


findGseTitleSummaryInGeoVec <- function(in.vec.geo.name){
  # find GSE title and summary using gse name's vector
  
  out.data.frame <- data.frame()
  for (tmp in in.vec.geo.name) {
    tmp.result <- findGseTitleSummary(tmp)
    out.data.frame <-
      rbind(out.data.frame,
            data.frame(gse.num = tmp,
                       title = tolower(tmp.result$title),
                       summary = tmp.result$summary))
  }
  return(out.data.frame)
}


findGseTitleSummary <- function(in.geo.name){
  # findGeoTitleSummary("GSE15622")
  
  
  
  
  #   reg.4.title <- "^.*Title\\n((\\w|\\s){1, })\\n.*$"
  reg.to.find.title <- "^.*Title\\n([[:alnum:] ()[:punct:]]+).*$"
  reg.to.find.summary <- "^.*Summary\\n([[:alnum:] ()[:punct:]]+).*$"
  
  fread.html <- html_session(paste0("http://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=", in.geo.name))
  # tr.data <- fread.html %>% html() %>% html_text()
  tr.data <- fread.html %>% read_html() %>% html_text()
  tr.data <- tr.data[[1]]
  
  if (grepl(reg.to.find.title, tr.data) == TRUE) {
    return.title <- sub(reg.to.find.title, '\\1', tr.data)
  } else {
    stop("(grepl(reg.4.title, tr.data) == TRUE)")
  }
  
  if (grepl(reg.to.find.summary, tr.data) == TRUE) {
    return.summary <- sub(reg.to.find.summary, '\\1', tr.data)
  } else {
    stop("(grepl(reg.4.title, tr.data) == TRUE)")
  }
  return(list(title = return.title, summary = return.summary))
}

fileExistCheck <- function(in.file.name.with.path) {
  
  
  return.value <- FALSE
  if (file.exists(in.file.name.with.path)) {
    if (!file.info(in.file.name.with.path)$isdir){
      return.value <- TRUE  
    }
  }
  return(return.value)
}


changeDfProbeIdGeneSymbol2listGeneSymboltoProbeId <- function (in.df.probe.id.gene.symbol) {
  
  
  if (!is.data.frame(in.df.probe.id.gene.symbol)) {
    stop("if (!is.data.frame(in.df.probe.id.gene.symbol)) {")
  }
  if ( all(c("ID", "Gene_Symbol") %in% rownames(in.df.probe.id.gene.symbol)) ) {
    stop('if ( all(c("ID", "Gene_Symbol") %in% rownames(in.df.probe.id.gene.symbol)) ) {')
  }  
  
  out.list.gene.symbol.to.probe.id <- list()
  for (j in 1:nrow(in.df.probe.id.gene.symbol)) {
    
    tmp.gene.symbol <- in.df.probe.id.gene.symbol$Gene_Symbol[j]
    tmp.probe.id <- in.df.probe.id.gene.symbol$ID[j]
    tmp.gene.symbol.split.corrected <- str_replace_all(tmp.gene.symbol, pattern = "/{3,}", "//")
    tmp.vec.gene.symbol <- str_trim(str_split(tmp.gene.symbol.split.corrected, "//")[[1]])
    for (tmp.gene.symbol in tmp.vec.gene.symbol){
      if (!is.na(tmp.gene.symbol) && (tmp.gene.symbol != "") && (tmp.gene.symbol != "NA")) {
        out.list.gene.symbol.to.probe.id[[tmp.gene.symbol]] <- c(out.list.gene.symbol.to.probe.id[[tmp.gene.symbol]], tmp.probe.id)        
      }
    }
  }
  names(out.list.gene.symbol.to.probe.id) <- suppressWarnings( checkGeneSymbols(names(out.list.gene.symbol.to.probe.id))$Suggested.Symbol )
  out.list.gene.symbol.to.probe.id[is.na(names(out.list.gene.symbol.to.probe.id))] <- NULL
  out.list.gene.symbol.to.probe.id[names(out.list.gene.symbol.to.probe.id) == "NA"] <- NULL
  
  pos.of.multiple.gene.in.check.gene.symbol <- which(!is.na(str_match(names(out.list.gene.symbol.to.probe.id), "///")))
  out.list.of.multiple.gene.in.check.gene.symbol <- out.list.gene.symbol.to.probe.id[pos.of.multiple.gene.in.check.gene.symbol]
  tmp.list.of.separating.of.multiple.gene.in.check.gene.symbol <- list()
  for( tmp in names(out.list.of.multiple.gene.in.check.gene.symbol)) {
    tmp.vec.gene.symbol <- str_trim(str_split(tmp, "///")[[1]])
    tmp.probe.id <- out.list.of.multiple.gene.in.check.gene.symbol[[tmp]]
    for (tmp.gene.symbol in tmp.vec.gene.symbol){
      if (!is.na(tmp.gene.symbol) && (tmp.gene.symbol != "") && (tmp.gene.symbol != "NA")) {
        tmp.list.of.separating.of.multiple.gene.in.check.gene.symbol[[tmp.gene.symbol]] <- 
          c(tmp.list.of.separating.of.multiple.gene.in.check.gene.symbol[[tmp.gene.symbol]], tmp.probe.id)
      }
    }
  }
  out.list.gene.symbol.to.probe.id[pos.of.multiple.gene.in.check.gene.symbol] <- NULL
  out.list.gene.symbol.to.probe.id <- c(out.list.gene.symbol.to.probe.id, 
                                        tmp.list.of.separating.of.multiple.gene.in.check.gene.symbol)
  
  duplicated.name <- unique(names(out.list.gene.symbol.to.probe.id)[duplicated(names(out.list.gene.symbol.to.probe.id))])
  for ( tmp.duplicated.name in duplicated.name) {
    tmp.pos <- which(names(out.list.gene.symbol.to.probe.id) == tmp.duplicated.name)
    tmp.merged.probe.id <- unique(unlist(out.list.gene.symbol.to.probe.id[tmp.pos]))
    out.list.gene.symbol.to.probe.id[tmp.pos] <- NULL
    out.list.gene.symbol.to.probe.id[[tmp.duplicated.name]] <- tmp.merged.probe.id
  }
  
  return(out.list.gene.symbol.to.probe.id)
}

makeGeneRowMatrix <- function(in.single.geno.data, 
                              in.single.feat.gene.symbol.to.probeID.data, 
                              in.merge.function = mean){
  
  
  out_df_for_gene_matrix <- data.frame(matrix(nrow = length(names(in.single.feat.gene.symbol.to.probeID.data)), 
                                              ncol = ncol(in.single.geno.data), 
                                              dimnames = list(names(in.single.feat.gene.symbol.to.probeID.data), 
                                                              colnames(in.single.geno.data))
                                              )
                                       )
  
  aggregateVec <- rep(NA, nrow(in.single.geno.data))
  names(aggregateVec) <- rownames(in.single.geno.data)
  tmpRowNameOfSingleGenoData <- rownames(singleGenoData)
  for (tmp.gene.name in names(in.single.feat.gene.symbol.to.probeID.data)){
    vec.probe.in.gene.name <- as.character(in.single.feat.gene.symbol.to.probeID.data[[tmp.gene.name]])
    if (!all(vec.probe.in.gene.name %in% tmpRowNameOfSingleGenoData)) {
      print(vec.probe.in.gene.name)
      stop(" if (!all(vec.probe.in.gene.name %in% names(singleGenoData))) {")
    }
    aggregateVec[vec.probe.in.gene.name] <- tmp.gene.name
  }
  out_df_for_gene_matrix <- aggregate(in.single.geno.data, list(gene = aggregateVec), in.merge.function)
  rownames(out_df_for_gene_matrix) <- out_df_for_gene_matrix$gene
  out_df_for_gene_matrix <- subset(out_df_for_gene_matrix, select = -gene)
  
  return(out_df_for_gene_matrix)
}


adjustBatchUsingCombat <- function(in.edata, in.batch) {
  
  #
  # arg
  #   in.edata: The column is case
  #   in.batch: batch number for merge
  
  
  
  # Sys.sleep(0.5)
  
  if ( ncol(in.edata)!= length(in.batch)){
    stop("if ( ncol(in.edata)!= length(in.batch)){")
  }
  memory.limit(4095 * 16 * 2)
  
  backup_rownames <- rownames(in.edata)
  backup_colnames <- colnames(in.edata)
  
  simplified.batch <- as.numeric(as.factor(in.batch))
  # modcombat <- model.matrix(~1, data = data.frame(simplified.batch))
  # combat_edata <- ComBat(dat = in.edata, batch = simplified.batch, mod = modcombat, par.prior=TRUE, prior.plots=FALSE)
  combat_edata <- removeBatchEffect(in.edata, simplified.batch)
  
  return(combat_edata)
}

mergeGData <- function(in.list.gdata) {
  #
  # arg
  #   in.list.gdata: list for gene expression datas
  
  
  if (!is.list(in.list.gdata)) {
    stop("if (!is.list(in.list.gdata)) {")
  }
  
  
  
  vec.common.row.name.of.gdata <- c()
  for (tmp.in.list.gdata in in.list.gdata) {
    row.name.of.gdata <- row.names(tmp.in.list.gdata)
    if (length(vec.common.row.name.of.gdata) == 0) {
      vec.common.row.name.of.gdata <- row.name.of.gdata
    } else {
      vec.common.row.name.of.gdata <- intersect(vec.common.row.name.of.gdata, row.name.of.gdata)
    }
  }
  
  vec.batch <- c()
  df.merged <- data.frame(row.names = vec.common.row.name.of.gdata)
  for (tmp.name.of.in.list.gdata in names(in.list.gdata)) {
    tmp.in.list.gdata <- in.list.gdata[[tmp.name.of.in.list.gdata]]
    vec.batch <- c(vec.batch, rep(tmp.name.of.in.list.gdata, ncol(tmp.in.list.gdata)))
    df.merged <- cbind(df.merged, tmp.in.list.gdata[vec.common.row.name.of.gdata, ])
  }
  return.data <- adjustBatchUsingCombat(in.edata = df.merged, in.batch = vec.batch )
  return(return.data)
}


cutOffselForSurvivalData <- function (y, x, in.sel.category.data = FALSE) {
  # Compute the best survival p-valued 2 group.
  #
  # Args:
  #   y: Survival Data of n x 2 data.frame
  #         first column: time
  #         second column: event(1: occured)
  #
  #   x: Continuous or categorial feature of nx1 data.frame
  #   in.sel.category.data: if FALSE, x is continuous, else x is category data
  #
  # Return:
  #		LimitOfGroup[]
  #		unLimitOfGroup[]
  #   	list['group'] : cut-off value string if x is continuous, group string if category
  #   	list['category'] : category
  #  	 	list['pValue'] :
  
  
  if ( !is.data.frame(y) ) {
    stop("!is.data.frame(y)")
  }
  if ( ncol(y) != 2 ) {
    stop("ncol(y) != 2")
  }
  if (is.data.frame(x)) {
    if (ncol(x) != 1) {
      stop("ncol(x) != 1")
    }
    if (nrow(x) != nrow(y)) {
      stop("nrow(x) != nrow(y)")
    }
  } else if (is.vector(x)) {
    if (length(x) != nrow(y)) {
      stop("length(x) != nrow(y)")
    }
  } else {
    stop("!is.data.frame(x) and !is.vector(x) ")
  }
  
  
  percent.cutoff <- 10
  
  
  
  fisher.test.data = groupPossible2Class(x, in.sel.category.data)
  sel.pvalue.position = 0
  sel.pvalue = 100
  
  sel.pvalue.position.limit.of.group = 0
  selPvalueLimitOfGroup = 100
  
  for (tmp in 1:length(fisher.test.data) ) {
    min.number.test.data <- as.factor(fisher.test.data[[tmp]]$category)
    min.number.test.data <- min.number.test.data[!is.na(min.number.test.data)]
    
    if (min(summary(min.number.test.data)) <= 2) {
      next
    }
    
    tmp.pvalue <- SurvDiffPValue(y[ , 1], y[ , 2], fisher.test.data[[tmp]]$category)
    if (tmp.pvalue < sel.pvalue) {
      sel.pvalue.position = tmp
      sel.pvalue = tmp.pvalue
    }
    
    # cut-off check
    ten.percent.cutoff = floor( length(fisher.test.data[[tmp]]$category) / percent.cutoff )
    tmp.data <- as.factor(fisher.test.data[[tmp]]$category[!is.na(fisher.test.data[[tmp]]$category)])
    if (min(summary(tmp.data)) >= ten.percent.cutoff) {
      if (tmp.pvalue < selPvalueLimitOfGroup) {
        sel.pvalue.position.limit.of.group = tmp
        selPvalueLimitOfGroup = tmp.pvalue
      }  		
    }
  }
  
  tmp.surv <- Surv(y[ , 1], y[ , 2] == 1)
  if (sel.pvalue.position.limit.of.group == 0) {
    cat("LimitOfGroup is impossible\n")
    print(summFac(x))
    list.of.limit.of.group <- NA
  } else {
    list.of.limit.of.group <- list(group = fisher.test.data[[sel.pvalue.position.limit.of.group]]$group,
                                   category = data.frame(category = fisher.test.data[[sel.pvalue.position.limit.of.group]]$category),
                                   pValue = selPvalueLimitOfGroup,
                                   cutOff = fisher.test.data[[sel.pvalue.position.limit.of.group]]$cutOff )
  }
  
  if (sel.pvalue.position != sel.pvalue.position.limit.of.group) {
    cat("UnLimitOfGroup\n")
    printOfcutOffselForSurvivalData(fisher.test.data,
                                    sel.pvalue.position,
                                    sel.pvalue,
                                    tmp.surv,
                                    paste(in.title, "unlimit") )
  }
  
  # if limitOfGroup is equal to unLimitOfGroup, unLimitOfGroup will be same as limitOfGroup
  return( list( LimitOfGroup = list.of.limit.of.group
                , unLimitOfGroup = list(group = fisher.test.data[[sel.pvalue.position]]$group,
                                        category = data.frame(category = fisher.test.data[[sel.pvalue.position]]$category),
                                        pValue = sel.pvalue,
                                        cutOff = fisher.test.data[[sel.pvalue.position]]$cutOff
                )
  )
  )
}

cutOffsel <- function (y, x, categoryData = F) {
  # Compute the best p-valued 2 group.
  #
  # Args:
  #   y: Classification n x 1 data.frame
  #   x: Continuous or categorial feature of nx1 data.frame
  #   categoryData: if FALSE, x is continuous, else x is category data
  #
  # Return:
  #   list['group'] : cut-off value string if x is continuous, group string if category
  #   list['category'] : category
  #   list['pValue'] :
  
  fisherTestData = groupPossible2Class(x, categoryData)
  
  selPvaluePosition = 0
  selPvalue = 100
  for (tmp in 1:length(fisherTestData) ) {
    fisherPvlaue = fisher.test( table(data.frame(y, fisherTestData[[tmp]]$category)) )$p.value
    #print(fisherPvlaue)
    if (fisherPvlaue < selPvalue) {
      selPvaluePosition = tmp
      selPvalue = fisherPvlaue
    }
  }
  return( list(group = fisherTestData[[selPvaluePosition]]$group,
               category = data.frame(category = fisherTestData[[selPvaluePosition]]$category),
               pValue = selPvalue,
               cutOff = fisherTestData[[selPvaluePosition]]$cutOff) )
}


# source("featureSave.R")


selPosOfFinalPData <- function(in.data.frame, in.sel.string) {
  
  # return row position of phenotype by "in.sel.string"
  #   ex)  "Tissue is breast and er is 0"
  # 
  # for now, only 'and' & 'is' is availiable
  
  
  sel.string <- tolower(in.sel.string)
  (sel.string <- gsub('\\bis\\b',' == ',sel.string))
  (sel.string <- gsub('\\band\\b',' & ',sel.string))
  (sel.string <- gsub('\\b([_a-zA-Z0-9]+)\\b\\s+==\\s+\\b([_a-zA-Z0-9]+)\\b',paste0('in.data.frame[ , \'\\1\'] == \'\\2\' '),sel.string))
  which(eval(parse(text = paste0(sel.string))))
}


boxplot4Gdata <- function(in.matrix.gene, in.vec.gene.group) {
  
  df4Boxplot.exp <- NULL
  df4Boxplot.group <- NULL
  
  for (tmp in 1:length(in.vec.gene.group)) {
    tmpExpVec <- in.matrix.gene[ ,tmp]
    df4Boxplot.exp <- c(df4Boxplot.exp , tmpExpVec)
    df4Boxplot.group <- c(df4Boxplot.group , rep(in.vec.gene.group[tmp], length(tmpExpVec)))
  }
  df4Boxplot <- data.frame(exp = df4Boxplot.exp, group = df4Boxplot.group)
  boxplot(exp ~ group, data = df4Boxplot)  
}

changeFilterPData <- function(in.filter.data, in.sel.col, in.regular.exp, in.post.process = NA){
  
  return.vec <- rep(NA, nrow(in.filter.data))
  tmp.regexpr <- regexpr(in.regular.exp, in.filter.data[ , in.sel.col])
  pos.to.change  <- which(tmp.regexpr > 0)
  out.regmatches <- regmatches(in.filter.data[ , in.sel.col], tmp.regexpr)
  vec.extract <- sub(in.regular.exp, '\\1', out.regmatches)
  
  if (!is.na(in.post.process)) {
    tmp.function <- eval(parse(text = in.post.process))
    vec.extract <- tmp.function(vec.extract)
  }
  
  return.vec[pos.to.change] <- vec.extract
  return(return.vec)
}


tidyupGenoData <- function(in_list_of_geno_data, in_gsm_to_process) {
  merged_data <- data.frame()
  group_test_gsm_num <- NULL
  out_group_num <- 1
  
  for( i in names(in_list_of_geno_data) ){
    tmp_list_pos <- which(colnames(in_list_of_geno_data[[i]]) %in% in_gsm_to_process )
    if (length(tmp_list_pos) > 0) {
      if (nrow(merged_data) == 0) {
        merged_data <- in_list_of_geno_data[[i]][ , tmp_list_pos, drop = FALSE]
      } else {
        merged_data <- t(mergeDF(t(merged_data),
                                 t(in_list_of_geno_data[[i]][ , tmp_list_pos, drop = FALSE])))        
      }
      group_test_gsm_num <- c(group_test_gsm_num, rep(out_group_num, times = length(tmp_list_pos)))
      out_group_num <- out_group_num + 1
    }
  }
  
  noSelectedGene <- apply(merged_data, 1, function(x){any(is.na(x))})
  merged_data <- merged_data[!noSelectedGene, ]
  
  return(list(merged_data = merged_data, 
              vec_group = group_test_gsm_num))
}

leftVecSel <- vectorizeConsideringNA(function(in.x, in.y){return(in.x)})


commandToShiny <- function(in_state, program_name, in_text, in_jsonMain2Shiny) {
  data_json <- list(state = in_state,
                    programName = program_name,
                    text = in_text)
  writeJsonCNewLine(data_json, in_jsonMain2Shiny)
}

writeJsonCNewLine <- function(in_list, in_file_path){
  dir.create(dirname(in_file_path), showWarnings = FALSE, recursive = TRUE)
  write(jsonlite::toJSON(in_list, pretty = TRUE), file = in_file_path)
}

checkCategoryOrContinuousOfDf <- function(in_df, in_category_lenght_limit = 4, in_category_na_min = 6) {
  # check each column
  
  out_category_col <- c()
  out_continuous <- c()
  out_na <- c()
  for (i in colnames(in_df)) {
    col_data <- na.omit(unique(in_df[ , i]))
    length_col_data <- length(col_data)
    if (length_col_data == 0) {
      out_na <- c(out_na, i)
    } else {
      if (!any(is.na(suppressWarnings(as.numeric(col_data)))) & 
          length_col_data > in_category_lenght_limit) {
        out_continuous <- c(out_continuous, i)
      } else {
        if (length_col_data <= in_category_na_min) {
          out_category_col <- c(out_category_col, i)
        } else {
          out_na <- c(out_na, i)                
        }
      }
    }
  }
  return(list(category = out_category_col, coutinuous = out_continuous, na = out_na))
}

tryNa <- function(...) {
  out <- try(...)
  if (class(out) == "try-error") {
    return(NA)
  } else {
    return(out)
  }
}


tryInf <- function(...) {
    try_count <- 20
    while (try_count) {
        out <- tryNa(...)
        if (!all(is.na(out))) {
            return(out)
        }
        try_count <- try_count - 1
    }
    stop("tryInf error")
}


`%+%`  <- function(in.left, in.right) {
  paste(in.left, in.right, sep = '')
}


knitrByCommand <- R6Class("knitrByCommand",
                          public = list(
                            current.dir =  NA,
                            tmp.dir = NA,
                            rmd.filename = NA,
                            rmd.file = NA,
                            md.file = NA,
                            output.dir = NA,
                            flag_html = NA,
                            initialize = function(in.rmd.filename, in.current.dir,
                                                  in.output.dir = "result", in_flag_html = FALSE) {
                              tmp.dir <- makeTmpFolder()
                              rmd.basename <- in.rmd.filename %+% ".Rmd"
                              
                              rmd.file <- fitFilePath(in.current.dir, rmd.basename)
                              md.file <- fitFilePath(tmp.dir, in.rmd.filename %+% ".md")
                              output.dir <- ifelse(checkAbsPath(in.output.dir), 
                                                   in.output.dir,
                                                   fitDirPath(in.current.dir, in.output.dir))
                              dir.create(output.dir, showWarnings = FALSE, recursive = TRUE)
                              
                              self$current.dir <- in.current.dir
                              self$tmp.dir <- tmp.dir
                              self$rmd.filename <- in.rmd.filename
                              self$rmd.file <- rmd.file
                              self$md.file <- md.file
                              self$output.dir <- output.dir
                              self$flag_html <- in_flag_html
                            },
                            run = function(in.filename = NA) {
                              on.exit(setwd(self$current.dir))      
                              
                              if (is.na(in.filename)) {
                                output.dir <- self$output.dir
                                out.filename <- self$rmd.filename
                              } else {
                                output.dir <- fitDirPath(self$output.dir, self$rmd.filename)
                                dir.create(output.dir, showWarnings = FALSE, recursive = TRUE)
                                out.filename <- in.filename
                              }
                              
                              if (self$flag_html) {
                                tmp <- 
                                  rmarkdown::render(input = self$rmd.file,
                                                    intermediates_dir = self$tmp.dir,
                                                    output_file = 
                                                      fitFilePath(output.dir, out.filename %+% '.html'))        
                              } else {
                                setwd(self$tmp.dir)
                                knit(self$rmd.file, output = self$md.file, encoding = "CP949")
                                system(
                                  "pandoc +RTS -K512m -RTS \"" %+%
                                    self$md.file %+% "\" --to docx " %+%
                                    " --from markdown+autolink_bare_uris+ascii_identifiers+tex_math_single_backslash-implicit_figures " %+%
                                    " --output \"" %+% fitFilePath(output.dir, out.filename %+% '.docx') %+% "\" " %+%
                                    " --highlight-style tango " %+% 
                                    " --reference-docx \"" %+% pathKnitrTemplate %+% "\" ")
                              }
                            },
                            end = function(in.str.mail.to.me = NA, in.not.notice = FALSE) {
                              unlink(fitFilePath(self$tmp.dir), recursive = TRUE, force = TRUE)
                            }
                          )
)                          

makeTmpFolder <- function(in_root_path = pathTempDir) {
  
  if ( !dir.exists(in_root_path) ) {
    stop("if ( !dir.exists(fitDirPath(in_root_path)) ) {")
  }
  
  number.of.folder.name <- 5
  max.number.of.folder.name <- 100
  while(T) {
    tmp.folder.name <- paste0("__tmp__", makeRandomName(number.of.folder.name), collapse = "")
    root.path.with.tmp.folder.name <- file.path(in_root_path, tmp.folder.name)
    if ( !file.exists(root.path.with.tmp.folder.name) ) {
      dir.create(root.path.with.tmp.folder.name, showWarnings = FALSE)
      return(root.path.with.tmp.folder.name)
    }
    if (number.of.folder.name >= max.number.of.folder.name) {
      stop("Making random directory is failed!")
    }
    number.of.folder.name <- number.of.folder.name + 1
  }
}

makeRandomName <- function(in.length.str){
  make.names(paste(sample(c(0:9, letters, LETTERS), in.length.str, replace = TRUE), collapse = ""))
}

checkAbsPath <- function(in_str_path) {
  # ret:
  #   TRUE: absolute path
  
  return(grepl("^([/\\]|[a-zA-Z]:[/\\])", in_str_path))
}


mainFunForCutoffSel4Discrete <- function(in.value, in.vec.group){
  
  out.pvalue <- fisher.test(table(data.frame(in.value, in.vec.group)))$p.value  
  return(out.pvalue)
}


mainFunForCutoffSel4Continuouse <- function(in.vec.data, in.vec.group){
  
  
  if (length(as.vector(in.vec.data)) != length(as.vector(in.vec.group)))
    stop('if (length(as.vector(in.vec.data)) != length(as.vector(in.vec.group)))')    
  if (length(as.vector(in.vec.data)) <= 3) stop('if (length(as.vector(in.vec.data)) <= 3)')  
  
  if (min(table(in.vec.group)) == 1) {
    vec.group0 <- in.vec.data[in.vec.group == 0]
    vec.group1 <- in.vec.data[in.vec.group == 1]
    if (length(vec.group0) == 1) {
      tmp.mu <- vec.group0
      tmp.vec.for.t.test <- vec.group1
    } else {
      tmp.mu <- vec.group1
      tmp.vec.for.t.test <- vec.group0
    }
    out.pvalue <- t.test(x = tmp.vec.for.t.test, mu = tmp.mu)$p.value      
  } else {
    out.pvalue <- t.test(in.vec.data ~ in.vec.group)$p.value      
  }
  return(out.pvalue)
}


mainFunForCutoffSel4Survival <- function(in.vec.time, in.vec.occured, in.vec.group){
  
  # arg
  #   in.vec.occured: event(1 - occured)
  
  
  if (min(summary(na.omit(as.factor(in.vec.group)))) <= 2) {
    return(1)
  }
  
  out.pvalue <- SurvDiffPValue(in.vec.time, in.vec.occured, in.vec.group)
  return(out.pvalue)
}


closure4CutoffSel <- function(in.function){
  
  out.function <- function(..., in.vec.cut.off, in.flag.category = F, in.flag.plot = T){
    
    # Compute the best p-valued 2 group.
    #
    # Args:
    #   ...: parameter for in.function
    #   in.vec.cut.off: continuous or categorical feature 
    #   in.flag.category: if FALSE, in.vec.cut.off is continuous, else in.vec.cut.off is category data
    #
    # Return:
    #   list['groupText'] : cut-off value string if in.vec.cut.off is continuous, group string if category
    #   list['vecGroup'] : vector for group
    #   list['pValue'] :
    #   list['cutoff'] :
    
    
    if (length(na.omit(unique(in.vec.cut.off))) <= 1) {
      catE("vec.cut.off is none or only 1 data!")
      
      return(list(LimitOfGroup = list(groupText = NA,
                                      vecGroup = NA,
                                      pValue = NA,
                                      cutoff = NA),
                  unLimitOfGroup = list(groupText = NA,
                                        vecGroup = NA,
                                        pValue = NA,
                                        cutoff = NA)))
    }
    
    ratio.limit.cutoff <- 0.1
    
    tmp.group.data <- groupPossible2Class(in.vec.cut.off, in.flag.category)
    
    sel.pvalue.position <- -1
    selected.pvalue <- 100
    init.limit.sel.pvalue.position <- -1
    limit.sel.pvalue.position <- init.limit.sel.pvalue.position
    limit.selected.pvalue <- 100
    
    vec.pvalue.4.plot <- rep(NA, length(tmp.group.data))
    vec.x.pvalue.4.plot <- rep(NA, length(tmp.group.data))
    for (tmp.pos in 1:length(tmp.group.data) ) {
      tmp.vecGroup <- tmp.group.data[[tmp.pos]]$vecGroup
      tmp.pvalue <- in.function(..., in.vec.group = tmp.vecGroup)
      
      vec.pvalue.4.plot[tmp.pos] <- tmp.pvalue
      vec.x.pvalue.4.plot[tmp.pos] <- tmp.group.data[[tmp.pos]]$cutoff
      
      if (tmp.pvalue < selected.pvalue) {
        sel.pvalue.position <- tmp.pos
        selected.pvalue <- tmp.pvalue
      }
      
      length.of.cutoff <- floor( length(tmp.vecGroup) * ratio.limit.cutoff )
      tmp.data <- as.factor(na.omit(tmp.vecGroup))
      if (min(summary(tmp.data)) >= length.of.cutoff) {
        if (tmp.pvalue < limit.selected.pvalue) {
          limit.sel.pvalue.position <- tmp.pos
          limit.selected.pvalue <- tmp.pvalue
        }  		
      }
    }
    
    
    
    if (limit.sel.pvalue.position == init.limit.sel.pvalue.position) {
      if (in.flag.plot == T) {
        catE("LimitOfGroup is impossible")
        print(summFac(in.vec.cut.off))
      }
      list.of.limit.of.group <- NA
      pos.of.limit <- NA
    } else {
      list.of.limit.of.group <- list(groupText = tmp.group.data[[limit.sel.pvalue.position]]$groupText,
                                     vecGroup = data.frame(category = tmp.group.data[[limit.sel.pvalue.position]]$vecGroup),
                                     pValue = limit.selected.pvalue,
                                     cutoff = tmp.group.data[[limit.sel.pvalue.position]]$cutoff)
      pos.of.limit <- limit.sel.pvalue.position
    }
    pos.of.unlimit <- sel.pvalue.position
    
    
    raw.min.xlim <- min(in.vec.cut.off, na.rm = T)
    raw.max.xlim <- max(in.vec.cut.off, na.rm = T)
    raw.range.xlim <- raw.max.xlim - raw.min.xlim
    margin.xlim <- raw.range.xlim * 0.05
    vec.xlim <- c(raw.min.xlim - margin.xlim, raw.max.xlim + margin.xlim)
    
    if (in.flag.category == T) {
      tmp <- table(in.vec.cut.off)
      dat.for.bar <- data.frame(name = names(tmp), dat = tmp)
      if (in.flag.plot == T){
        plotBar(dat.for.bar, in.x.col = "name", in.y.col = 'dat')        
        xlim.for.plot.pvalue <- vec.xlim        
      }
    } else {
      if (in.flag.plot == T){      
        xlim.for.plot.pvalue <- plotHistogram(in.vec.cut.off, in.xlim = vec.xlim, in.max.4.fit.bin = 30)
      }
    }
    
    if (in.flag.plot == T) {
      plotPvalue4Cutoff(vec.pvalue.4.plot, vec.x.pvalue.4.plot, pos.of.limit, pos.of.unlimit, 
                        in.xlim = xlim.for.plot.pvalue)      
    }
    
    
    # if limitOfGroup is equal to unLimitOfGroup, unLimitOfGroup will be same as limitOfGroup
    return(list(LimitOfGroup = list.of.limit.of.group, 
                unLimitOfGroup = list(groupText = tmp.group.data[[sel.pvalue.position]]$groupText,
                                      vecGroup = data.frame(category = tmp.group.data[[sel.pvalue.position]]$vecGroup),
                                      pValue = selected.pvalue,
                                      cutoff = tmp.group.data[[sel.pvalue.position]]$cutoff),
                pValueDf = data.frame(cutoff = vec.x.pvalue.4.plot, pvalue = vec.pvalue.4.plot)))
  }
  
  return(out.function)
}

cutoffSel4Discrete <- closure4CutoffSel(mainFunForCutoffSel4Discrete)
cutoffSel4Continuous <- closure4CutoffSel(mainFunForCutoffSel4Continuouse)
cutoffSel4Survival <- closure4CutoffSel(mainFunForCutoffSel4Survival)

printCutoff4Discrete <- function(in.df, in.col.group, in.vec.cutoff, in.flag.plot = T) {
  
  if (!is.data.frame(in.df)) stop('if (!is.data.frame(in.df)) {')
  if ( !all(c(in.col.group, in.vec.cutoff) %in% colnames(in.df)) ) stop('if ( !all(c(in.col.group, in.vec.cutoff) %in% colnames(in.df)) ) {')
  
  tmp_col_group_vec <- sort(na.omit(unique(in.df[ , in.col.group])), decreasing = T)
  if (length(tmp_col_group_vec) == 2) {
    catE('Ratio: ' %+% tmp_col_group_vec[1] %+% " / " %+% tmp_col_group_vec[2])
  }
  result.data <- data.frame()
  # tmp.vec.cutoff <- in.vec.cutoff[1] # for debug
  for (tmp.vec.cutoff in in.vec.cutoff) {
    if (in.flag.plot == T) {
      catE()
      catHeader(tmp.vec.cutoff)
    }
    clean.data <- in.df[!is.nan(in.df[ , tmp.vec.cutoff]), ]
    clean.data <- clean.data[!is.na(clean.data[ , tmp.vec.cutoff]), ]
    
    tmp_cutoffsel_result_data <- cutoffSel4Discrete(clean.data[ , in.col.group],
                                                    in.vec.cut.off = clean.data[ , tmp.vec.cutoff],
                                                    in.flag.plot = in.flag.plot)
    title.of.unlimit.group = "unLimitOfGroup"    
    if (!all(is.na(tmp_cutoffsel_result_data$LimitOfGroup))) {
      if (!all(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == tmp_cutoffsel_result_data$LimitOfGroup$vecGroup)) {
        df.4.plot <- cbind(clean.data[ , in.col.group, drop = F],
                           data.frame(tmp.names = unlist(tmp_cutoffsel_result_data$LimitOfGroup$vecGroup))
        )
        colnames(df.4.plot)[which(colnames(df.4.plot) == "tmp.names")] <- tmp.vec.cutoff
        if (in.flag.plot == T) {
          plotMosaic2(df.4.plot, in.col.group, tmp.vec.cutoff, in.title = "LimitOfGroup")                   
        }
      } else {
        title.of.unlimit.group = "Group"
      }
    }
    df.4.plot <- cbind(clean.data[ , in.col.group, drop = F], data.frame(tmp.names = unlist(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup)))
    colnames(df.4.plot)[which(colnames(df.4.plot) == "tmp.names")] <- tmp.vec.cutoff
    if (in.flag.plot == T) {
      catE(in.col.group)
      catE(tmp.vec.cutoff)
      plotMosaic2(df.4.plot, in.col.group, tmp.vec.cutoff, in.title = title.of.unlimit.group)
      
    }
    tmp_result_table_data <- postProcess4PrintCutoff(tmp_cutoffsel_result_data, tmp.vec.cutoff)
    if (length(tmp_col_group_vec) != 2) {
      ratio_limit <- NaN
      ratio_unlimit <- NaN
    } else {
      if (is.nan(tmp_cutoffsel_result_data$LimitOfGroup$cutoff)) {
        ratio_limit <- NaN
      } else {
        tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$LimitOfGroup$vecGroup == 1, ]
        tmp_numerator <- sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[1]) / 
          sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[2])
        tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$LimitOfGroup$vecGroup == 0, ]
        tmp_denumerator <- sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[1]) / 
          sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[2])
        ratio_limit <- tmp_numerator / tmp_denumerator
      }
      
      if (is.nan(tmp_cutoffsel_result_data$unLimitOfGroup$cutoff)) {
        ratio_unlimit <- NaN
      } else {
        tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == 1, ]
        tmp_numerator <- sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[1]) / 
          sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[2])
        tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == 0, ]
        tmp_denumerator <- sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[1]) / 
          sum(tmp_clean_data[ , in.col.group] == tmp_col_group_vec[2])
        ratio_unlimit <- tmp_numerator / tmp_denumerator
      }            
    }
    tmp_result_table_data <- cbind(tmp_result_table_data[ , c('limit.cutoff', 'limit.pvalue') , drop = F],
                                   data.frame(ratio_limit = ratio_limit), 
                                   tmp_result_table_data[ , c('unlimit.cutoff', 'unlimit.pvalue') , drop = F],
                                   data.frame(ratio_unlimit = ratio_unlimit))
    result.data <- rbind(result.data, tmp_result_table_data)
  }
  
  print(result.data)
  
  return(result.data)
}


printCutoff4Continuous <- function(in.df, in.col.value, in.vec.cutoff) {
  
  
  if (!is.data.frame(in.df)) 
    stop("if (!is.data.frame(in.df)) {")
  if (!all(c(in.col.value, in.vec.cutoff) %in% colnames(in.df))) 
    stop("if ( !all(c(in.col.value, in.vec.cutoff) %in% colnames(in.df)) ) {")
  
  result.data <- data.frame()
  for (tmp.vec.cutoff in in.vec.cutoff) {
    catE()
    catHeader(tmp.vec.cutoff)
    
    clean.data <- in.df[!is.nan(in.df[, tmp.vec.cutoff]), ]
    clean.data <- clean.data[!is.na(clean.data[, tmp.vec.cutoff]), ]
    
    tmp_cutoffsel_result_data <- cutoffSel4Continuous(clean.data[, in.col.value], in.vec.cut.off = clean.data[, tmp.vec.cutoff])
    tmp_result_table_data <- postProcess4PrintCutoff(tmp_cutoffsel_result_data, tmp.vec.cutoff)
    
    if (is.nan(tmp_cutoffsel_result_data$LimitOfGroup$cutoff)) {
      ratio_limit <- NaN
    } else {
      tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$LimitOfGroup$vecGroup == 1, ]
      tmp_numerator <- mean(tmp_clean_data[ , in.col.value])
      tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$LimitOfGroup$vecGroup == 0, ]
      tmp_denumerator <- mean(tmp_clean_data[ , in.col.value])
      ratio_limit <- tmp_numerator / tmp_denumerator
    }
    
    if (is.nan(tmp_cutoffsel_result_data$unLimitOfGroup$cutoff)) {
      ratio_unlimit <- NaN
    } else {
      tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == 1, ]
      tmp_numerator <- mean(tmp_clean_data[ , in.col.value])
      tmp_clean_data <- clean.data[tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == 0, ]
      tmp_denumerator <- mean(tmp_clean_data[ , in.col.value])
      ratio_unlimit <- tmp_numerator / tmp_denumerator
    }       
    tmp_result_table_data <- cbind(tmp_result_table_data[ , c('limit.cutoff', 'limit.pvalue') , drop = F],
                                   data.frame(ratio_limit = ratio_limit), 
                                   tmp_result_table_data[ , c('unlimit.cutoff', 'unlimit.pvalue') , drop = F],
                                   data.frame(ratio_unlimit = ratio_unlimit))    
    result.data <- rbind(result.data, tmp_result_table_data)
    
    title.of.unlimit.group <- "unLimitOfGroup"
    if (!all(is.na(tmp_cutoffsel_result_data$LimitOfGroup))) {
      if (!all(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == tmp_cutoffsel_result_data$LimitOfGroup$vecGroup)) {
        plotCompareHistogram(cbind(clean.data, data.frame(group = unlist(tmp_cutoffsel_result_data$LimitOfGroup$vecGroup))), 
                             in.col.value, "group", in.title = "LimitOfGroup")
      } else {
        title.of.unlimit.group <- "Group"
      }
    }
    plotCompareHistogram(cbind(clean.data, data.frame(group = unlist(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup))), 
                         in.col.value, "group", in.title = title.of.unlimit.group)
  }
  print(result.data)
  
  return(result.data)
}

printCutoff4Survival <- function(in.data, in.day.column, in.occur.column, in.vec.cutoff, in_max_time = NA) {
  
  
  if (!is.data.frame(in.data)) {
    stop("!is.data.frame(in.data)")
  }
  if ( !all(c(in.day.column, in.occur.column, in.vec.cutoff) %in% colnames(in.data)) ) {
    stop("!all(colnames(in.data) %in% c(in.day.column, in.occur.column, in.vec.cutoff)")
  }
  
  catE("If Group=0 is more survival than Group=1, ratio >= 1")
  
  result.data <- data.frame()
  # tmp.vec.cutoff <- in.vec.cutoff #for debug
  for (tmp.vec.cutoff in in.vec.cutoff) {
    catE()
    catHeader(tmp.vec.cutoff)
    clean.data <- in.data[!is.nan(in.data[ , tmp.vec.cutoff]), ]
    clean.data <- clean.data[!is.na(clean.data[ , tmp.vec.cutoff]), ]
    tmp_cutoffsel_result_data <- cutoffSel4Survival(in.vec.time = clean.data[ , in.day.column],
                                                    in.vec.occured = clean.data[ , in.occur.column],
                                                    in.vec.cut.off = clean.data[ , tmp.vec.cutoff])
    
    Survival.Event <- Surv(clean.data[ , in.day.column], clean.data[ , in.occur.column] == 1)
    
    tmp_result_table_data <- postProcess4PrintCutoff(tmp_cutoffsel_result_data, tmp.vec.cutoff)
    if (is.nan(tmp_cutoffsel_result_data$LimitOfGroup$cutoff)) {
      ratio_limit <- NaN
    } else {
      Group <- unlist(tmp_cutoffsel_result_data$LimitOfGroup$vecGroup)
      tmp_survdiff <- survdiff(Survival.Event ~ Group)
      if (all(names(tmp_survdiff$n) == c("Group=0", "Group=1"))){
        tmp <- tmp_survdiff$obs / tmp_survdiff$exp
        ratio_limit <- tmp[2] / tmp[1]
      } else {
        ratio_limit <- NaN
      }
    }
    if (is.nan(tmp_cutoffsel_result_data$unLimitOfGroup$cutoff)) {
      ratio_unlimit <- NaN
    } else {
      Group <- unlist(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup)
      tmp_survdiff <- survdiff(Survival.Event ~ Group)
      if (all(names(tmp_survdiff$n) == c("Group=0", "Group=1"))){
        tmp <- tmp_survdiff$obs / tmp_survdiff$exp
        ratio_unlimit <- tmp[2] / tmp[1]
      } else {
        ratio_unlimit <- NaN
      }
    }
    
    tmp_result_table_data <- cbind(tmp_result_table_data[ , c('limit.cutoff', 'limit.pvalue') , drop = F],
                                   data.frame(ratio_limit = ratio_limit),
                                   tmp_result_table_data[ , c('unlimit.cutoff', 'unlimit.pvalue') , drop = F],
                                   data.frame(ratio_unlimit = ratio_unlimit))
    result.data <- rbind( result.data, tmp_result_table_data)
    
    if (all(is.na(result.data[ ,c("limit.cutoff", "unlimit.cutoff")]))) next
    
    tmp_fun_plot_survival <- function(in_group, in_survival_event, in_title, in_max_time = NA) {
      vec_legend <- sort(unique(in_group), decreasing = TRUE)
      plotSurvival(survfit(in_survival_event ~ in_group),
                   in.gray.picture = TRUE,
                   in.title = in_title,
                   in.num.group = 2,
                   in.legend.label = vec_legend,
                   in.legend.value = vec_legend, 
                   in_max_time = in_max_time
      )
    }
    
    title.of.unlimit.group = "unLimitOfGroup"
    if (!all(is.na(tmp_cutoffsel_result_data$LimitOfGroup))) {
      if (!all(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup == tmp_cutoffsel_result_data$LimitOfGroup$vecGroup)) {
        Group <- unlist(tmp_cutoffsel_result_data$LimitOfGroup$vecGroup)
        tmp_fun_plot_survival(Group, Survival.Event, in_title = "LimitOfGroup", in_max_time)
      } else {
        title.of.unlimit.group = "Group"
      }
    }
    Group <- unlist(tmp_cutoffsel_result_data$unLimitOfGroup$vecGroup)
    tmp_fun_plot_survival(Group, Survival.Event, in_title = title.of.unlimit.group, in_max_time)
  }
  print(result.data)
  catE()
  
  return(result.data)
}

catHeader <- function(..., in.rank = 1) {
  upper.and.lower.line <- rep("=", 70)
  
  if (in.rank == 1) {
    catE(upper.and.lower.line)
  } else {
    catE()
  }
  catE(paste0(rep(" ", in.rank - 1), ..., collapse = ""))
  catE(upper.and.lower.line)
}


groupPossible2Class <- function(x, categoryData = F) {
  
  # Compute the possible 2 groups
  #
  # Args:
  #   x: Continuous or categorial feature of nx1 data.frame
  #   categoryData: if FALSE, x is continuous, else x is category data
  #
  # Return:
  #   list[]['groupText'] : group text to identity
  #   list[]['vecGroup'] : group vector
  #                       (in continuous, the value over cutoff is 1)
  #                       (in category, the value of left is 1)
  #   list[]['cutoff'] : cutoff
  #                       (in continuous, cutoff value)
  #                       (in category, vectof which's group is 1)  
  
  
  find.cutoff.with.small.sig.num <- function(in.x1, in.x2){
    # find cutoff value between in.x1 and in.x2 with small significant number (for readability)
    # ex) (2/3 + 3)/2 -> 1.83333333333333333333333 
    #     but find.cutoff.with.small.sig.num(2/3, 3) -> 2
    
    if (identical(in.x1, in.x2)) stop("if (identical(in.x1, in.x2))")
    
    find.round.num <- function(in.sub.x){ ceiling(-1 * log10(abs(in.sub.x)))}
    candidate.round.num <- max(0, min(find.round.num(in.x1), find.round.num(in.x2)))
    center.cut.off <- (in.x1 + in.x2) / 2
    min.in.x <- min(in.x1, in.x2)
    max.in.x <- max(in.x1, in.x2)
    while (candidate.round.num < 100) {
      test.cut.off <- round(center.cut.off, candidate.round.num)
      if ( !identical(test.cut.off, in.x1) 
           && !identical(test.cut.off, in.x2)
           && (test.cut.off > min.in.x)
           && (test.cut.off < max.in.x)
      ){
        return(test.cut.off)
      }
      candidate.round.num <- candidate.round.num + 1
    }
    stop("    while (candidate.round.num < 100) {")
  }
  
  fisherTestData = list()
  if (categoryData == F) {
    xUnique <- as.vector(t(unique(x)))
    xUnique <- sort(xUnique)
    for (cutOffPos in 1:(length(xUnique)-1) ) {
      cutOff <- find.cutoff.with.small.sig.num(xUnique[cutOffPos], xUnique[cutOffPos+1])
      xCategory <- ifelse(x > cutOff, 1, 0)
      fisherTestData[[cutOffPos]] = list(groupText = paste(cutOff, "_over", sep = ""), vecGroup = xCategory, cutoff = cutOff)
    }  	
  }
  else {
    #If x is category, algorithm for avoid the redundency is need.
    xUnique <- unique(x)
    divXUniqueBy2 <- floor(length(xUnique) / 2)
    fisherTestDataNum = 1
    for (cutOffNum in 1:divXUniqueBy2 ) {
      # If category length is even & half-cases
      if ( (length(xUnique) %% 2 == 0) && (cutOffNum == divXUniqueBy2) ) {
        set1Sel = combn(length(xUnique), divXUniqueBy2)
        saveSel = matrix(ncol = 0, nrow = divXUniqueBy2)
        while(dim(set1Sel)[2] > 0) {
          tmp = set1Sel[ , 1, drop = F]
          saveSel = cbind(saveSel, tmp)
          rmTmp = setdiff(1:divXUniqueBy2, tmp)
          delCol = apply(set1Sel, 2, function(x) {all(x == rmTmp)})
          set1Sel = set1Sel[ , -delCol, drop = F]
          if (dim(set1Sel)[2] != 0) {
            set1Sel = set1Sel[ , -1, drop = F]
          }
        }
      } else {
        saveSel = combn(length(xUnique), cutOffNum)
      }
      
      for (set1SelCount in 1:dim(saveSel)[2] ) {
        set1 = xUnique[saveSel[ , set1SelCount]]
        set2 = setdiff(xUnique, set1)
        xCategory = ifelse(x %in% set1, 1, 0)
        fisherTestData[[fisherTestDataNum]] <- 
          list(groupText = paste( paste(set1, collapse = ", "), paste(set2, collapse = ", ") , sep = ' vs '),
               vecGroup = xCategory, 
               cutoff = set1)
        fisherTestDataNum = fisherTestDataNum + 1
      }
    }
  }
  return(fisherTestData)
}



plotHistogram <- function(in.vec, 
                          in.xlab = NA, 
                          in.binwidth = NA, 
                          in.bin = NA, 
                          in.xlim = NA, 
                          in.max.4.fit.bin = 20) {
  
  # make histogram
  #
  # arg
  #   in.vec
  #   in.xlab
  #   in.binwidth: binwidth
  #   in.bin
  #   in.xlim: xlimit ex) c(10,100)
  #   in.max.4.fit.bin: max number for bin fitting(all x is expressed and histogram have margin between histogram bar)
  #
  # return
  #   xlim value
  
  
  
  if (!is.vector(in.vec)) {
    stop("if (!is.vec(in.vec)) {")
  }
  if (!is.na(in.xlab) && !is.character(in.xlab)) {
    stop('if (!is.null(in.xlab) && !is.character(in.xlab)) {')
  }    
  if (!is.na(in.binwidth) && (!is.numeric(in.binwidth) || !is.vector(in.binwidth) || length(in.binwidth) != 1)) {
    stop('if (!is.null(in.binwidth) && (!is.numeric(in.binwidth) || !is.vector(in.binwidth))) {')
  }
  in.vec <- as.vector(na.omit(in.vec))
  
  const.min.bin <- 10
  if (is.na(in.binwidth)) {
    if (any(is.na(in.xlim))) {
      if (is.na(in.bin)) {
        # in.binwidth <- (max(in.vec) - min(in.vec)) / 30      
        in.binwidth <- 2 * IQR(in.vec) / length(in.vec)^(1/3)
        range.in.vec <- diff(range(in.vec, na.rm = T))
        in.alt.binwidth <- range.in.vec / (length(in.vec)^(1/2))
        if ((range.in.vec / in.binwidth) < const.min.bin) {
          in.binwidth <- min(in.binwidth, in.alt.binwidth)
        }
        if (in.binwidth == 0){
          in.binwidth <- diff(range(in.vec, na.rm = T)) / (length(in.vec)^(1/2)) 
        } 
        in.xlim <- c(min(in.vec) - in.binwidth,  max(in.vec) + in.binwidth)        
      } else {
        in.binwidth <- diff(range(in.vec, na.rm = T)) / in.bin
        in.xlim <- c(min(in.vec) - in.binwidth,  max(in.vec) + in.binwidth)        
      }
    } else {
      if (is.na(in.bin)) {
        range.in.vec <- max(in.xlim) - min(in.xlim)
        in.binwidth <- range.in.vec / (length(in.vec)^(1/3))
        in.alt.binwidth <- range.in.vec / (length(in.vec)^(1/2))
        if ((range.in.vec / in.binwidth) < const.min.bin) {
          in.binwidth <- min(in.binwidth, in.alt.binwidth)
        }        
      } else {
        in.binwidth <- diff(range(in.vec, na.rm = T)) / in.bin
      }
      in.xlim <- c(min(in.xlim) - in.binwidth,  max(in.xlim) + in.binwidth)
    }
    hist.origin <- min(in.vec)
  }
  
  if (length(table(in.vec)) <= in.max.4.fit.bin) {
    tmp.unique.in.vec <- sort(unique(in.vec))
    diff.unique.in.vec <- tmp.unique.in.vec[tmp.unique.in.vec != 0]
    
    if (length(diff.unique.in.vec) <= 1) {
      vec.for.check.multiple.of.diff <- diff.unique.in.vec
    } else {
      vec.for.check.multiple.of.diff <- min(diff(diff.unique.in.vec)) # init      
    }
    
    
    while (vec.for.check.multiple.of.diff * in.max.4.fit.bin >=  diff(range(in.vec))) {
      if (all((diff.unique.in.vec/vec.for.check.multiple.of.diff) %% 1 == 0)) {
        in.binwidth <- min(vec.for.check.multiple.of.diff) / 2
        hist.origin <- min(in.vec) - in.binwidth / 2
        in.xlim <- c(min(in.vec) - in.binwidth,  max(in.vec) + in.binwidth)     
        
        break
      } else {
        diff.unique.in.vec <- sort(uniqueApprox(diff(diff.unique.in.vec)))
        vec.for.check.multiple.of.diff <- min(diff.unique.in.vec)
      } 
    }
  }
  
  if (is.na(in.xlab)) {
    in.xlab = "data"
  }
  # alpha means thd in.flag.density of color
  df.ggplot <- data.frame(gg.x = in.vec)
  
  objectPlot <- ggplot(data =  df.ggplot, aes(x = gg.x)) + 
    scale_fill_grey(start = const_scaleFillGreyStart, end = const_scaleFillGreyStop) +
    xlab(in.xlab) # + ggtitle(title.add)
  
  objectPlot <- objectPlot + 
    geom_histogram(colour = "white", binwidth =  in.binwidth, 
                   boundary = hist.origin)
  if (!any(is.na(in.xlim))) {
    objectPlot <- objectPlot + 
      scale_x_continuous(expand = c(0, 0)) + 
      coord_cartesian(xlim = in.xlim)
  }  
  
  print(objectPlot)
  
  return(in.xlim)
}


plotPvalue4Cutoff <- function(in.pvalue, in.x = NA, in.pos.limit = NA, in.pos.unlimit = NA, in.xlim = NA) {
  
  
  const_ymax.in.plotPvalue4Cutoff <- 0.2
  
  
  if (any(is.na(in.x))) {
    vec.x <- c(1:length(in.pvalue))  
  } else {
    if (length(in.pvalue) != length(in.x)) stop('if (length(in.pvalue) != length(in.x))')
    vec.x <- in.x
  }
  
  point.of.pos <- rep(F, length(in.pvalue))
  text.of.pos <- rep("", length(in.pvalue))
  
  if (!is.na(in.pos.limit)) {
    point.of.pos[in.pos.limit] <- T
    text.of.pos[in.pos.limit] <- 'limit'
  }
  if (!is.na(in.pos.unlimit)) {
    point.of.pos[in.pos.unlimit] <- T
    text.of.pos[in.pos.unlimit] <- 'unlimit'
  }
  if ( equalNa(in.pos.limit, in.pos.unlimit) ) {
    point.of.pos[in.pos.limit] <- T
    text.of.pos[in.pos.limit] <- 'best'
  }
  
  
  p.value.limited <- sapply(in.pvalue, function(x){min(x, (const_ymax.in.plotPvalue4Cutoff))})
  offset.pos.y.text <- (const_ymax.in.plotPvalue4Cutoff - 0) / 70
  vec.text.y <- p.value.limited - offset.pos.y.text
  vec.text.y <- ifelse(vec.text.y >= (offset.pos.y.text * 2), vec.text.y, vec.text.y + offset.pos.y.text * 2)
  
  df4ggplot <- data.frame(x = vec.x, 
                          y = p.value.limited, 
                          point = point.of.pos, 
                          text = text.of.pos, 
                          text.y = vec.text.y)
  
  
  p <- ggplot(df4ggplot[ , ], aes(x = x, y = y))
  if (length(vec.x) >= 2) {
    p <- p + geom_line()  
  }
  p <- p + geom_point(data = df4ggplot[df4ggplot$point == T,], 
                      aes(x=x, y=y), shape = 16)
  p <- p + geom_text(data = df4ggplot, 
                     mapping = aes(x = x, y = text.y, label=text), size=3) 
  p <- p + ggtitle("p value position for each cutoff") + xlab("cutoff") + ylab("p value") + 
    geom_hline(yintercept = 0.05, linetype = 2) + 
    scale_y_continuous(limits=c(0, const_ymax.in.plotPvalue4Cutoff), expand = c(0.01,0)) 
  if (!all(is.na(in.xlim))) {
    p <- p + scale_x_continuous(limits = in.xlim, expand = c(0, 0)) 
  }
  print(p)
}

"appendList<-" <- function(x, value){
  if (missing(x)) x  <- list()
  return(append(x, list(value)))
}



getSimilarwordUsingWordNet3_1 <- function(in_word) {
  
  remove_str <- "S:"
  
  tmp_url1 <- "http://wordnetweb.princeton.edu/perl/webwn?s="
  tmp_url2 <- "&sub=Search+WordNet&o2=&o0=&o8=1&o1=&o7=&o5=&o9=&o6=&o3=&o4=&h=00000"
  url_to_get <- paste(tmp_url1, in_word, tmp_url2, sep = "")
  test <- read_html(url_to_get)
  tmp <- test %>% html_nodes("a")
  tmp_attr <- tmp %>% html_attr("href")
  tmp_synm <- tmp %>% html_text()
  
  tmp_sym_before_remove <- tmp_synm[grep("webwn", tmp_attr)]
  
  tmp <- tmp_sym_before_remove[!(tmp_sym_before_remove %in% remove_str)]
  tmp_sym <- unique(tmp)
  
  return(tmp_sym)
}


moveFiles <- function(in_from_dir, in_to_dir) {
  # Move all files to destination directory
  #   - Make dir if destination directory doesn't not exist.
  
  dir.create(in_to_dir, showWarnings = FALSE, recursive = TRUE)
  
  vec_file_list <- listFilesOnly(in_from_dir)
  
  if (length(vec_file_list) >= 1) {
    for (i in vec_file_list) {
      file.rename(fitFilePath(in_from_dir, i), fitFilePath(in_to_dir, i))  
    }    
  }
}

printSummaryTable <- function(in.frm.data, in.group.col, 
                              in.factor.col = c(), in.num.col = c(), 
                              in.id.col = NA, in_flag_fisher_run = TRUE,
                              in_flag_col_percent = F) {
  # print the summary table in data.frame
  # 
  # remark 
  #   use selFactorOrNumCol to discriminate in.factor.col and in.num.col
  #     if you have many features
  # 
  # arg
  #   in.frm.data: data.frame to print summary
  #   in.group.col: group column name
  #   in.factor.col: factorial column name to summary
  #   in.num.col: numerical column name to summary
  #   in.id.col: id column for listing
  #
  # return
  #   none
  #
  
  
  
  const_num_fac_group_to_evade <- 7
  strNeq <- function(number) {
    return(paste("( N = ", as.character(number) , " )", sep = ""))
  }
  
  meanSD <- function(inData) {
    inData = as.numeric(inData)
    return(paste(signif(mean(inData), 3), '(', signif(sd(inData), 3), ')'))
  }
  
  meanRange <- function(in_data) {
    if (length(in_data) >= 1) {
      in_data <- as.numeric(in_data)  
      return_value <- paste(signif(mean(in_data), 3), '(', signif(min(in_data), 3), '-', signif(max(in_data), 3), ')')
    } else {
      return_value <- "NA"
    }
    return(return_value)
  }
  
  strPercent <- function(inData) {
    inData = as.numeric(inData)
    return(paste('(', round(inData*100, digits = 1), '%)'))
  } 	
  
  in.frm.data[ , in.group.col] <- factor(in.frm.data[ , in.group.col])
  
  in.frm.dataWithoutNA <- in.frm.data[!is.na(in.frm.data[ , in.group.col]), ]
  if (length(unique(in.frm.dataWithoutNA[ , in.group.col])) <= 1) {
    flag.pvalue.cal <- FALSE
  } else {
    flag.pvalue.cal <- TRUE
  }
  
  colGroup <- sort(unique(in.frm.data[ , in.group.col]), decreasing = FALSE, na.last = T)
  colGroup <- colGroup[!is.na(colGroup)]
  in.frm.data <- in.frm.data[!is.na(in.frm.data[ , in.group.col]), ]
  
  #header	
  tmpCol <- c("", strNeq(dim(in.frm.data)[1]))
  for (indColGroup in colGroup) {
    tmpCol <- c(tmpCol, strNeq(dim(in.frm.data[in.frm.data[ , in.group.col] == indColGroup, ])[1]))
  }
  tmpCol <- c(tmpCol, "", "")
  
  colnames.for.data.frame.for.output <- c("", "Total", levels(colGroup), "p-val1*", "p-val2**")
  data.frame.for.output <- data.frame(matrix(tmpCol, nrow = 1, ncol = length(colnames.for.data.frame.for.output))
                                      , stringsAsFactors = F)
  colnames(data.frame.for.output) <- colnames.for.data.frame.for.output
  
  # processing of numerical data
  for (tmp in in.num.col) {
    tmpin.frm.data <- in.frm.data[!is.na(in.frm.data[ , tmp]), c(tmp, in.group.col)]
    
    tmp.col <- c(tmp, strNeq(dim(tmpin.frm.data)[1]))
    
    for (indColGroup in colGroup) {
      tmpin.frm.data2 <- tmpin.frm.data[tmpin.frm.data[ , in.group.col] == indColGroup, ]
      tmp.col <- c(tmp.col, strNeq(dim(tmpin.frm.data2)[1]))
    }
    if ((flag.pvalue.cal == T) & (length(na.omit(unique(tmpin.frm.data[ , in.group.col]))) >= 2)) {
      # #temporary data for 20160805
      # tmp_pvalue <- t.test(makeFormula(tmp , "goldenCriteria"), data = tmpin.frm.data,  var.equal = F)$p.value
      # pvalueSave <-  makePvalueStr(tmp_pvalue, is.simple = T, in.last.num = const_pvalueSignificant)
      pvalueSave <-
        makePvalueStr(calPvalueOfAnovaInDf(tmpin.frm.data, in.group.col, tmp),
                      is.simple = T, in.last.num = const_pvalueSignificant)
      
      pvalueSave1 <- 
        makePvalueStr(kruskal.test(tmpin.frm.data[ , tmp] ~ tmpin.frm.data[ , in.group.col])$p.value, 
                      is.simple = T, in.last.num = const_pvalueSignificant) 
    } else {
      pvalueSave <- "NA"
      pvalueSave1 <- "NA"
    }
    
    tmp.col <- as.character(c(tmp.col, pvalueSave, pvalueSave1))
    
    data.frame.for.output <- rbind(data.frame.for.output, tmp.col)
    
    tmp.col <- "" #first column
    tmp.col <- c(tmp.col, meanRange(tmpin.frm.data[ , tmp]))
    
    for (indColGroup in colGroup) {
      tmpin.frm.data2 <- tmpin.frm.data[tmpin.frm.data[ , in.group.col] == indColGroup, ]
      tmp.col <- c(tmp.col, meanRange(tmpin.frm.data2[ , tmp]))
    }
    tmp.col <- c(tmp.col, "", "") #for last p-value column
    data.frame.for.output <- rbind(data.frame.for.output, tmp.col)
  }
  
  for (tmp in in.factor.col) {
    tmpin.frm.data <- in.frm.data[!is.na(in.frm.data[ , tmp]), c(tmp, in.group.col)]
    totalColLength <- dim(tmpin.frm.data)[1]
    
    tmp.col <- c(tmp, strNeq(totalColLength))		
    
    colCountVector = vector()
    for (indColGroup in colGroup) {
      tmpin.frm.data2 = tmpin.frm.data[tmpin.frm.data[ , in.group.col] == indColGroup, ]
      colCountVector[indColGroup] = dim(tmpin.frm.data2)[1]
      tmp.col <- c(tmp.col, strNeq(colCountVector[indColGroup]))
    }
    
    factorVector <- sort(unique(tmpin.frm.data[ , tmp]), decreasing = FALSE, na.last = T)
    
    if ( (length(factorVector) <= 1) | (flag.pvalue.cal == F) ) {
      pvalueSave.chisq <- "NA"
      pvalueSave.fisher <- "NA"
    } else if (length(factorVector) >= const_num_fac_group_to_evade) {
      pvalueSave.chisq <- "Too many to cal"
      pvalueSave.fisher <- "Too many to cal"
    }
    else {
      pvalueSave.chisq <- suppressWarnings(chisq.test(table(in.frm.dataWithoutNA[ , tmp], in.frm.dataWithoutNA[ , in.group.col]))$p.value)
      
      if (in_flag_fisher_run == TRUE) {
        pvalueSave.fisher <- fisher.test(table(in.frm.dataWithoutNA[ , tmp], in.frm.dataWithoutNA[ , in.group.col]))$p.value  
      } else {
        pvalueSave.fisher <- -1
      }
      
      pvalueSave.chisq <- makePvalueStr(pvalueSave.chisq, is.simple = T, 
                                        in.last.num = const_pvalueSignificant)
      pvalueSave.fisher <- makePvalueStr(pvalueSave.fisher, is.simple = T, 
                                         in.last.num = const_pvalueSignificant)
    }
    
    tmp.col <- c(tmp.col, pvalueSave.chisq, pvalueSave.fisher)
    data.frame.for.output <- rbind(data.frame.for.output, tmp.col)
    
    if (length(factorVector) < const_num_fac_group_to_evade) {
      for (indFactorVector in factorVector) {
        tmp.col <- paste0("&nbsp;&nbsp;", indFactorVector) #first column
        totalLength <- dim(tmpin.frm.data[tmpin.frm.data[ , tmp] == indFactorVector, ])[1]
        tmp.col <- c(tmp.col, paste(totalLength, strPercent(totalLength/totalColLength)))
        for (indColGroup in colGroup) {
          tmpin.frm.data4factor = tmpin.frm.data[tmpin.frm.data[ , in.group.col] == indColGroup, ]
          total_column_length <- nrow(tmpin.frm.data4factor)
          tmpLength = dim(tmpin.frm.data4factor[tmpin.frm.data4factor[ , tmp] == indFactorVector, ])[1]
          if (in_flag_col_percent) {
            tmp.col <- c(tmp.col, paste(tmpLength, strPercent(tmpLength / total_column_length)))            
          } else {
            tmp.col <- c(tmp.col, paste(tmpLength, strPercent(tmpLength/totalLength)))  
          }
        }
        data.frame.for.output <- rbind(data.frame.for.output, c(tmp.col, "", ""))			
      }
    }
  }
  if (in_flag_fisher_run == FALSE) {
    data.frame.for.output <- data.frame.for.output[ , -which(colnames(data.frame.for.output) == 'p-val2**')]
  }
  cat("\n<p><h2> Group Column: ", in.group.col, "</h2></p>\n")
  cat(kable(data.frame.for.output, format = "pandoc"), sep = "\n")
  cat("\n<br />")
  cat("*p-val1 is t-test or anova with equal variance or Chi-square test with correction")
  cat("\n<p></p>")
  cat("**p-val2 is Wilcoxon signed-rank test or Fisher's exact test")
  cat("\n<p>&nbsp;</p>\n")
  
  
  if (!is.na(in.id.col)) {
    df.for.id <- data.frame();
    for (i in colGroup) {
      df.for.id <- rbind(df.for.id, 
                         data.frame(group = i,
                                    id = paste1f(in.frm.data[in.frm.data[ , in.group.col] == i, 
                                                             in.id.col])))
    }
    
    cat(kable(df.for.id, format = "pandoc"), sep = "\n")
    cat("\n<p>&nbsp;</p>")    
  }
  cat("\n<p>&nbsp;</p>")  
}


removeFilesInDir <- function(in_dir) {
  vec_file_list <- listFilesOnly(in_dir)
  
  if (length(vec_file_list) >= 1) {
    for (i in vec_file_list) {
      file.remove(fitFilePath(in_dir, i))
    }    
  }
}

makePvalueStr <- function(in.p.value, is.simple = F, in.last.num = 3, is.flag = F) {
  return_vec <- 
    do.call(c, lapply(in.p.value, 
                      function(x){makeSinglePvalueStr(x, is.simple, 
                                                      in.last.num, is.flag)}))
  return(return_vec)
}



calDegByTTest <- function(in.exp.matrix, in.numerator.group, in.denominator.group) {
  # t-test by
  #
  # arg
  #   - in.exp.matrix: expression matrix with probe rows and case columns
  
  
  
  if (length(intersect(in.numerator.group, in.denominator.group)) != 0) {
    stop("(length(intersect(in.numerator.group, in.denominator.group)) != 0)")
  }
  if (!all(colnames(in.exp.matrix) %in% c(in.numerator.group, in.denominator.group))) {
    stop("(all(colnames(in.exp.matrix) %in% union(in.numerator.group, in.denominator.group)))")
  }
  
  fold.change <- apply(in.exp.matrix, 1, function(x){mean(x[in.numerator.group]) - mean(x[in.denominator.group])})
  p.value <- apply(in.exp.matrix, 1, function(x){ 
    if (length(unique(na.omit(x[in.numerator.group]))) == 1 && length(unique(na.omit(x[in.denominator.group]))) == 1) {
      1;
    } else {
      t.test(x[in.numerator.group], x[in.denominator.group])$p.value;
    }})
  
  p.adjust.value <- p.adjust(p.value, method="fdr")
  gene.compare.data <- data.frame(logFC = fold.change, P.Value = p.value, adj.P.Val = p.adjust.value)
  gene.compare.data <- gene.compare.data[order( gene.compare.data[, "P.Value"]), ]
  
  return(gene.compare.data)
}


plotHeatmap.2 <- function(in.data, 
                          in.group.vector, 
                          in.main = "", 
                          in.row.sorting = T, 
                          in.clustering.method = "centroid",
                          in_cex_ratio = 1){
  # plot Heatmap
  #
  # arg
  #   in.data: column to print summary
  # 	in.group.vector: column group data (ex: c("data1", "data1" , "data2", "data2") )
  # 	in.main: string of main title
  #   in.row.sorting: if group is two, reordering the row by mean
  #
  # return
  #   - accuracy of hclustering
  
  element.of.in.group.vector <- sort(unique(in.group.vector))
  lenght.of.in.group.vector <- length(element.of.in.group.vector)
  pos.of.in.group.vector <- rep(NA, length(in.group.vector))
  for (tmp in 1:lenght.of.in.group.vector) {
    pos.of.in.group.vector[in.group.vector == element.of.in.group.vector[tmp]] <- tmp  
  }
  
  if ( lenght.of.in.group.vector < 2 || lenght.of.in.group.vector > 3) {
    stop("if ( lenght.of.in.group.vector < 2 || lenght.of.in.group.vector > 3) {")
  }
  if ( dim(in.data)[2] != length(in.group.vector) ) {
    stop("The column length of in.data is not same as length of in.group.vector")
  }
  
  exp.data <- in.data
  if (in.row.sorting  == TRUE && lenght.of.in.group.vector == 2) {
    tmp.normalizad.by.zscore <- t(apply(exp.data, 1, function(in.x){ (in.x - mean(in.x))/sd(in.x)}))
    vector.row.data <- order(rowMeans(tmp.normalizad.by.zscore[ ,pos.of.in.group.vector == 1]) -
                               rowMeans(tmp.normalizad.by.zscore[ ,pos.of.in.group.vector == 2])
    )
    exp.data <- exp.data[vector.row.data, ]
  }
  
  sideC = c("#4682b4", "#63743E", "#C18698")[pos.of.in.group.vector]
  #   sidec.name <- c("SteelBlue", "Chalet Green", "Oriental Pink")
  sidec.name <- c("Blue", "Green", "Pink")
  
  
  #   col = c(colorRampPalette(c("green", "black"), space = "rgb")(50),
  #           colorRampPalette(c("black", "red"), space = "rgb")(50) )
  xlab.string <- ""
  for (tmp in 1:lenght.of.in.group.vector) {
    xlab.string <- paste(xlab.string, element.of.in.group.vector[tmp], "-", sidec.name[tmp], " ")
  }
  
  saved.cex.main <- par('cex.main')
  saved.cex.lab <- par("cex.lab")
  par(cex.main = 0.7 * in_cex_ratio)
  
  tmp.accuracy.hclust <- 0
  for (tmp.method in in.clustering.method) {
    lambda.hclust <- function(x) hclust(x, method = tmp.method)
    heatmap.2(as.matrix(exp.data), col = rev(redgreen(100)), scale = "row", ColSideColors = sideC,
              key = TRUE, symkey = FALSE, 
              key.xlab = "",
              density.info = "none", trace = "none", 
              main = paste0(in.main, '\n(', xlab.string, ')\n', "Method:", tmp.method),
              dendrogram = "column",
              Rowv = F,
              cexRow = 0.8 * in_cex_ratio,
              cexCol = 0.8 * in_cex_ratio,
              hclustfun = lambda.hclust
    )    
    hclust.result <- cutree(lambda.hclust(dist(t(in.data))), k = lenght.of.in.group.vector )
    if ( any(names(hclust.result) != colnames(in.data)) ) {
      print(hclust.result)
      stop("hclust.result problem")
    }
    tmp.accuracy.hclust.sub <- 0
    
    list.perm <- permn(unique(pos.of.in.group.vector))
    for (tmp.list.perm in list.perm) {
      check.vector <- rep(NA, length(in.group.vector))
      for (position.of.tmp.list.perm in seq(1, length(tmp.list.perm)) ) {
        check.vector[ pos.of.in.group.vector == position.of.tmp.list.perm ] <- tmp.list.perm[position.of.tmp.list.perm]
      }
      if (any(is.na(check.vector))) {
        stop("check.vector problem")
      }
      tmp.accuracy.hclust.sub <- max(tmp.accuracy.hclust.sub, sum(check.vector == hclust.result) / length(pos.of.in.group.vector))
    }    
    tmp.accuracy.hclust <- max(tmp.accuracy.hclust, tmp.accuracy.hclust.sub)
  }
  
  par(cex.lab = saved.cex.lab)
  par(cex.main = saved.cex.main)  
  
  return(tmp.accuracy.hclust)
}

equalNa <- function(in.x, in.y){
  out.vec <- (in.x == in.y)
  out.vec[is.na(out.vec)] <- FALSE
  
  return(out.vec)
}


postProcess4PrintCutoff <- function(in.list.result.cutoff, in.row.name = 'temp', in.flag.make.pvalue.str = T){
  
  if (!all(names(in.list.result.cutoff) %in% c("LimitOfGroup", "unLimitOfGroup", "pValueDf"))) 
    stop('if (!all(names(in.list.result.cutoff) %in% c("LimitOfGroup", "unLimitOfGroup")))')
  
  if ( any(is.na(in.list.result.cutoff$LimitOfGroup)) ) {
    limit.cutoff <- NaN
    limit.pvalue <- NaN
  } else {
    limit.cutoff <- in.list.result.cutoff$LimitOfGroup$cutoff
    limit.pvalue <- in.list.result.cutoff$LimitOfGroup$pValue
  }
  
  return.limit.pvalue <- 
    ifelse(in.flag.make.pvalue.str, 
           makePvalueStr(limit.pvalue, is.simple = T, 
                         in.last.num = const_pvalueSignificant, is.flag = T),
           limit.pvalue)
  return.unlimit.pvalue <- 
    ifelse(in.flag.make.pvalue.str, 
           makePvalueStr(in.list.result.cutoff$unLimitOfGroup$pValue, 
                         is.simple = T, 
                         in.last.num = const_pvalueSignificant, 
                         is.flag = T),
           in.list.result.cutoff$unLimitOfGroup$pValue)
  
  return(data.frame(limit.cutoff = limit.cutoff,
                    limit.pvalue = return.limit.pvalue,
                    unlimit.cutoff = in.list.result.cutoff$unLimitOfGroup$cutoff,
                    unlimit.pvalue = return.unlimit.pvalue,
                    row.names = in.row.name))
}


plotMosaic2 <- function(inDataFrame, rowCol, colCol, in.title = "") {
  
  # plot Mosaic Plot
  #
  # arg
  #   - inDataFrame: input Dataframe
  #   - rowCol: table row
  #   - colCol: table col
  #
  # ref:
  #   - http://learnr.wordpress.com/2009/03/29/ggplot2_marimekko_mosaic_chart/
  
  xmax <- NULL;
  
  
  
  segment <- value <- ymax <- value <- xmin <- xmax <- xmin <- ymin <-
    ymax <- ymin <- ymin <- ymax <- xmin <- xmax <- variable <- xtext <- ytext <- N.Value <- xmax <- NULL
  
  tableSave <- table(inDataFrame[ , rowCol], inDataFrame[ , colCol], dnn = c(rowCol, colCol))
  
  df <- data.frame(segment = rownames(tableSave),
                   segpct = apply(tableSave, 1, sum)
  )
  for (tmpCol in colnames(tableSave)) {
    df[ , tmpCol] <- tableSave[ , tmpCol] / df[ , "segpct"] * 100
  }
  
  # 	df <- data.frame(	segment = c("A", "B", "C", "D"), # row name
  # 										segpct = c(1, 30, 20, 10), 			# row sum
  # 										Alpha = c(1, 40, 30, 25), 				# column 1
  # 										Beta = c(25, 30, 30, 25), 				# column 2
  # 										Gamma = c(10, 20, 20, 25)				# column 2
  # 	)
  
  # Calculate cumulative width on x-axes, starting point of each column and erase segpct variable.
  
  df$xmax <- cumsum(df$segpct)
  df$xmin <- df$xmax - df$segpct
  df$segpct <- NULL
  
  # Data looks like this before the long-format conversion:
  #   head(df)
  
  # After melting the data looks like this:
  dfm <- melt(df, id = c("segment", "xmin", "xmax"))
  #   head(dfm)
  
  dfm[ , "N.Value"] <- NA
  for(loopTemp in 1:dim(dfm)[1]) {
    dfm[loopTemp, "N.Value"] <- tableSave[dfm[loopTemp, "segment"], dfm[loopTemp, "variable"]]
  }
  
  # Now we need to determine how the columns are stacked and where to position the text labels.
  
  # Calculate ymin and ymax:
  dfm1 <- ddply(dfm, .(segment), transform, ymax = cumsum(value))
  dfm1 <- ddply(dfm1, .(segment), transform, ymin = ymax - value)
  
  # Positioning of text:
  dfm1$xtext <- with(dfm1, xmin + (xmax - xmin)/2)
  dfm1$ytext <- with(dfm1, ymin + (ymax - ymin)/2)
  
  # Finally, we are ready to start the plotting process:
  p <- ggplot(dfm1, aes(ymin = ymin, ymax = ymax, xmin = xmin, xmax = xmax, fill = variable))
  
  # Use grey border to distinguish between the segments:
  p1 <- p + geom_rect(colour = I("grey"))
  
  # The explanation of different fill colours will be included in the text label of Segment A using the ifelse function.
  #p2 <- p1 + geom_text(aes(x = xtext, y = ytext, label = paste(value, "%", sep = "") ), size = 3.5)
  p2 <- p1 + geom_text(aes(x = xtext, y = ytext, label = paste("N = \n", N.Value, sep = "") ), size = 5)
  
  # The maximum y-axes value is 100 (as in 100%), and to add the segment description above each column I manually specify the text position.
  dfm1_x <- aggregate(cbind(xtext)  ~  segment, data = dfm1, FUN = mean)
  p3 <- p2
  for (tmp in seq(1:dim(dfm1_x)[1])) {
    dataX <- dfm1_x$xtext[tmp]
    labelX <- dfm1_x$segment[tmp]
    p3 <- p3 + annotate('text', x = dataX, y = -5, label = labelX, size = 5, angle = 90)
  }
  dfm1_y <- subset(dfm1, xmax == max(dfm1$xmax))
  
  for (tmp in seq(1:dim(dfm1_y)[1])) {
    dataY <- dfm1_y$ytext[tmp]
    labelY <- dfm1_y$variable[tmp]
    labelX <- max(dfm1_y$xmax) + 10
    p3 <- p3 + annotate('text', x = labelX, y = dataY, label = labelY, size = 5, angle = 0)
  }
  
  # Some last-minute changes to the default formatting: remove axis labels, legend and gridlines.
  
  #p3 + theme_bw() + labs(x = NULL, y = NULL, fill = NULL) + opts(legend.position = "none", panel.grid.major = theme_line(colour = NA), panel.grid.minor = theme_line(colour = NA))
  
  # Or, if the default palette is not to one???liking it is very easy to use a ColorBrewer palette instead:
  
  #last_plot() + scale_fill_brewer(palette = "Set2")
  
  #p3 + scale_fill_brewer(palette = "Set2") + coord_flip()
  
  fontSize <- 16
  p4 <- 
    p3 + 
    scale_fill_grey(start = 0.5, end = 0.7, na.value = "grey50", name = "")  + #for readibility of text in mosiac
    coord_flip() + 
    theme(axis.title = element_text(size = fontSize) ,
          axis.title.y = element_text(angle = 90),
          axis.text = element_text(size = fontSize),
          legend.text = element_text(size = round(fontSize)),
          legend.title = element_text(size = fontSize),
          legend.position = "none",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks.x = element_blank(),
          axis.ticks.y = element_blank(),
          panel.background = element_blank()
    ) + 
    xlab(rowCol) + ylab( colCol ) + scale_x_reverse() + 
    ggtitle(in.title) 
  
  print(p4)
}


makeSinglePvalueStr <- function(in.p.value, is.simple = F, in.last.num = 3, is.flag = F) {
  # make proper p-value string
  #
  # arg:
  #   in.p.value: number of p.value
  #		is.simple: if false, output is "p-value :" + in.p.value
  #		in.last.num: last position of value under decimal
  #   is.flag: if true, p-value < 0.05, get "*"
  # Output:
  #   string of pValue
  #
  # remarks
  #   If in.p.value is less than 0.001, string is changed to "< 0.001"
  
  if (is.na(in.p.value)) {
    return("NA")
  }
  
  if (length(in.p.value) == 0) stop('if (length(in.p.value) == 0)')
  
  if (is.character(in.p.value)) {
    in.p.value <- as.numeric(in.p.value)
  } else if (!is.numeric(in.p.value)) {
    stop("in.p.value is not fit")
    
  }
  if (in.last.num < 0) {
    stop("in.last.num argument is less than 0")
  }
  flagStr <- ""
  if (is.flag == T) {
    if (in.p.value < 0.05) {
      flagStr <- "*"
    }
  }
  
  if (in.p.value * 10 ^ in.last.num >= 1) {
    returnString = sprintf(paste0("%0.", in.last.num, "f"), in.p.value)
  } else {
    tmpZero <- paste0(rep("0", in.last.num-1), collapse = "")
    returnString = paste0("<0.", tmpZero, "1", collapse = "")
  }
  returnString <- paste0(returnString, flagStr)
  
  if (is.simple == F) {
    returnString <- paste("P-value :", returnString)
  }
  return(returnString)
}

calPvalueOfAnovaInDf <- function(in.df, in.group.col, in.value.col) {
  return(summary(aov(in.df[ , in.value.col] ~ in.df[ , in.group.col]))[[1]][["Pr(>F)"]][1])
}


plotCompareHistogram <- function(in.data.frame, in.x.col.name, in.group.col.name, 
                                 in.flag.density = F, in.title = "", in.binwidth = NA) {
  # make histogram separated by the group
  #
  # arg
  #   - in.data.frame: dataframe to plot
  # 	- in.x.col.name: data for x-axis
  #		- in.group.col.name: group to separate
  # return
  #   - none
  #
  
  
  
  if (is.na(in.binwidth)) {
    in.binwidth <- (max(in.data.frame[ ,in.x.col.name]) - min(in.data.frame[ ,in.x.col.name])) / 30      
  }   
  
  # alpha means thd in.flag.density of color
  df.ggplot <- data.frame(gg.x = in.data.frame[ , in.x.col.name], 
                          gg.fill =  as.factor(in.data.frame[ , in.group.col.name])
  )
  objectPlot <- ggplot(data =  df.ggplot, aes(x = gg.x, fill = gg.fill)) + 
    scale_fill_grey(name = in.group.col.name, start = const_scaleFillGreyStart, end = const_scaleFillGreyStop) +
    xlab(in.x.col.name) # + ggtitle(title.add)
  if (in.flag.density == T) {
    objectPlot = objectPlot + geom_histogram(aes(y = (..count..)/sum(..count..))) + ylab("Percent") 
  } 
  objectPlot <- objectPlot + 
    geom_histogram(position = "dodge", binwidth =  in.binwidth) + 
    ggtitle(in.title)
  
  print(objectPlot)
}


SurvDiffPValue <- function(inTime, inEvent, inGroup) {
  
  
  if ( (length(inTime) != length(inEvent)) || (length(inTime) != length(inEvent))) {
    stop("SurvdiffPValue input values is not equal!")
  }
  if (length(inTime) != length(inEvent)) {
    stop("SurvdiffPValue input values is not equal!")
  }	
  
  tempSurvDiff = survdiff(Surv(inTime, inEvent == 1) ~ inGroup)
  pValtemp <- 1 - pchisq(tempSurvDiff$chisq, length(tempSurvDiff$n) - 1)	
  
  return(pValtemp)
}


plotSurvival <- function(in.surv.fit, in.gray.picture = F, in.title = "",
                         in.num.group = 2,
                         in.xlab = "Time", in.ylab = "Survival",
                         in.legend.title = "", in.legend.label = NA,
                         in.legend.value = NA,
                         in_max_time = NA) {
  
  if (in.gray.picture == FALSE) {
    plot.data <- ggsurv(in.surv.fit)
    # if needed legend, check below line
    # (pl2 <- pl2 + guides(color = guide_legend("title", labels = c('Male', 'Female'))) +
    # scale_color_discrete(labels = c("Male", "Female")))
  } else {
    plot.data <- ggsurv(in.surv.fit,
                        lty.est = 1:in.num.group,
                        surv.col = c('black'),
                        cens.col = 'black',
                        cens.shape = 3,
                        plot.cens = FALSE,
                        back.white = TRUE,
                        xlab = in.xlab,
                        ylab = in.ylab)
    
    if (any(is.na(in.legend.label))) {
      suppressMessages(plot.data <- plot.data  + guides(colour = FALSE) + scale_linetype_discrete(name = in.legend.title))
    } else {
      plot.data <- plot.data + guides(colour = FALSE)
      if (in.num.group == 2) {
        tmp_value <- c('dashed', 'solid')
        if (in.num.group == 2) {
          if (all(order(factor(in.legend.value)) != 1:2)) {
            tmp_value <- c('solid', 'dashed')
          }
        }        
        suppressMessages(plot.data <- plot.data + 
                           scale_linetype_manual(name = in.legend.title,
                                                 breaks = in.legend.value,
                                                 labels = in.legend.label,
                                                 values = tmp_value)
        )
        
      } else {
        suppressMessages(plot.data <- plot.data + 
                           scale_linetype_discrete(name = in.legend.title,
                                                   breaks = factor(in.legend.value),
                                                   labels = factor(in.legend.label)
                           )
        )
      }
    }
  }
  
  if (any(is.na(in_max_time))) {
    max_time_of_survival <- max(in.surv.fit$time)
  } else {
    max_time_of_survival <- in_max_time
  }
  plot.x.unit <- 50
  plot.maxtime <- ceiling(max_time_of_survival / plot.x.unit ) * plot.x.unit
  
  plot.data <- plot.data +
    coord_cartesian(xlim = c(0, plot.maxtime), ylim = c(0, 1)) +
    ggtitle(paste(in.title, '\n'))
  
  print(plot.data)
  print(in.surv.fit)
}


setScriptArg <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  script_path <- dirname(sub("--file=","",args[grep("--file",args)]))

  if (length(script_path) != 0) {
    setwd(script_path)
  }  
}


toDfString <- function(in_df) {
  in_df <- data.frame(lapply(in_df, as.character), stringsAsFactors=FALSE)  
}

EG2Symbol <- function(eg, organism = "human", useBiomart=FALSE) {
    eg <- as.character(eg)
    if (useBiomart == TRUE) {
        ##require(biomaRt)
        if (organism == "human") {
            wh_dataset = "hsapiens_gene_ensembl"
        } else if (organism == "mouse") {
            wh_dataset = "mmusculus_gene_ensembl"
        } else if (organism == "rat") {
            wh_dataset = "rnorvegicus_gene_ensembl"
        } else {
            stop ("Not supported yet...\n")
        }
        ensembl = useMart("ensembl", dataset=wh_dataset)
        if (organism == "human") {
            symbol <- getBM(attributes=c("entrezgene", "hgnc_symbol"),
                            filters="entrezgene", values=eg, mart=ensembl)
        } else if (organism == "mouse" ) {
            symbol <- getBM(attributes=c("entrezgene", "mgi_symbol"),
                            filters="entrezgene", values=eg, mart=ensembl)
        }
        result <- symbol[!is.na(symbol[,2]),]
        result <- symbol[symbol[,2] != "",]
    } else {
        if (organism == "human") {
            x <- org.Hs.egSYMBOL
            mapped_proteins <- mappedkeys(x)
            xx <- AnnotationDbi::as.list(x[mapped_proteins])
            symbol <- xx[eg]
            eg.symbol.df <- ldply(symbol)
            names(eg.symbol.df) <- c("entrezgene", "hgnc_symbol")
            result <- eg.symbol.df
        }
    }
    return (result)
}


Symbol2EG <- function(gene_name, organism = "human", useBiomart=FALSE) {
    gene_name <- as.character(gene_name)
    if (useBiomart == TRUE) {
        
        if (organism == "human") {
            wh_dataset = "hsapiens_gene_ensembl"
        } else if (organism == "mouse") {
            wh_dataset = "mmusculus_gene_ensembl"
        } else if (organism == "rat") {
            wh_dataset = "rnorvegicus_gene_ensembl"
        } else {
            stop ("Not supported yet...\n")
        }
        ensembl = useMart("ensembl", dataset=wh_dataset)
        if (organism == "human") {
            symbol <- getBM(attributes=c("entrezgene", "hgnc_symbol"),
                            filters="hgnc_symbol", values=gene_name, mart=ensembl)
        } else if (organism == "mouse" ) {
            symbol <- getBM(attributes=c("entrezgene", "mgi_symbol"),
                            filters="hgnc_symbol", values=gene_name, mart=ensembl)
        }
        result <- symbol[!is.na(symbol[,2]),]
        result <- symbol[symbol[,2] != "",]
    } else {
        if (organism == "human") {
            x <- org.Hs.egSYMBOL
            mapped_proteins <- mappedkeys(x)
            xx_tmp<- AnnotationDbi::as.list(x[mapped_proteins])
            xx <- rep(NA, length(xx_tmp))
            xx <- names(xx_tmp)
            names(xx) <- unlist(xx_tmp)            
            symbol <- xx[gene_name]
            gene_name.symbol.df <- ldply(symbol)
            names(gene_name.symbol.df) <- c("hgnc_symbol", "entrezgene")
            result <- gene_name.symbol.df
        }
    }
    return (result)
}


makeTableAndPlotGSEA <- function(in_list_gsea) {
    library(DOSE)
    library(clusterProfiler)
    library(org.Hs.eg.db)
    
    gene_list_entrez_id <- Symbol2EG(in_list_gsea)$entrezgene
    
    fake_order_gene_list <- seq(1, -1, length.out = length(gene_list_entrez_id))
    names(fake_order_gene_list) <- gene_list_entrez_id
    
    gsecc <- gseGO(geneList=fake_order_gene_list, ont="BP", OrgDb=org.Hs.eg.db, verbose=FALSE)
    tmp <- as.data.frame(gsecc)
    if (nrow(tmp) <= 0) {
        cat("There are no GSEA Gene set with statistically significant!")    
    } else {
        print(tmp[ , c("ID",  "Description", "enrichmentScore", "pvalue", "p.adjust")])
        for (i in 1:min(nrow(tmp), 5)) {
            gene_set_id <- row.names(tmp)[i]
            print(gseaplot(gsecc, geneSetID=gene_set_id, title = gene_set_id))
        }
    }
}


getPpiTableAndPlotByGeneName <- function(in_gene_list, in_irefr_hubo_path=fitFilePath(const_rootSource, 'iRefR_Hugo.Rds')) {
    library('graph')
    library("iRefR")
    library('stringr')
    library('igraph')
    library("DOSE")
    
    CONST_MAX_GENE_LIST <- 200
    
    if (length(in_gene_list) > CONST_MAX_GENE_LIST) {
        print("Gene_list is cut by first " %+% CONST_MAX_GENE_LIST %+% " genes")
        in_gene_list <- in_gene_list[1:CONST_MAX_GENE_LIST]
    }
    
    x2 <- readRDS(in_irefr_hubo_path)
    x3 <- unique(x2[x2[ , 1] %in% in_gene_list & x2[ , 2] %in% in_gene_list, ])
    x3 <- x3[x3[, 1] != x3[, 2], ]
    gene_list_in_graph <- unique(unlist(x3))
    ppi.graph <- graph_from_data_frame(x3, vertices=gene_list_in_graph, directed=FALSE)
    
    if (length(gene_list_in_graph) <= 0) {
        cat("Any input gene list is not existed in iRefR\n")
        invisible()
    } else {
        cat( paste(setdiff(in_gene_list, gene_list_in_graph), collapse = ','), " is not existed in iRefR\n")
    }  
    
    edges = get.edges(ppi.graph, 1:(igraph::ecount(ppi.graph)))
    ppi.graph = igraph::simplify(ppi.graph)
    cols = rep("yellow", vcount(ppi.graph))
    # plot(subgraph, layout=layout.kamada.kawai, vertex.size=5, vertex.color=cols, vertex.label=V(subgraph)$name, 
    #    vertex.label.family = "sans")
    
    DOSE::plot(igraph::simplify(ppi.graph), type = "hybrid", layout=layout.kamada.kawai, vertex.size=30, vertex.label=V(ppi.graph)$name)
    resultTable <- igraph::as_data_frame(ppi.graph)
    colnames(resultTable) <- c('Gene A', 'Gene B')
    return(resultTable)
}
