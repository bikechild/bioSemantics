source("commonFunc.R")

library(sva)

flag_notDeleteResultFile4test <- FALSE

# program
genoDataByGeneName <- readRDS(const_old_summaryGDataFile)
finalPdata <- readRDS(const_old_arrangePDataFile)


jsonData <- tryInf(jsonlite::fromJSON(const_MainJson))

for (i in names(jsonData)) {
    assign(i, jsonData[[i]])
}

objKnitr <- knitrByCommand$new("analysisUsingPhenotypeAndGenoType",
                               getwd(),
                               const_docPath)

multiplePhenotypeRunDf <- list()
if (flag_analysisPhenotypeMultiple){
    jsonPhenoData <- tryInf(jsonlite::fromJSON(const_MainPhenoLoopJson))
    for (i in jsonPhenoData$continuousFeatures) {
        multiplePhenotypeRunDf[[length(multiplePhenotypeRunDf) + 1]] <-
            list(kind = 'continuous', value = i)
    }
    for (i in jsonPhenoData$discreteFeatures) {
        multiplePhenotypeRunDf[[length(multiplePhenotypeRunDf) + 1]] <- 
            list(kind = 'discrete', value = i)
    }  
    if (!flag_Test) {
        for (i in seq(nrow(jsonPhenoData$survivalFeatures))) {
            multiplePhenotypeRunDf[[length(multiplePhenotypeRunDf) + 1]] <- 
                list(kind = 'survival', value = jsonPhenoData$survivalFeatures[i, ])    
        }   
    }
    vecGenes <- strsplit(jsonPhenoData$genes, "(\\s|,)+")[[1]]
} else {
    vecGenes <- strsplit(jsonData$tmpGeneName, "(\\s|,)+")[[1]]
}

tmpCount <- 1
while (!flag_analysisPhenotypeMultiple || tmpCount <= length(multiplePhenotypeRunDf)) {
    if (flag_analysisPhenotypeMultiple) {
        flag_groupByStr <- FALSE
        flag_continuousFeature <- FALSE
        flag_survivalFeature <- FALSE
        flag_discreteFeature <- FALSE
        flag_analysisPhenotypeMultiple <- FALSE
        tmpKnitrSetData <- multiplePhenotypeRunDf[[tmpCount]]
        if (tmpKnitrSetData[['kind']] == 'continuous') {
            flag_continuousFeature <- TRUE
            vecContinuousFeature <- tmpKnitrSetData[['value']]
            fileNameFeature <- vecContinuousFeature
        } else if (tmpKnitrSetData[['kind']] == 'discrete') {
            flag_discreteFeature <- TRUE      
            vecDiscreteFeature <- tmpKnitrSetData[['value']]      
            fileNameFeature <- vecDiscreteFeature
        } else if (tmpKnitrSetData[['kind']] == 'survival') {
            flag_survivalFeature <- TRUE
            colSurvivalTime <- tmpKnitrSetData[['value']][ , 'time']
            colSurvivalEvent <- tmpKnitrSetData[['value']][ , 'event']
            fileNameFeature <- paste('survival', 
                                     tmpKnitrSetData[['value']][ , 2], 
                                     tmpKnitrSetData[['value']][ , 'event'], 
                                     sep = '_'
            )
        } else {
            stop("    if (tmpKnitrSetData['kind'] == 'continuous') {")
        }
    } else {
        fileNameFeature <- ""
    }
    saveRDS(list(genoDataByGeneName = genoDataByGeneName,
                 finalPdata = finalPdata,
                 flag_groupByStr = flag_groupByStr,
                 flag_continuousFeature = flag_continuousFeature,
                 flag_survivalFeature = flag_survivalFeature,
                 group1Str = group1Str,
                 group2Str = group2Str,
                 vecContinuousFeature = vecContinuousFeature,
                 colSurvivalTime = colSurvivalTime,
                 colSurvivalEvent = colSurvivalEvent,
                 flag_discreteFeature = flag_discreteFeature,
                 vecDiscreteFeature = vecDiscreteFeature,
                 flag_group_by_selection < flag_group_by_selection,
                 group1_list < group1_list,
                 group2_list < group2_list                 
                 ),
            pathKnitrData
            )
    for (i in vecGenes) {
        makeDoc_Rmd_const_inGeneName_makeDoc_Rmd <- i
        objKnitr$run(i %+% "_" %+% fileNameFeature)
    }
    # file.remove(pathKnitrData)
    tmpCount <- tmpCount + 1
    if (!flag_analysisPhenotypeMultiple) break
}
objKnitr$end()

# make table of cutoff data
if (file.exists(const_docSummaryCutoffFile)) {
    docSummaryCutOff<- readRDS(const_docSummaryCutoffFile)
    docSummaryCutOff <- docSummaryCutOff[order(rownames(docSummaryCutOff)), ]
    less_1Eminus3Col <- grep(pattern = "^<0.001\\*$", docSummaryCutOff$limit.pvalue)
    if (length(less_1Eminus3Col) >= 1) {
        docSummaryCutOff4Write <- docSummaryCutOff[-less_1Eminus3Col, ]
    } else {
        docSummaryCutOff4Write <- docSummaryCutOff
    }
    docSummaryCutOff4Write <- 
        docSummaryCutOff4Write[order(gsub(pattern = "[\\<|*]", 
                                          replacement = "", 
                                          docSummaryCutOff4Write$limit.pvalue
        )
        ), ]
    if (length(less_1Eminus3Col) >= 1) {
        docSummaryCutOff4Write <- rbind(docSummaryCutOff[less_1Eminus3Col, ], docSummaryCutOff4Write)  
    }
    
    write.csv(docSummaryCutOff4Write, const_docSummaryCutoffTable)
    
    if (!flag_notDeleteResultFile4test) {
        file.remove(const_docSummaryCutoffFile)  
    }
}

