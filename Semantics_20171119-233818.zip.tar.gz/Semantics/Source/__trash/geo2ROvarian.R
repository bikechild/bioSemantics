source("D:\\bioSemantic\\GEO\\commonFunc.R")
# ToDO: "CAARRAY", "TCGA",
geoList <- c("GSE14764","GSE15622","GSE18520","GSE19829","GSE23554","GSE26193","GSE26712","GSE27651","GSE30161","GSE3149","GSE51373","GSE9891")
getGEOpData(geoList,  "..\\Data\\outPData.rds", "D:\\BioDatabase\\GEOFile")
