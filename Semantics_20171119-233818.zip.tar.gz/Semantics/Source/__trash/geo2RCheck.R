cat('\14')
rm(list = ls())
source("commonFunc.R")

checkGeo2R( readRDS("..\\data\\pDataSaveLung.rds") )
