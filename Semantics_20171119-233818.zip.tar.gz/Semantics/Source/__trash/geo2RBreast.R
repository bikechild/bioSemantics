source("D:\\bioSemantic\\GEO\\commonFunc.R")
# ToDO: "CAARRAY", "TCGA",
geoList <- c("GSE2990","GSE3494","GSE6532","GSE12093","GSE9195","GSE16391","GSE17705","GSE19615")
getGEOpData(geoList,  "..\\Data\\outPData.rds", "D:\\BioDatabase\\GEOFile")