source("commonFunc.R")

data <- read.delim('../../Data/SurvExpressData.txt')

dataSelected <- data
dataSelected <- dataSelected[grep("stage", dataSelected[ ,"Clinical.data"], ignore.case = TRUE), ]
dataSelected <- dataSelected[grep("GSE\\d{1,}", dataSelected[ , "Database"], ignore.case = TRUE), ]
geoList <- sub(".*(GSE\\d{1,}).*", "\\1", dataSelected[ , "Database"])
saveRDS(geoList, file = const_pathFileSurvExpressGeoList)

# getGEOpData(geoList,  "..\\Data\\outPData.rds", "D:\\BioDatabase\\GEOFile")

