source("D:\\bioSemantic\\GEO\\commonFunc.R")
# ToDO: "CAARRAY", "TCGA",
geoList <- c("GSE14814", "GSE19188", "GSE29013", "GSE30219", "GSE31210", "GSE3141", "GSE31908", "GSE37745", "GSE43580", "GSE4573", "GSE50081", "GSE8894")
getGEOpData(geoList,  "..\\Data\\outPData.rds", "D:\\BioDatabase\\GEOFile")
