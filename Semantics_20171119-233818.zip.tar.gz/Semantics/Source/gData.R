source("commonFunc.R")

library("biomaRt")
library("stringr")

flag_TEST <- FALSE
# flag_TEST <- TRUE

const_flagMeanOfSameGene <- TRUE

genoData <- readRDS(const_pathFileGeno)
featData <- readRDS(const_pathFileFeature)
gplData <- readRDS(const_pathFileGplList)

for ( i in names(genoData)) {
  if(any(rownames(genoData[[i]]) != rownames(featData[[i]]))){
    cat(i, '\n')
    stop("if(any(rownames(genoData[[i]]) != rownames(featureData[[i]]))){")
  }
}

extractRefSeqName <- function(in_vec) {
  return(str_match_all(in_vec, "NM_[.0-9]{1,}"))
}

getAilunData <- function(in.gpl.name) {
  const_ailun.path <- 'D:/BioDatabase/ailun/annotation/geo/'
  file.path.of.gpl <- paste0(const_ailun.path, in.gpl.name ,".annot")
  if (fileExistCheck(file.path.of.gpl)) {
    read.csv(file = file.path.of.gpl, sep= '\t', header = FALSE, stringsAsFactors = F)
  } else{
    return(NULL)
  }
}

getGeneSymbolFromGbList <- function(in.vec.gb) {
  library(stringr)
  library(biomaRt)
  
  df.gb.selected <- extractRefSeqName(in.vec.gb)
  gb.to.convert <- unique(unlist(df.gb.selected))
  
  tmp_try_count <- 0
  repeat{
    retry_flag <- FALSE
    tryCatch({mart <- useMart(dataset="hsapiens_gene_ensembl", biomart='ensembl')},
             error = function(e){ retry_flag <- TRUE})
    if (retry_flag){
      if (tmp_try_count >= 100) {
        stop('    if (tmp_try_count >= 100) {')
      } else {
        tmp_try_count <- tmp_try_count + 1
        print(tmp_try_count)
      }
    } else {
      break
    }
  }
  
  result.biomart <-  biomaRt::select(mart, keys=c(gb.to.convert), columns=c('refseq_mrna','hgnc_symbol'), keytype='refseq_mrna')
  
  vec.result <- rep(NA, length(df.gb.selected))
  for (tmp in 1:length(df.gb.selected)) {
    tmp.return.vec <- unique(result.biomart[which(result.biomart$refseq_mrna %in% df.gb.selected[[tmp]]), "hgnc_symbol"])
    
    vec.result[tmp] <- paste(tmp.return.vec , collapse = " \\ ")  
  }
  
  return(vec.result)
}

getOneRefSeqMrna <- function(in.vec.gb){
  
  return(str_extract(in.vec.gb, "NM_\\d{1,}"))
}

getGeneSymbolFromGbCol <- function(in.vec.gb) {
  
  
  tmp <- getOneRefSeqMrna(in.vec.gb)
  return.value <- getGeneSymbolFromGbList(tmp)
  return(return.value)
}

filterHgncName <- function(in.vec.hgnc.name){
  
  tmp.out <- checkGeneSymbols(in.vec.hgnc.name)$Suggested.Symbol
  return(gsub(" /// .*", "", tmp.out))
}


# make probeToGeneSymbol table
featGeneSymbolData <- list()
vec_orig_gpl <- c()
vec_ailun <- c()
vec_bblist <- c()
for ( i in names(featData)) {
  cat( "probeToGeneSymbol: ", i, '\n')
  tmpFeatureData <- featData[[i]]
  vecGeneSymbolColName <- c("gene_symbol", "gene symbol", "symbol", "orf", "orf_list")
  colPosOfGeneName <- which(tolower(colnames(tmpFeatureData)) %in% vecGeneSymbolColName)
  colPosOfGblist <- which(tolower(colnames(tmpFeatureData)) %in% c("gb_list"))
  
  is_needed_biomart <- F
  if ( length(colPosOfGblist) > 0 ) {
    df.gb.selected <- extractRefSeqName(tmpFeatureData[ , min(colPosOfGblist)])
    gb.to.convert <- unique(unlist(df.gb.selected))    
    if (length(gb.to.convert) > 0)  {
      is_needed_biomart <- T
    }
  }
  
  # if ( length(colPosOfGeneName) > 0 ) {
  #   featGeneSymbolData[[i]] <- data.frame(ID = rownames(tmpFeatureData), 
  #                                         Gene_Symbol = tmpFeatureData[ , min(colPosOfGeneName)])
  #   vec_orig_gpl <- c(vec_orig_gpl, i)
  # } else if(!is.null(getAilunData(gplData[[i]]))){
  #   returnAilunData <- getAilunData(gplData[[i]])
  #   featGeneSymbolData[[i]] <- data.frame(ID = returnAilunData$V1, Gene_Symbol = returnAilunData$V3)
  #   vec_ailun <- c(vec_ailun, i)
  # } else if ( length(colPosOfGblist) > 0 ) {
  #   featGeneSymbolData[[i]] <- data.frame(ID = rownames(tmpFeatureData), 
  #                                         Gene_Symbol = getGeneSymbolFromGbList(tmpFeatureData[ , min(colPosOfGblist)]))
  #   vec_bblist <- c(vec_bblist, i)
  # } else {
  #   cat("Problem in 'make probeToGeneSymbol table':", i, '\n')
  #   featGeneSymbolData[[i]] <- NULL
  # }
  
  if ( length(colPosOfGeneName) > 0 ) {
    featGeneSymbolData[[i]] <- data.frame(ID = rownames(tmpFeatureData),
                                          Gene_Symbol = tmpFeatureData[ , min(colPosOfGeneName)])
    vec_orig_gpl <- c(vec_orig_gpl, i)
  } else if (is_needed_biomart) {
    featGeneSymbolData[[i]] <- data.frame(ID = rownames(tmpFeatureData),
                                          Gene_Symbol = getGeneSymbolFromGbList(tmpFeatureData[ , min(colPosOfGblist)]))
    vec_bblist <- c(vec_bblist, i)
  } else if(!is.null(getAilunData(gplData[[i]]))){
    returnAilunData <- getAilunData(gplData[[i]])
    featGeneSymbolData[[i]] <- data.frame(ID = returnAilunData$V1, Gene_Symbol = returnAilunData$V3)
    vec_ailun <- c(vec_ailun, i)
  } else {
    cat("Problem in 'make probeToGeneSymbol table':", i, '\n')
    featGeneSymbolData[[i]] <- NULL
  }
  
}

if (flag_TEST) {
  stop("haha")
}



#Gene_Symbol Char Check
if (FALSE) {
  
  vecTest <- c()
  for ( i in names(featGeneSymbolData)) {
    print(head(featGeneSymbolData[[i]]))
  }
  
  # vecTest Checker
  vecTest <- unique(vecTest)
  vecTest[grep('[^\'-._@a-zA-Z0-9 ]', vecTest)]
  vecTest[grep('//{2,3}', vecTest)]
  
  vecTestUnifySplitChar <- str_replace_all(vecTest, pattern = "/{3,}", "//")
  vecTestList <- str_split(vecTestUnifySplitChar, "//")
  
  
  for ( i in names(featGeneSymbolData)) {
    if(!is.null(featGeneSymbolData[[i]])){
      vecTest <- c(vecTest, as.character(featGeneSymbolData[[i]]$Gene_Symbol))
    } else {
      cat( i,  " is NULL\n")
    }
  }
}



#conversion to gene - probe
featGeneSymbol2ProbeIDData <- list()
for ( tmpNameOfFeatGeneSymbolData in names(featGeneSymbolData)) {
  cat("featGeneSymbolData: ", tmpNameOfFeatGeneSymbolData, '\n')
  
  tmp <- featGeneSymbolData[[tmpNameOfFeatGeneSymbolData]]
  tmp <- data.frame(lapply(tmp, as.character), stringsAsFactors=FALSE)
  tmp2 <- changeDfProbeIdGeneSymbol2listGeneSymboltoProbeId(tmp)
  featGeneSymbol2ProbeIDData[[tmpNameOfFeatGeneSymbolData]] <- tmp2
}

for (tmp in names(featGeneSymbol2ProbeIDData)) {
  print(tmp)    
  print(length(featGeneSymbol2ProbeIDData[[tmp]]))
}

genoDataByGeneName <- list()
for (tmpNames in names(genoData)) {
  cat("genoData: ", tmpNames, '\n')
  
  singleGenoData <- genoData[[tmpNames]]
  singleFeatGeneSymbol2ProbeIDData <- featGeneSymbol2ProbeIDData[[tmpNames]]
  
  if(const_flagMeanOfSameGene == TRUE){
    calFunction <- mean 
  } else {
    calFunction <- max
  }
  genoDataByGeneName[[tmpNames]] <- makeGeneRowMatrix(singleGenoData, singleFeatGeneSymbol2ProbeIDData, calFunction)
}

for ( tmp in names(featGeneSymbol2ProbeIDData)) {
  print(tmp)    
  print(nrow(genoDataByGeneName[[tmp]]))
}

saveRDS(genoDataByGeneName, const_summaryGDataFile)
